#--------------------------------------------------------------------------
# SharepointConfig.psd1
#   Settings for the SharePoint scripts (Upload2SharePoint.ps1 and
#   DownloadFromSharePoint.ps1).
#   App/tenant info lives in the shared Entra config; the path below is
#   relative to THIS file.
#--------------------------------------------------------------------------

@{
    EntraConfig       = "..\Common\config\EntraApp.psd1"

    SharePointHost    = "033gc.sharepoint.com"

    # Retries per file (upload/validate, move, download) and per chunk
    MaxRetries        = 3
    BaseDelay         = 5

    #----------------------------------------------------------------------
    # Throttling (both scripts)
    #----------------------------------------------------------------------

    # Circuit breaker: after this many throttling responses (429/503) in one
    # run, stop and leave the remaining files for the next run
    MaxThrottleEvents = 10

    # Longest Retry-After (seconds) the script will wait. If SharePoint asks
    # for more, the run stops and the next run carries on.
    MaxRetryAfter     = 300

    #----------------------------------------------------------------------
    # Upload
    #----------------------------------------------------------------------

    # Files larger than this (MB) are uploaded in 10 MB chunks instead of one
    # request; keeps each request short on a slow link
    SimpleUploadLimitMB = 50

    # Default staging folder (the -StagingFolder parameter overrides it)
    StagingFolder     = "_staging"

    # Staged copies older than this (left by killed runs) are removed at start
    StagingMaxAgeDays = 2

    # Office files: seconds to wait after upload before reading the hash
    # (SharePoint injects metadata). Other files wait only if the upload
    # response doesn't already prove the file is intact.
    SettleDelay       = 5

    # How many times to re-read the item if the hash is not available yet
    HashReadAttempts  = 3

    # Pause between files (upload, and download of a folder), to stay under
    # SharePoint's request limits
    DelayBetweenFiles = 2

    # Passes per run for a folder (upload, download All). Pass 1 tries
    # every file; each next pass retries only the files still failing for a
    # temporary reason (e.g. 10 files: 5 ok in pass 1, 3 more in pass 2,
    # last 2 in pass 3). Files still failing after the last pass are retried
    # by a rerun; files already done are skipped.
    MaxPasses         = 3

    # Seconds to wait before starting another pass (lets SharePoint recover)
    PassDelay         = 30

    # Upload manifest folder (one .json per site + target folder):
    #   -LogFolder given : <LogFolder>\<StateFolderName>
    #   no -LogFolder    : <script folder>\<StateFolderName>
    # The manifest must stay in the same place from run to run, so pass a
    # stable -LogFolder (put a run id in -LogFileName, not in -LogFolder).
    StateFolderName   = "state"

    #----------------------------------------------------------------------
    # Download
    #----------------------------------------------------------------------

    # Longest a single file download may take before it is cut off
    DownloadTimeoutMinutes = 60

    #----------------------------------------------------------------------
    # Exit codes returned to the calling job (both scripts).
    # A failure before this file is loaded (modules, this config itself)
    # exits with 99: the scripts hardcode it since these codes aren't known yet.
    #----------------------------------------------------------------------
    ExitCodes = @{
        Success            = 0    # done (also: files already there / local file already identical / empty folder)
        UploadFailed       = 1    # upload, one file: failed after all retries
        LocalPathNotFound  = 2    # local file or folder not found
        AuthFailed         = 10   # Graph authentication
        SiteNotFound       = 11   # site or default document library
        FileExists         = 12   # destination differs and overwrite is off
        FolderError        = 13   # upload: target missing or staging not creatable
        MoveFailed         = 14   # upload, single file: validated file not moved to target
        PartialFailure     = 15   # folder: some files failed for a temporary reason; rerun to retry
                                  # (files already done are skipped)
        InvalidFileName    = 16   # name not allowed (upload: by SharePoint; download: -LocalFileName)
        RemoteFileNotFound = 17   # download: path not found or empty, or no matching file (Latest)
        DownloadFailed     = 18   # download, one file: failed or invalid after all retries
        LocalWriteFailed   = 20   # download, one file: can't write locally (access denied, disk full, locked)
        InvalidParameter   = 21   # download: -LocalFileName with a folder in DownloadMode All
        NeedsReview        = 22   # folder: some files failed for a reason a rerun won't fix
                                  # (invalid name, file exists with -NoOverwrite, access denied);
                                  # see REVIEW lines in the log summary
        SetupFailed        = 98   # setup after config load (log folder, Entra config path)
        Unexpected         = 99   # any error not covered above, or config not loaded
    }
}
