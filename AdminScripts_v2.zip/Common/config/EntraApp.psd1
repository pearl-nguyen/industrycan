#--------------------------------------------------------------------------
# EntraApp.psd1
#   Microsoft Entra app registration, its certificate and the DPAPI secret
#   store. Shared by every script that calls Graph (SharePoint upload and
#   download, email) and by the Security scripts (InstallCert.ps1,
#   SaveSecret.ps1). Replaces the former Security\SecurityConfig.psd1.
#
#   No secrets here: Graph sign-in uses the certificate in LocalMachine\My,
#   and passwords are stored as DPAPI-encrypted files (Secrets.Folder).
#--------------------------------------------------------------------------

@{
    TenantId   = "b72ac62f-06d5-4cd5-824e-ee92319a4676"
    ClientId   = "452f66fa-4eea-4ba8-885b-ad65f3bd1e2c"

    # Certificate used to sign in to Graph. After installing a new
    # certificate (InstallCert.ps1), put its thumbprint here once the new
    # key has been added to the Entra app.
    Thumbprint = "F59E00898EF052136F3F562A4263A6D3491480AF"

    Certificate = @{
        # Subject of the app certificate managed by InstallCert.ps1. Only
        # certificates with exactly this subject are ever changed or deleted.
        Subject       = "CN=STS - SMS Operations"

        # DPAPI secret holding the PFX password (saved with SaveSecret.ps1)
        PfxSecretName = "StsSmsOpsCertPfx"
    }

    Secrets = @{
        # Folder of the encrypted secrets (<Name>.bin): absolute, or relative
        # to THIS file. Here: <root>\Security\secrets
        Folder  = "..\..\Security\secrets"

        # Extra key mixed into the encryption. NEVER change it once secrets
        # are saved: they could no longer be decrypted.
        Entropy = "STS-SMS-Ops-DPAPI-v1"
    }
}
