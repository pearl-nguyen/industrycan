#--------------------------------------------------------------------------
# GraphAuth.psm1
#   App-only Microsoft Graph authentication with a certificate, driven by
#   the shared Entra config (Common\config\EntraApp.psd1).
#   Used by SharePoint upload/download, email, certificate checks, ...
#   Requires ConfigHelpers.psm1 to be imported by the calling script.
#--------------------------------------------------------------------------

$script:EntraRequired = @("TenantId", "ClientId", "Thumbprint")

# Loads the Entra config and connects to Graph with the certificate.
# Certificate checks (presence, expiry warnings) belong to a separate script.
# Returns safe connection info (no secrets) for logging.
function Connect-AppGraph {

    param(
        [Parameter(Mandatory = $true)]
        [string]$EntraConfigPath
    )

    $entra = Import-ConfigFile -Path $EntraConfigPath -Required $script:EntraRequired

    Import-Module Microsoft.Graph.Authentication -ErrorAction Stop

    Connect-MgGraph `
        -TenantId $entra.TenantId `
        -ClientId $entra.ClientId `
        -CertificateThumbprint $entra.Thumbprint `
        -NoWelcome `
        -ErrorAction Stop

    return [pscustomobject]@{
        TenantId = $entra.TenantId
        ClientId = $entra.ClientId
    }
}

# Safe to call even if never connected or the Graph module is not loaded
function Disconnect-AppGraph {

    try {
        if (Get-Command Disconnect-MgGraph -ErrorAction SilentlyContinue) {
            Disconnect-MgGraph -ErrorAction SilentlyContinue | Out-Null
        }
    }
    catch {
        # Nothing to clean up
    }
}

Export-ModuleMember -Function `
    Connect-AppGraph,
    Disconnect-AppGraph
