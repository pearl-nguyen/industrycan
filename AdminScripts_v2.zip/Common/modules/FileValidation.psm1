#--------------------------------------------------------------------------
# FileValidation.psm1
#   File hashing (SHA256, QuickXorHash) and Office package comparison.
#   QuickXorHash is the hash SharePoint Online / OneDrive for Business
#   expose through Graph (file.hashes.quickXorHash), so a local copy can be
#   checked against the remote one without downloading it.
#   Requires Logging.psm1 to be imported by the calling script.
#--------------------------------------------------------------------------

Add-Type -AssemblyName System.IO.Compression -ErrorAction Stop
Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction Stop

# Microsoft's reference QuickXorHash, compiled once per session
if (-not ('FileValidation.QuickXorHash' -as [type])) {

    Add-Type -ErrorAction Stop -TypeDefinition @'
using System;
using System.Security.Cryptography;

namespace FileValidation
{
    public class QuickXorHash : HashAlgorithm
    {
        private const int BitsInLastCell = 32;
        private const byte Shift = 11;
        private const byte WidthInBits = 160;

        private ulong[] _data;
        private long _lengthSoFar;
        private int _shiftSoFar;

        public QuickXorHash()
        {
            this.Initialize();
        }

        protected override void HashCore(byte[] array, int ibStart, int cbSize)
        {
            unchecked
            {
                int currentShift = this._shiftSoFar;
                int vectorArrayIndex = currentShift / 64;
                int vectorOffset = currentShift % 64;
                int iterations = Math.Min(cbSize, (int)WidthInBits);

                for (int i = 0; i < iterations; i++)
                {
                    bool isLastCell = vectorArrayIndex == this._data.Length - 1;
                    int bitsInVectorCell = isLastCell ? BitsInLastCell : 64;

                    if (vectorOffset <= bitsInVectorCell - 8)
                    {
                        for (int j = ibStart + i; j < cbSize + ibStart; j += WidthInBits)
                        {
                            this._data[vectorArrayIndex] ^= (ulong)array[j] << vectorOffset;
                        }
                    }
                    else
                    {
                        int index1 = vectorArrayIndex;
                        int index2 = isLastCell ? 0 : (vectorArrayIndex + 1);
                        byte low = (byte)(bitsInVectorCell - vectorOffset);

                        byte xoredByte = 0;
                        for (int j = ibStart + i; j < cbSize + ibStart; j += WidthInBits)
                        {
                            xoredByte ^= array[j];
                        }

                        this._data[index1] ^= (ulong)xoredByte << vectorOffset;
                        this._data[index2] ^= (ulong)xoredByte >> low;
                    }

                    vectorOffset += Shift;
                    while (vectorOffset >= bitsInVectorCell)
                    {
                        vectorArrayIndex = isLastCell ? 0 : vectorArrayIndex + 1;
                        vectorOffset -= bitsInVectorCell;
                    }
                }

                this._shiftSoFar = (this._shiftSoFar + Shift * (cbSize % WidthInBits)) % WidthInBits;
            }

            this._lengthSoFar += cbSize;
        }

        protected override byte[] HashFinal()
        {
            byte[] rgb = new byte[(WidthInBits - 1) / 8 + 1];

            for (int i = 0; i < this._data.Length - 1; i++)
            {
                Buffer.BlockCopy(BitConverter.GetBytes(this._data[i]), 0, rgb, i * 8, 8);
            }

            Buffer.BlockCopy(
                BitConverter.GetBytes(this._data[this._data.Length - 1]), 0,
                rgb, (this._data.Length - 1) * 8,
                rgb.Length - (this._data.Length - 1) * 8);

            byte[] lengthBytes = BitConverter.GetBytes(this._lengthSoFar);
            for (int i = 0; i < lengthBytes.Length; i++)
            {
                rgb[(WidthInBits / 8) - lengthBytes.Length + i] ^= lengthBytes[i];
            }

            return rgb;
        }

        public override sealed void Initialize()
        {
            this._data = new ulong[(WidthInBits - 1) / 64 + 1];
            this._shiftSoFar = 0;
            this._lengthSoFar = 0;
        }

        public override int HashSize
        {
            get { return WidthInBits; }
        }
    }
}
'@
}

# Office Open XML formats: SharePoint may inject metadata into these on
# upload, which changes the stored bytes, size and hash
$script:OfficeExtensions = @(".docx", ".docm", ".dotx", ".dotm",
                             ".xlsx", ".xlsm", ".xltx", ".xlam",
                             ".pptx", ".pptm", ".potx", ".ppsx", ".ppsm")

# Matches relationship / content-type entries that point at SharePoint's parts
$script:InjectedPattern = 'customXml|docProps/custom\.xml|custom-properties'

function Test-IsOfficeFile {

    param([string]$Path)

    $extension = [System.IO.Path]::GetExtension($Path).ToLower()

    return ($script:OfficeExtensions -contains $extension)
}

function Get-FileSHA256 {

    param([string]$Path)

    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256 -ErrorAction Stop).Hash
}

# Base64 QuickXorHash, same format as Graph's file.hashes.quickXorHash
function Get-FileQuickXorHash {

    param([string]$Path)

    $hasher = $null
    $fs     = $null

    try {
        $hasher = New-Object FileValidation.QuickXorHash
        $fs     = [System.IO.File]::OpenRead($Path)

        return [Convert]::ToBase64String($hasher.ComputeHash($fs))
    }
    finally {
        if ($fs)     { $fs.Dispose() }
        if ($hasher) { $hasher.Dispose() }
    }
}

function Get-StringSHA256 {

    param([string]$Text)

    $sha = $null

    try {
        $sha   = [System.Security.Cryptography.SHA256]::Create()
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
        return ([BitConverter]::ToString($sha.ComputeHash($bytes)) -replace '-')
    }
    finally {
        if ($sha) { $sha.Dispose() }
    }
}

# Returns a hashtable: part name -> SHA256, skipping SharePoint metadata parts.
# For .rels and [Content_Types].xml, entries pointing at injected parts are
# removed and the rest are compared order-independently (Ids ignored).
function Get-OfficeContentHashes {

    param([string]$Path)

    $result = @{}
    $zip    = $null
    $sha    = $null

    try {

        $zip = [System.IO.Compression.ZipFile]::OpenRead($Path)
        $sha = [System.Security.Cryptography.SHA256]::Create()

        foreach ($entry in $zip.Entries) {

            $name = $entry.FullName

            if ($name.EndsWith('/') -or
                $name.StartsWith('customXml/') -or
                $name.StartsWith('docProps/') -or
                $name.StartsWith('[trash]/')) {
                continue
            }

            $stream = $null
            $reader = $null

            try {

                $stream = $entry.Open()

                if ($name.EndsWith('.rels') -or $name -eq '[Content_Types].xml') {

                    $reader = New-Object System.IO.StreamReader($stream)

                    [xml]$xml = $reader.ReadToEnd()

                    $items = @()

                    foreach ($node in $xml.DocumentElement.ChildNodes) {

                        if ($node.NodeType -ne [System.Xml.XmlNodeType]::Element) {
                            continue
                        }

                        $attrs = ($node.Attributes |
                            Where-Object { $_.Name -ne 'Id' } |
                            Sort-Object Name |
                            ForEach-Object { "$($_.Name)=$($_.Value)" }) -join '|'

                        if ($attrs -match $script:InjectedPattern) {
                            continue
                        }

                        $items += "$($node.LocalName)|$attrs"
                    }

                    $result[$name] = Get-StringSHA256 (($items | Sort-Object) -join "`n")
                }
                else {
                    $result[$name] = [BitConverter]::ToString($sha.ComputeHash($stream)) -replace '-'
                }
            }
            finally {
                # Disposing the reader also closes the entry stream;
                # the stream is disposed too in case the reader was never created
                if ($reader) { $reader.Dispose() }
                if ($stream) { $stream.Dispose() }
            }
        }
    }
    finally {
        if ($sha) { $sha.Dispose() }
        if ($zip) { $zip.Dispose() }
    }

    return $result
}

# Returns a list of differences; empty list means content is identical
function Compare-OfficeContent {

    param(
        [string]$Original,
        [string]$Downloaded
    )

    $a = Get-OfficeContentHashes $Original
    $b = Get-OfficeContentHashes $Downloaded

    Write-Log "Office package comparison started"
    Write-Log "Original parts : $($a.Count)"
    Write-Log "Remote parts   : $($b.Count)"

    $problems = @()

    foreach ($k in $a.Keys) {

        if (-not $b.ContainsKey($k)) {
            $problems += "Missing part: $k"
        }
        elseif ($a[$k] -ne $b[$k]) {
            $problems += "Changed part: $k"
        }
    }

    foreach ($k in $b.Keys) {

        if (-not $a.ContainsKey($k)) {
            $problems += "Extra part: $k"
        }
    }

    return $problems
}

Export-ModuleMember -Function `
    Test-IsOfficeFile,
    Get-FileSHA256,
    Get-FileQuickXorHash,
    Get-StringSHA256,
    Get-OfficeContentHashes,
    Compare-OfficeContent
