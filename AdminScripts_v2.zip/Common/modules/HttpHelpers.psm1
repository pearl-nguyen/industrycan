#--------------------------------------------------------------------------
# HttpHelpers.psm1
#   Generic helpers for calling HTTP / REST APIs:
#   URL path encoding, HTTP error classification, throttling (Retry-After,
#   circuit breaker), retry with backoff.
#   Not tied to SharePoint; reusable by any script.
#   Requires Logging.psm1 (Write-Log, Write-LogException) to be imported
#   by the calling script.
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
# THROTTLING STATE (per run)
#   ThrottleEvents : 429/503 responses seen so far
#   ThrottleStop   : set when the server asks for a wait longer than
#                    MaxRetryAfter; the caller should stop and leave the
#                    rest for the next run
#--------------------------------------------------------------------------

$script:ThrottleEvents    = 0
$script:ThrottleStop      = $false
$script:MaxThrottleEvents = 10
$script:MaxRetryAfter     = 300

#--------------------------------------------------------------------------
# PATH / ERROR HELPERS
#   The error patterns match HTTP status forms only ("(409)",
#   "success: Conflict", error codes), never bare words or numbers, so a
#   message that merely contains "conflictBehavior" or a size like 409
#   is not misread.
#--------------------------------------------------------------------------

# URL-encodes each segment of a path so spaces, #, %, accents etc. are safe
function ConvertTo-EncodedPath {

    param([string[]]$Parts)

    $segments = @()

    foreach ($part in $Parts) {

        if ([string]::IsNullOrWhiteSpace($part)) {
            continue
        }

        foreach ($seg in ($part -split '[\\/]')) {

            if ($seg -ne '') {
                $segments += [uri]::EscapeDataString($seg)
            }
        }
    }

    return ($segments -join '/')
}

function Test-IsConflictError {

    param([string]$Message)

    return ($Message -cmatch 'nameAlreadyExists|\(409\)|success: Conflict|Conflict \(Conflict\)')
}

function Test-IsNotFoundError {

    param([string]$Message)

    return ($Message -cmatch 'itemNotFound|\(404\)|success: NotFound|NotFound \(Not Found\)')
}

#--------------------------------------------------------------------------
# THROTTLING
#--------------------------------------------------------------------------

# 429 Too Many Requests / 503 Service Unavailable: the server asks us to slow down
function Test-IsThrottleError {

    param([string]$Message)

    return ($Message -cmatch '\(429\)|\(503\)|TooManyRequests|Too Many Requests|ServiceUnavailable|Service Unavailable|activityLimitReached|throttledRequest')
}

function Test-IsThrottleStatus {

    param([int]$StatusCode)

    return ($StatusCode -eq 429 -or $StatusCode -eq 503)
}

# Sets the circuit breaker limits for this run
function Set-ThrottlePolicy {

    param(
        [int]$MaxEvents = 10,
        [int]$MaxRetryAfter = 300
    )

    $script:MaxThrottleEvents = $MaxEvents
    $script:MaxRetryAfter     = $MaxRetryAfter
    $script:ThrottleEvents    = 0
    $script:ThrottleStop      = $false
}

# Seconds requested by the server's Retry-After header, or $null if absent
function Get-RetryAfterSeconds {

    param($ErrorRecord)

    $response = $null

    try { $response = $ErrorRecord.Exception.Response } catch { }

    if ($response -and $response.Headers) {

        # HttpResponseMessage (Invoke-MgGraphRequest)
        try {
            $ra = $response.Headers.RetryAfter
            if ($ra -and $ra.Delta) {
                return [int][math]::Ceiling($ra.Delta.TotalSeconds)
            }
        }
        catch { }

        # WebResponse (older clients)
        try {
            $value   = @($response.Headers["Retry-After"])[0]
            $seconds = 0
            if ($value -and [int]::TryParse([string]$value, [ref]$seconds)) {
                return $seconds
            }
        }
        catch { }
    }

    if ($ErrorRecord.Exception.Message -match 'Retry-After\D{0,5}(\d+)') {
        return [int]$Matches[1]
    }

    return $null
}

# Records a throttling response. Returns the seconds to wait, or -1 when the
# run should stop (server asked for more than MaxRetryAfter).
function Register-Throttle {

    param(
        [Nullable[int]]$RetryAfter,
        [int]$Attempt,
        [int]$BaseDelay = 5
    )

    $script:ThrottleEvents++

    if ($RetryAfter -gt $script:MaxRetryAfter) {
        $script:ThrottleStop = $true
        Write-Log "Server asked to wait $RetryAfter s (limit $($script:MaxRetryAfter) s); stopping" "WARN"
        return -1
    }

    if ($RetryAfter -gt 0) {
        Write-Log "Throttled by server, honoring Retry-After ($RetryAfter s)" "WARN"
        return [int]$RetryAfter
    }

    $delay = Get-RetryDelay -Attempt $Attempt -BaseDelay $BaseDelay
    Write-Log "Throttled by server (no Retry-After), waiting $delay s" "WARN"

    return $delay
}

# True when the run should stop: too many throttling responses, or a
# Retry-After longer than allowed
function Test-ThrottleLimitReached {

    return ($script:ThrottleStop -or $script:ThrottleEvents -ge $script:MaxThrottleEvents)
}

function Get-ThrottleEventCount {
    return $script:ThrottleEvents
}

#--------------------------------------------------------------------------
# RETRY
#--------------------------------------------------------------------------

# Exponential backoff with jitter: 5-10s, 10-15s, 20-25s, ...
function Get-RetryDelay {

    param(
        [int]$Attempt,
        [int]$BaseDelay = 5
    )

    return [int](($BaseDelay * [math]::Pow(2, $Attempt - 1)) +
                 (Get-Random -Minimum 1 -Maximum 6))
}

# Delay before retrying after an error: the server's Retry-After when it is
# throttling us, exponential backoff otherwise. Returns -1 when the run
# should stop instead of retrying (see Test-ThrottleLimitReached).
function Get-ErrorRetryDelay {

    param(
        $ErrorRecord,
        [int]$Attempt,
        [int]$BaseDelay = 5
    )

    if ($ErrorRecord -and (Test-IsThrottleError $ErrorRecord.Exception.Message)) {

        $delay = Register-Throttle `
            -RetryAfter (Get-RetryAfterSeconds $ErrorRecord) `
            -Attempt $Attempt `
            -BaseDelay $BaseDelay

        if ($delay -lt 0 -or (Test-ThrottleLimitReached)) {
            return -1
        }

        return $delay
    }

    return Get-RetryDelay -Attempt $Attempt -BaseDelay $BaseDelay
}

# Runs a script block with retries. $ShouldRetry receives the error message
# and returns $false for errors that must not be retried (e.g. conflicts).
# Stops retrying early when the throttle limit is reached.
function Invoke-WithRetry {

    param(
        [Parameter(Mandatory = $true)]
        [scriptblock]$ScriptBlock,

        [string]$Activity = "Operation",
        [int]$MaxRetries = 3,
        [int]$BaseDelay = 5,
        [scriptblock]$ShouldRetry = { param($Message) $true }
    )

    for ($attempt = 1; $attempt -le $MaxRetries; $attempt++) {

        try {
            Write-Log "$Activity - attempt $attempt of $MaxRetries"
            return & $ScriptBlock
        }
        catch {

            $err = $_

            if ($attempt -ge $MaxRetries -or -not (& $ShouldRetry $err.Exception.Message)) {
                throw
            }

            Write-LogException $err

            $delay = Get-ErrorRetryDelay -ErrorRecord $err -Attempt $attempt -BaseDelay $BaseDelay

            if ($delay -lt 0) {
                throw
            }

            Write-Log "Retrying in $delay seconds" "WARN"

            Start-Sleep -Seconds $delay
        }
    }
}

Export-ModuleMember -Function `
    ConvertTo-EncodedPath,
    Test-IsConflictError,
    Test-IsNotFoundError,
    Test-IsThrottleError,
    Test-IsThrottleStatus,
    Set-ThrottlePolicy,
    Get-RetryAfterSeconds,
    Register-Throttle,
    Test-ThrottleLimitReached,
    Get-ThrottleEventCount,
    Get-RetryDelay,
    Get-ErrorRetryDelay,
    Invoke-WithRetry
