<#
    SaveSecret.ps1

    Save, list or remove DPAPI-protected passwords on this machine
    (Common\modules\DpapiSecret.psm1). Settings: Secrets section of
    Common\config\EntraApp.psd1.
    Run from an ELEVATED PowerShell ("Run with elevated access").

  SAVE (you are prompted twice for the value)
    .\SaveSecret.ps1 -Name StsSmsOpsCertPfx
    .\SaveSecret.ps1 -Name OracleExport -ReaderObjectIds "<svc-account-object-id>","<team-group-object-id>"
    Saving again with the same name replaces the value (and resets its readers).

  LIST all secrets and who can read them
    .\SaveSecret.ps1 -List

  REMOVE
    .\SaveSecret.ps1 -Remove OracleExport

  LOGGING
    -LogFolder / -LogFileName: optional; not given, lines go to the console.

  EXIT CODES
     0  done
     1  error (details in the log/console)
    99  setup failed (module or config could not be loaded)

  NOTES
    Layout (<root> = parent of this script's folder):
        <root>\Security\SaveSecret.ps1
        <root>\Security\secrets\            (default Secrets.Folder)
        <root>\Common\config\EntraApp.psd1
        <root>\Common\modules\Logging.psm1, ConfigHelpers.psm1, DpapiSecret.psm1
#>

[CmdletBinding()]
param(
    [string]$Name,

    [string[]]$ReaderSids = @(),

    [string[]]$ReaderObjectIds = @(),

    [switch]$List,

    [string]$Remove,

    # Not given: no log file, all lines go to the console (standard output)
    [string]$LogFolder,

    [string]$LogFileName
)

$ErrorActionPreference = "Stop"

$SuccessExitCode    = 0
$ErrorExitCode      = 1
$UnexpectedExitCode = 99

$RootFolder   = Split-Path $PSScriptRoot -Parent
$ModuleFolder = Join-Path $RootFolder "Common\modules"
$ConfigFile   = Join-Path $RootFolder "Common\config\EntraApp.psd1"

#--------------------------------------------------------------------------
# BOOTSTRAP 1: LOGGING (nothing to log to yet -> console, exit 99)
#--------------------------------------------------------------------------

try {
    Import-Module (Join-Path $ModuleFolder "Logging.psm1") -Force -ErrorAction Stop

    # No -LogFolder: console only ($logPath is $null)
    $logPath = Initialize-Log -LogFolder $LogFolder -LogFileName $LogFileName
}
catch {
    [Console]::Out.WriteLine("Bootstrap failed (logging): $($_.Exception.Message)")
    exit $UnexpectedExitCode
}

Write-LogSeparator
Write-Log "SaveSecret started"

if ($logPath) {
    Write-Log "Log file   : $logPath"
}

#--------------------------------------------------------------------------
# BOOTSTRAP 2: MODULES AND CONFIG (exit 99)
#--------------------------------------------------------------------------

try {
    foreach ($module in @("ConfigHelpers", "DpapiSecret")) {
        Import-Module (Join-Path $ModuleFolder "$module.psm1") -Force -ErrorAction Stop
    }

    Import-ConfigFile -Path $ConfigFile -Required "Secrets.Folder", "Secrets.Entropy" | Out-Null

    Write-Log "Config     : $ConfigFile"
    Write-Log "User       : $([Security.Principal.WindowsIdentity]::GetCurrent().Name)"
}
catch {
    Write-LogException $_ "Bootstrap failed"
    Write-Log "Finished with exit code $UnexpectedExitCode"
    Write-LogSeparator
    exit $UnexpectedExitCode
}

function Exit-Script {

    param([int]$Code)

    Write-Log "Finished with exit code $Code"
    Write-LogSeparator

    exit $Code
}

#--------------------------------------------------------------------------
# ACTION
#--------------------------------------------------------------------------

try {
    if ($List) {

        $secrets = @(Get-DpapiSecretList -ConfigPath $ConfigFile)

        if ($secrets.Count -eq 0) {
            Write-Log "No secrets saved"
        }
        else {
            $secrets | Format-Table -AutoSize -Wrap | Out-String -Width 250 | Write-LogLines
        }
    }
    elseif ($Remove) {
        Remove-DpapiSecret -ConfigPath $ConfigFile -Name $Remove
    }
    elseif ($Name) {
        Save-DpapiSecret `
            -ConfigPath $ConfigFile `
            -Name $Name `
            -ReaderSids $ReaderSids `
            -ReaderObjectIds $ReaderObjectIds
    }
    else {
        throw "Provide -Name to save a secret, or use -List / -Remove."
    }
}
catch {
    Write-LogException $_
    Exit-Script $ErrorExitCode
}

Exit-Script $SuccessExitCode
