<#
    InstallCert.ps1

    Manages the Entra app certificate in LocalMachine\My: installs a new
    certificate from a PFX, and controls who can read its private key.
    Subject and PFX password secret come from the Certificate section of
    Common\config\EntraApp.psd1 (-Subject / -PfxSecretName override them).
    Run from an ELEVATED PowerShell ("Run with elevated access"):
        powershell -ExecutionPolicy Bypass -File .\InstallCert.ps1 <options>

  SEE WHO HAS ACCESS
    .\InstallCert.ps1 -ListOnly

  ADD people (certificate already installed)
    .\InstallCert.ps1 -ReaderUpns "jane.doe@ised-isde.gc.ca"
    .\InstallCert.ps1 -ReaderObjectIds "<entra-user-or-group-object-id>"
    .\InstallCert.ps1 -ReaderSids "S-1-12-1-..."

  REMOVE people (left the team / department)
    .\InstallCert.ps1 -RemoveUpns "jane.doe@ised-isde.gc.ca"
    .\InstallCert.ps1 -RemoveSids "S-1-12-1-..."      # use the SID shown by -ListOnly
    (Adding and removing can be combined in one run.)

  NEW CERTIFICATE FROM IT
    1. Save the PFX password (admins-only by default):
         .\SaveSecret.ps1 -Name StsSmsOpsCertPfx
    2. Install: the password is read from DPAPI; current readers are carried over:
         .\InstallCert.ps1 -PfxPath "C:\Ops\Certs\sts.pfx"
    3. Add the new key to the Entra app, put the new thumbprint in
       Common\config\EntraApp.psd1 (Thumbprint), and check that an upload works.
    4. Remove the old certificate:
         .\InstallCert.ps1 -PfxPath "C:\Ops\Certs\sts.pfx" -RemoveOld

  LOGGING
    -LogFolder / -LogFileName: optional; not given, lines go to the console.
    Use a log folder to keep a record of who was granted or removed.

  EXIT CODES
     0  done
     1  error (details in the log/console); nothing after the error was changed
    99  setup failed (module or config could not be loaded)

  NOTES
    - -ReaderUpns / -RemoveUpns only work for people who have signed in to
      this machine. Otherwise use their Entra Object ID, or for removal the
      SID shown by -ListOnly. A deleted account shows only as a SID in
      -ListOnly: remove it with -RemoveSids.
    - Changes apply to EVERY installed certificate with this Subject (old and new).
    - SYSTEM and Administrators can never be removed (prevents lock-out).
    - Only certificates whose Subject EXACTLY matches are ever deleted, and
      only with -RemoveOld plus typing YES.

    Layout (<root> = parent of this script's folder):
        <root>\Security\InstallCert.ps1
        <root>\Common\config\EntraApp.psd1
        <root>\Common\modules\Logging.psm1, ConfigHelpers.psm1, DpapiSecret.psm1
#>

[CmdletBinding()]
param(
    [string]$PfxPath,

    # Default: Certificate.Subject in EntraApp.psd1
    [string]$Subject,

    # Default: Certificate.PfxSecretName in EntraApp.psd1
    [string]$PfxSecretName,

    [string[]]$ReaderUpns      = @(),
    [string[]]$ReaderObjectIds = @(),
    [string[]]$ReaderSids      = @(),

    [string[]]$RemoveUpns      = @(),
    [string[]]$RemoveObjectIds = @(),
    [string[]]$RemoveSids      = @(),

    [switch]$RemoveOld,

    [switch]$ListOnly,

    # Not given: no log file, all lines go to the console (standard output)
    [string]$LogFolder,

    [string]$LogFileName
)

$ErrorActionPreference = "Stop"

$SuccessExitCode    = 0
$ErrorExitCode      = 1
$UnexpectedExitCode = 99

$RootFolder   = Split-Path $PSScriptRoot -Parent
$ModuleFolder = Join-Path $RootFolder "Common\modules"
$ConfigFile   = Join-Path $RootFolder "Common\config\EntraApp.psd1"

$ConfigRequired = @(
    "Thumbprint",
    "Certificate.Subject",
    "Certificate.PfxSecretName",
    "Secrets.Folder",
    "Secrets.Entropy"
)

$ProtectedSids = @("S-1-5-18", "S-1-5-32-544")   # SYSTEM, Administrators

#--------------------------------------------------------------------------
# BOOTSTRAP 1: LOGGING (nothing to log to yet -> console, exit 99)
#--------------------------------------------------------------------------

try {
    Import-Module (Join-Path $ModuleFolder "Logging.psm1") -Force -ErrorAction Stop

    # No -LogFolder: console only ($logPath is $null)
    $logPath = Initialize-Log -LogFolder $LogFolder -LogFileName $LogFileName
}
catch {
    [Console]::Out.WriteLine("Bootstrap failed (logging): $($_.Exception.Message)")
    exit $UnexpectedExitCode
}

Write-LogSeparator
Write-Log "InstallCert started"

if ($logPath) {
    Write-Log "Log file   : $logPath"
}

#--------------------------------------------------------------------------
# BOOTSTRAP 2: MODULES AND CONFIG (exit 99)
#--------------------------------------------------------------------------

try {
    foreach ($module in @("ConfigHelpers", "DpapiSecret")) {
        Import-Module (Join-Path $ModuleFolder "$module.psm1") -Force -ErrorAction Stop
    }

    $Config = Import-ConfigFile -Path $ConfigFile -Required $ConfigRequired

    if ([string]::IsNullOrWhiteSpace($Subject)) {
        $Subject = $Config.Certificate.Subject
    }

    if ([string]::IsNullOrWhiteSpace($PfxSecretName)) {
        $PfxSecretName = $Config.Certificate.PfxSecretName
    }

    Write-Log "Config     : $ConfigFile"
    Write-Log "User       : $([Security.Principal.WindowsIdentity]::GetCurrent().Name)"
    Write-Log "Subject    : $Subject"
}
catch {
    Write-LogException $_ "Bootstrap failed"
    Write-Log "Finished with exit code $UnexpectedExitCode"
    Write-LogSeparator
    exit $UnexpectedExitCode
}

function Exit-Script {

    param([int]$Code)

    Write-Log "Finished with exit code $Code"
    Write-LogSeparator

    exit $Code
}

#--------------------------------------------------------------------------
# HELPERS
#--------------------------------------------------------------------------

function Resolve-UpnToSid {

    param([string]$Upn)

    try {
        return ([Security.Principal.NTAccount]"AzureAD\$Upn").Translate([Security.Principal.SecurityIdentifier]).Value
    }
    catch {
        throw "Cannot resolve '$Upn'. Use their Entra Object ID, or (to remove) the SID shown by -ListOnly."
    }
}

function Resolve-AllSids {

    param([string[]]$Sids, [string[]]$ObjectIds, [string[]]$Upns)

    $out  = @()
    $out += $Sids
    $out += $ObjectIds | ForEach-Object { ConvertTo-EntraSid $_ }
    $out += $Upns      | ForEach-Object { Resolve-UpnToSid $_ }

    return @($out | Where-Object { $_ } | Select-Object -Unique)
}

function Get-KeyPath {

    param($Cert)

    $rsa  = [System.Security.Cryptography.X509Certificates.RSACertificateExtensions]::GetRSAPrivateKey($Cert)
    $path = Get-ChildItem "$env:ProgramData\Microsoft\Crypto\Keys" -Filter $rsa.Key.UniqueName -ErrorAction SilentlyContinue |
            Select-Object -First 1 -ExpandProperty FullName

    if (-not $path) {
        throw "Private key file not found for $($Cert.Thumbprint) (TPM key?)."
    }

    return $path
}

function Get-InstalledCerts {

    return @(Get-ChildItem Cert:\LocalMachine\My -ErrorAction Stop |
             Where-Object { $_.Subject -eq $Subject -and $_.HasPrivateKey } |
             Sort-Object NotAfter -Descending)
}

# Users/groups (not SYSTEM/Administrators) currently allowed on the key
function Get-ReaderSids {

    param($Cert)

    (Get-Acl -LiteralPath (Get-KeyPath $Cert) -ErrorAction Stop).Access |
        Where-Object { $_.AccessControlType -eq "Allow" } |
        ForEach-Object { try { $_.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value } catch { } } |
        Where-Object { $_ -like "S-1-12-1-*" -or $_ -like "S-1-5-21-*" } |
        Select-Object -Unique
}

function Show-Access {

    param($Certs)

    foreach ($c in $Certs) {

        Write-Log "$($c.Subject)  $($c.Thumbprint)  expires $($c.NotAfter.ToString('yyyy-MM-dd'))"

        (Get-Acl -LiteralPath (Get-KeyPath $c) -ErrorAction Stop).Access | ForEach-Object {

            $sid  = try { $_.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value }
                    catch { "$($_.IdentityReference)" }
            $name = try { ([Security.Principal.SecurityIdentifier]$sid).Translate([Security.Principal.NTAccount]).Value }
                    catch { "(unknown - left or never signed in here)" }

            [pscustomobject]@{ Name = $name; SID = $sid; Rights = $_.FileSystemRights; Type = $_.AccessControlType }

        } | Format-Table -AutoSize | Out-String -Width 250 | Write-LogLines
    }
}

function Grant-Readers {

    param($Certs, [string[]]$Sids)

    foreach ($c in $Certs) {

        $path = Get-KeyPath $c

        foreach ($sid in $Sids) {

            $r = & icacls "$path" /grant "*$($sid):R" 2>&1

            if ($LASTEXITCODE -ne 0) {
                throw "icacls grant failed for $sid on $($c.Thumbprint):`n$r"
            }

            Write-Log "Granted read : $sid  ->  $($c.Thumbprint)"
        }
    }
}

function Remove-Readers {

    param($Certs, [string[]]$Sids)

    foreach ($sid in $Sids) {

        if ($ProtectedSids -contains $sid) {
            Write-Log "Skipping $sid (SYSTEM/Administrators cannot be removed)" "WARN"
            continue
        }

        foreach ($c in $Certs) {

            $r = & icacls (Get-KeyPath $c) /remove "*$sid" 2>&1

            if ($LASTEXITCODE -ne 0) {
                throw "icacls remove failed for $sid on $($c.Thumbprint):`n$r"
            }

            Write-Log "Removed      : $sid  <-  $($c.Thumbprint)"
        }
    }
}

# Installs a new certificate from the PFX and carries the readers over
function Install-FromPfx {

    if (-not (Test-Path -LiteralPath $PfxPath -PathType Leaf)) {
        throw "PFX not found: $PfxPath"
    }

    # Stops with a clear message if the password was not saved yet
    $securePw = Get-DpapiSecret -ConfigPath $ConfigFile -Name $PfxSecretName

    Write-Log "Using PFX password from secret '$PfxSecretName'"

    $pfxCert = (Get-PfxData -FilePath $PfxPath -Password $securePw -ErrorAction Stop).EndEntityCertificates |
               Select-Object -First 1

    if (-not $pfxCert) {
        throw "No certificate found in the PFX (or wrong password)."
    }

    if ($pfxCert.Subject -ne $Subject) {
        throw "PFX subject is '$($pfxCert.Subject)', expected '$Subject'. Wrong file? Nothing was changed."
    }

    $newThumb = $pfxCert.Thumbprint

    Write-Log "PFX OK     : $Subject  thumbprint $newThumb  valid until $($pfxCert.NotAfter.ToString('yyyy-MM-dd'))"

    if (Test-Path "Cert:\LocalMachine\My\$newThumb") {
        Write-Log "This certificate is already installed; import skipped" "WARN"
    }
    else {
        $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePw)

        try {
            $plainPw = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)

            $out = & certutil -f -p $plainPw -csp "Microsoft Software Key Storage Provider" -importpfx My "$PfxPath" NoExport 2>&1

            if ($LASTEXITCODE -ne 0) {
                throw "certutil import failed (check the password):`n$out"
            }
        }
        finally {
            $plainPw = $null
            [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
        }

        Write-Log "Imported"
    }

    $newCert = Get-Item "Cert:\LocalMachine\My\$newThumb" -ErrorAction Stop

    if (-not $newCert.HasPrivateKey) {
        throw "Imported certificate has no private key."
    }

    $provider = (& certutil -store My $newThumb | Select-String "Provider") -join " "

    if ($provider -notmatch "Software Key Storage Provider") {
        throw "Key is not in the software provider ($provider). It may have gone to the TPM."
    }

    # Carry over everyone who can read the old certificate(s), minus anyone being removed
    $oldCerts = @(Get-InstalledCerts | Where-Object { $_.Thumbprint -ne $newThumb })
    $inherit  = @($oldCerts | ForEach-Object { Get-ReaderSids $_ })
    $toGrant  = @(@($addSids) + @($inherit) |
                  Where-Object { $_ -and ($removeSids -notcontains $_) } |
                  Select-Object -Unique)

    if ($toGrant.Count -gt 0) {
        Grant-Readers @($newCert) $toGrant
    }
    else {
        Write-Log "No readers given or carried over: only administrators can use the new key" "WARN"
    }

    if ($removeSids.Count -gt 0) {
        Remove-Readers (Get-InstalledCerts) $removeSids
    }

    Show-Access @($newCert)

    if ($oldCerts.Count -gt 0) {

        Write-Log "Older certificates with the same subject:"
        $oldCerts | Format-Table Thumbprint, NotAfter -AutoSize | Out-String -Width 250 | Write-LogLines

        if ($RemoveOld) {

            $answer = Read-Host "Delete these $($oldCerts.Count) old certificate(s)? Type YES to confirm"

            if ($answer -ceq "YES") {
                foreach ($old in $oldCerts) {
                    Remove-Item "Cert:\LocalMachine\My\$($old.Thumbprint)" -DeleteKey -ErrorAction Stop
                    Write-Log "Deleted old certificate $($old.Thumbprint)"
                }
            }
            else {
                Write-Log "Deletion of old certificates skipped (not confirmed)"
            }
        }
        else {
            Write-Log "Old certificates kept. Re-run with -RemoveOld after the new key is in the Entra app and an upload has worked."
        }
    }

    Write-Log "Active (newest) thumbprint: $newThumb"

    if ($Config.Thumbprint -ne $newThumb) {
        Write-Log "EntraApp.psd1 still has Thumbprint $($Config.Thumbprint). Update it to $newThumb once the new key is in the Entra app." "WARN"
    }
}

#--------------------------------------------------------------------------
# START
#--------------------------------------------------------------------------

try {
    Assert-Elevated

    $addSids    = Resolve-AllSids $ReaderSids $ReaderObjectIds $ReaderUpns
    $removeSids = Resolve-AllSids $RemoveSids $RemoveObjectIds $RemoveUpns

    if ($ListOnly) {

        $certs = Get-InstalledCerts

        if ($certs.Count -eq 0) {
            throw "No certificate with subject '$Subject' and a private key is installed."
        }

        Show-Access $certs
    }
    elseif ($PfxPath) {
        Install-FromPfx
    }
    else {
        # Certificate already installed: add / remove readers
        if ($addSids.Count -eq 0 -and $removeSids.Count -eq 0) {

            if ($RemoveOld) {
                throw "-RemoveOld is only used together with -PfxPath."
            }

            throw "Nothing to do. Use -ReaderUpns/-ReaderObjectIds/-ReaderSids, -RemoveUpns/-RemoveObjectIds/-RemoveSids, -PfxPath or -ListOnly."
        }

        $certs = Get-InstalledCerts

        if ($certs.Count -eq 0) {
            throw "No certificate with subject '$Subject' and a private key is installed. Use -PfxPath to install one."
        }

        if ($addSids.Count -gt 0) {
            Grant-Readers $certs $addSids
        }

        if ($removeSids.Count -gt 0) {
            Remove-Readers $certs $removeSids
        }

        Show-Access $certs
    }
}
catch {
    Write-LogException $_
    Exit-Script $ErrorExitCode
}

Exit-Script $SuccessExitCode
