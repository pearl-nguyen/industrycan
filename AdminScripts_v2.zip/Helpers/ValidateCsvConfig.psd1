#--------------------------------------------------------------------------
# ValidateCsvConfig.psd1
#   Settings for Helpers\ValidateCsv.ps1
#--------------------------------------------------------------------------

@{
    #----------------------------------------------------------------------
    # Exit codes returned to the calling job: one per CsvValidationResult
    # value (CsvValidation.psm1), plus UnexpectedError. Every result name
    # must be listed; the script checks this at start.
    # A failure before this file is loaded (modules, this config itself)
    # also exits with 99.
    #----------------------------------------------------------------------
    ExitCodes = @{
        Success             = 0
        RowCountMismatch    = 1
        ColumnCountMismatch = 2    # header column count, or empty file
        MalformedRecord     = 3    # bad quoting or wrong field count
        InvalidHeader       = 4    # blank or duplicate column names
        UnexpectedError     = 99   # missing file or any other error
    }
}
