#--------------------------------------------------------------------------
# Logging.psm1
#   Log file: <LogFolder>\<LogFileName>.log
#   The calling job passes its own log folder/name so all lines land in the
#   job's log. Defaults when not given:
#     LogFolder   : <folder of the calling script>\logs
#     LogFileName : yyyyMMdd_HHmmss (start time)
#
#   If the log file can't be written (for example, the calling batch file
#   holds it open with >> "%LOG%"), the line goes to stdout instead
#   ([Console]::Out), so the batch redirect still captures it.
#--------------------------------------------------------------------------

$script:LogFile            = $null
$script:TimestampFormat    = "yyyy-MM-dd HH:mm:ss"
$script:Separator          = "=" * 52
$script:LogExtension       = ".log"
$script:DefaultLogFileName = Get-Date -Format 'yyyyMMdd_HHmmss'

# Creates the log folder if needed and sets the log file.
# Without -LogFolder, uses <folder of the calling script>\logs (the current
# directory when called interactively, outside any script).
# Returns the full path of the log file; the caller can take its folder
# with Split-Path -Parent.
function Initialize-Log {

    param(
        [string]$LogFolder,

        [string]$LogFileName
    )

    if ([string]::IsNullOrWhiteSpace($LogFolder)) {

        # First frame on the call stack that is a script other than this module
        $caller = Get-PSCallStack |
            Where-Object { $_.ScriptName -and $_.ScriptName -ne $PSCommandPath } |
            Select-Object -First 1

        if ($caller) {
            $baseFolder = Split-Path -Path $caller.ScriptName -Parent
        }
        else {
            $baseFolder = (Get-Location).ProviderPath
        }

        $LogFolder = Join-Path -Path $baseFolder -ChildPath "logs"
    }

    if (-not (Test-Path -LiteralPath $LogFolder -PathType Container)) {
        # -WhatIf:$false: logging must still happen when the caller runs with -WhatIf
        New-Item -ItemType Directory -Path $LogFolder -Force -WhatIf:$false -ErrorAction Stop | Out-Null
    }

    if ([string]::IsNullOrWhiteSpace($LogFileName)) {
        $LogFileName = $script:DefaultLogFileName
    }

    $script:LogFile = Join-Path -Path $LogFolder -ChildPath "$LogFileName$script:LogExtension"

    return $script:LogFile
}

function Write-Log {

    param(
        [Parameter(Position = 0)]
        [AllowEmptyString()]
        [string]$Message,

        [Parameter(Position = 1)]
        [ValidateSet("INFO", "WARN", "ERROR")]
        [string]$Level = "INFO"
    )

    $line = "{0} [{1}] {2}" -f (Get-Date -Format $script:TimestampFormat), $Level, $Message

    if ($script:LogFile) {
        try {
            Add-Content -LiteralPath $script:LogFile -Value $line -Encoding UTF8 -ErrorAction Stop -WhatIf:$false
            return
        }
        catch {
            # Fall through to the console
        }
    }

    # Not Write-Host: a batch >> redirect may not capture it.
    # Not Write-Output: it would become part of the calling function's return value.
    [Console]::Out.WriteLine($line)
}

function Write-LogSeparator {
    Write-Log $script:Separator
}

# Accepts an ErrorRecord ($_), an Exception, or a message string.
# Logs the message, exception type, every inner exception and, for an
# ErrorRecord, the failing line and the PowerShell stack trace.
# Pass $_ (not $_.Exception) to get the line number and stack trace.
function Write-LogException {

    param(
        [Parameter(Position = 0)]
        $Exception,

        [Parameter(Position = 1)]
        [string]$Context
    )

    $record = $null

    if ($Exception -is [System.Management.Automation.ErrorRecord]) {
        $record    = $Exception
        $Exception = $record.Exception
    }

    if ($Exception -is [System.Exception]) {

        $msg = "$($Exception.Message) [$($Exception.GetType().FullName)]"
        if ($Context) { $msg = "${Context}: $msg" }
        Write-Log $msg "ERROR"

        # Inner exceptions, skipping ones that only repeat the message above
        $last  = $Exception.Message
        $inner = $Exception.InnerException

        while ($inner) {
            if ($inner.Message -ne $last) {
                Write-Log "  Inner: $($inner.Message) [$($inner.GetType().FullName)]" "ERROR"
                $last = $inner.Message
            }
            $inner = $inner.InnerException
        }

        if ($record) {

            # "At C:\...\script.ps1:12 char:5" plus the failing line
            if ($record.InvocationInfo -and $record.InvocationInfo.PositionMessage) {
                foreach ($l in ($record.InvocationInfo.PositionMessage -split "`r?`n")) {
                    if ($l.Trim()) { Write-Log "  $l" "ERROR" }
                }
            }

            if ($record.ScriptStackTrace) {
                Write-Log "  Stack trace:" "ERROR"
                foreach ($l in ($record.ScriptStackTrace -split "`r?`n")) {
                    if ($l.Trim()) { Write-Log "    $l" "ERROR" }
                }
            }
        }
    }
    else {
        $msg = [string]$Exception
        if ($Context) { $msg = "${Context}: $msg" }
        Write-Log $msg "ERROR"
    }
}

Export-ModuleMember -Function `
    Initialize-Log,
    Write-Log,
    Write-LogSeparator,
    Write-LogException
