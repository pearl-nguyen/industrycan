#--------------------------------------------------------------------------
# SpTransfer.psm1
#   High-level SharePoint transfers built on SpGraph:
#     - Publish-SpFile : one file through staging -> validate -> target,
#                        skipping files already uploaded
#     - Receive-SpFile : one file downloaded to a temp name, validated,
#                        then renamed into place
#     - Target index   : one listing of the target folder per pass instead
#                        of one lookup per file
#     - Staging cleanup: removes copies abandoned by killed runs
#     - Manifest       : local JSON record of what was uploaded, so a run
#                        can resume and Office files (changed by SharePoint)
#                        are not re-uploaded
#   Requires Logging, HttpHelpers, SpGraph and FileValidation to be
#   imported by the calling script.
#--------------------------------------------------------------------------

$script:ManifestVersion = 1

# Staged names: yyyyMMddHHmmss_<8 hex>_<file name>
$script:StagedNamePattern = '^(\d{14})_[0-9a-f]{8}_'

#--------------------------------------------------------------------------
# RESULT
#--------------------------------------------------------------------------

# Status values (upload):
#   Uploaded        validated and moved to the target folder
#   Skipped         target already has this exact file
#   FileExists      target has a different file and Overwrite is $false
#   InvalidFileName SharePoint does not allow this name (not retried)
#   UploadFailed    upload or validation failed after all retries
#   MoveFailed      validated but could not be moved from staging
# Status values (download):
#   Downloaded, AlreadyCurrent, FileExists, DownloadFailed, LocalWriteFailed
function New-SpTransferResult {

    param([string]$FileName)

    return [pscustomobject]@{
        FileName   = $FileName
        Status     = $null
        Message    = $null
        LocalPath  = $null
        LocalSize  = $null
        LocalHash  = $null
        RemoteHash = $null
        ItemId     = $null
        WebUrl     = $null
    }
}

# Removes our own staging copy. Safe: the name is unique to this run,
# so no other file or version history is affected.
function Remove-SpStagedItem {

    param(
        [string]$DriveId,
        $Item
    )

    if (-not $Item -or -not $Item.id) {
        return
    }

    try {
        Remove-SpItem -DriveId $DriveId -ItemId $Item.id
        Write-Log "Staging copy removed: $($Item.name)"
    }
    catch {
        Write-Log "Could not remove staging copy: $($Item.name)" "WARN"
        Write-LogException $_
    }
}

#--------------------------------------------------------------------------
# TARGET INDEX / STAGING CLEANUP
#--------------------------------------------------------------------------

# Lists the target folder once and returns a hashtable: file name -> item
# (names are case-insensitive, like SharePoint)
function New-SpTargetIndex {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [Parameter(Mandatory = $true)][string]$FolderId
    )

    $index = @{}

    foreach ($item in (Get-SpChildren -DriveId $DriveId -FolderId $FolderId)) {
        if ($item.file) {
            $index[$item.name] = $item
        }
    }

    return $index
}

# Deletes staged copies older than MaxAgeDays. Only names created by this
# module (timestamp_hex_name) are touched, so other files are never removed.
# The age comes from the timestamp in the name. Failures are only logged.
function Clear-SpStaging {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [Parameter(Mandatory = $true)][string]$StagingFolderId,
        [int]$MaxAgeDays = 2
    )

    $cutoff  = (Get-Date).AddDays(-$MaxAgeDays)
    $removed = 0

    try {
        $children = Get-SpChildren -DriveId $DriveId -FolderId $StagingFolderId
    }
    catch {
        Write-Log "Could not list staging folder for cleanup" "WARN"
        Write-LogException $_
        return
    }

    foreach ($item in $children) {

        if (-not $item.file -or $item.name -notmatch $script:StagedNamePattern) {
            continue
        }

        $stamp = [datetime]::MinValue

        if (-not [datetime]::TryParseExact($Matches[1], "yyyyMMddHHmmss",
                [System.Globalization.CultureInfo]::InvariantCulture,
                [System.Globalization.DateTimeStyles]::None, [ref]$stamp)) {
            continue
        }

        if ($stamp -ge $cutoff) {
            continue
        }

        try {
            Remove-SpItem -DriveId $DriveId -ItemId $item.id
            $removed++
            Write-Log "Old staging copy removed: $($item.name)"
        }
        catch {
            Write-Log "Could not remove old staging copy: $($item.name)" "WARN"
            Write-LogException $_
        }
    }

    if ($removed -gt 0) {
        Write-Log "Staging cleanup: $removed old copy(ies) removed"
    }
}

#--------------------------------------------------------------------------
# PUBLISH ONE FILE
#--------------------------------------------------------------------------

# Uploads one local file to the target folder through the staging folder.
# Never deletes or changes a file in the target folder unless it replaces
# it with a fully validated copy. Returns a result object (see above).
#
# Settings (from the script's config): MaxRetries, BaseDelay, SettleDelay,
# HashReadAttempts, SimpleUploadLimitMB
#
# TargetIndex: hashtable from New-SpTargetIndex. Without it, the target is
# looked up by path for this file.
function Publish-SpFile {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [Parameter(Mandatory = $true)][string]$LocalFile,
        [Parameter(Mandatory = $true)][string]$TargetFolder,
        [Parameter(Mandatory = $true)][string]$TargetFolderId,
        [Parameter(Mandatory = $true)][string]$StagingFolder,
        [bool]$Overwrite = $true,
        [Parameter(Mandatory = $true)][System.Collections.IDictionary]$Settings,

        [hashtable]$TargetIndex,

        # Entry from the manifest for this file name, or $null
        $ManifestEntry
    )

    $maxRetries = [int]$Settings.MaxRetries
    $baseDelay  = [int]$Settings.BaseDelay

    $fileName  = Split-Path $LocalFile -Leaf
    $extension = [System.IO.Path]::GetExtension($fileName).ToLower()
    $result    = New-SpTransferResult $fileName

    $result.LocalPath = $LocalFile

    Write-Log "File       : $fileName"

    #----------------------------------------------------------------------
    # NAME ALLOWED? (not retried: it would fail every time)
    #----------------------------------------------------------------------

    $nameProblem = Test-SpFileName $fileName

    if ($nameProblem) {
        $result.Status  = "InvalidFileName"
        $result.Message = "File name $nameProblem"
        Write-Log $result.Message "ERROR"
        return $result
    }

    $localSize = (Get-Item -LiteralPath $LocalFile -ErrorAction Stop).Length
    $localHash = Get-FileQuickXorHash $LocalFile
    $isOffice  = Test-IsOfficeFile $LocalFile

    $result.LocalSize = $localSize
    $result.LocalHash = $localHash

    Write-Log "Size       : $localSize"
    Write-Log "QuickXor   : $localHash"

    #----------------------------------------------------------------------
    # ALREADY UPLOADED?
    #----------------------------------------------------------------------

    if ($null -ne $TargetIndex) {
        $existing = $TargetIndex[$fileName]
    }
    else {
        $existing = Invoke-WithRetry `
            -Activity "Check target" `
            -MaxRetries $maxRetries `
            -BaseDelay $baseDelay `
            -ScriptBlock {
                Get-SpItemByPath -DriveId $DriveId -PathParts @($TargetFolder, $fileName)
            }
    }

    if ($existing) {

        $existingHash = Get-SpItemQuickXorHash $existing

        $result.RemoteHash = $existingHash
        $result.ItemId     = $existing.id
        $result.WebUrl     = $existing.webUrl

        # Same bytes on SharePoint
        if ($existingHash -and $existing.size -eq $localSize -and $existingHash -ceq $localHash) {
            $result.Status  = "Skipped"
            $result.Message = "Identical file already in target"
            Write-Log "Skipped: identical file already in target"
            return $result
        }

        # Office file changed by SharePoint on upload: the manifest says we
        # uploaded this exact local content and nobody changed it since
        if ($ManifestEntry -and $existingHash -and
            $ManifestEntry.LocalHash -ceq $localHash -and
            $ManifestEntry.RemoteHash -ceq $existingHash) {
            $result.Status  = "Skipped"
            $result.Message = "Unchanged since last upload (manifest)"
            Write-Log "Skipped: unchanged since last upload (manifest)"
            return $result
        }

        if (-not $Overwrite) {
            $result.Status  = "FileExists"
            $result.Message = "Different file already in target and overwrite is off"
            Write-Log "Different file already in target and overwrite is off; not uploaded" "ERROR"
            return $result
        }

        Write-Log "Target has different content and will be replaced"

        $result.RemoteHash = $null
        $result.ItemId     = $null
        $result.WebUrl     = $null
    }

    #----------------------------------------------------------------------
    # UPLOAD TO STAGING + VALIDATE (with retries)
    #----------------------------------------------------------------------

    # Unique staging name so concurrent jobs never collide in staging.
    # Clear-SpStaging relies on this format.
    $runId       = "{0}_{1}" -f (Get-Date -Format "yyyyMMddHHmmss"),
                                ([guid]::NewGuid().ToString("N").Substring(0, 8))
    $stagingName = "${runId}_$fileName"
    $stagingPath = ConvertTo-EncodedPath @($StagingFolder, $stagingName)

    Write-Log "Staging    : /$($StagingFolder.Trim('/\'))/$stagingName"

    $stagedItem    = $null
    $validatedHash = $null
    $validated     = $false
    $lastMessage   = $null
    $attemptsMade  = 0

    for ($attempt = 1; $attempt -le $maxRetries; $attempt++) {

        $attemptsMade = $attempt
        $tempFile  = $null
        $lastError = $null

        try {

            Write-Log "Upload attempt $attempt of $maxRetries"

            # Staging name is ours alone, so replace is always safe here
            $stagedItem = Send-SpFile `
                -DriveId $DriveId `
                -ItemPath $stagingPath `
                -Path $LocalFile `
                -ConflictBehavior "replace" `
                -MaxRetries $maxRetries `
                -BaseDelay $baseDelay `
                -SimpleUploadLimit ([long]$Settings.SimpleUploadLimitMB * 1MB)

            # Log only safe fields (the full result contains a pre-authenticated
            # download URL that must not be written to logs)
            Write-Log "Upload Id   : $($stagedItem.id)"
            Write-Log "Upload Size : $($stagedItem.size)"

            #--------------------------------------------------------------
            # REMOTE SIZE + HASH (no download)
            #   Non-Office: the upload response usually already carries the
            #   hash; if it matches, no wait and no extra request.
            #   Office: always wait SettleDelay first, so the hash read is
            #   the one AFTER SharePoint's metadata injection (that is the
            #   hash the manifest must record).
            #--------------------------------------------------------------

            $remoteItem = $stagedItem
            $remoteHash = Get-SpItemQuickXorHash $stagedItem

            $identical = ($remoteHash -and
                          $remoteItem.size -eq $localSize -and
                          $remoteHash -ceq $localHash)

            if ($isOffice -or -not $identical) {

                Start-Sleep -Seconds $Settings.SettleDelay

                for ($read = 1; $read -le $Settings.HashReadAttempts; $read++) {

                    $remoteItem = Get-SpItem -DriveId $DriveId -ItemId $stagedItem.id
                    $remoteHash = Get-SpItemQuickXorHash $remoteItem

                    if ($remoteHash) {
                        break
                    }

                    if ($read -lt $Settings.HashReadAttempts) {
                        Write-Log "Remote hash not available yet, re-reading in $($Settings.SettleDelay) seconds" "WARN"
                        Start-Sleep -Seconds $Settings.SettleDelay
                    }
                }

                if (-not $remoteItem -or -not $remoteItem.id) {
                    throw "Remote file not found"
                }

                # Base64 is case-sensitive: -ceq
                $identical = ($remoteHash -and
                              $remoteItem.size -eq $localSize -and
                              $remoteHash -ceq $localHash)
            }

            Write-Log "Remote Size     : $($remoteItem.size)"
            Write-Log "Remote QuickXor : $remoteHash"

            #--------------------------------------------------------------
            # VALIDATE
            #--------------------------------------------------------------

            if ($identical) {
                Write-Log "Size and QuickXorHash identical"
            }
            elseif (-not $isOffice) {

                if (-not $remoteHash) {
                    throw "Remote QuickXorHash not available after $($Settings.HashReadAttempts) reads"
                }

                throw "Validation failed (local size $localSize, remote size $($remoteItem.size); hashes differ)"
            }
            else {

                # SharePoint changed the Office file (metadata) or has no hash
                # yet: download and compare the content parts
                Write-Log "Office file differs from local copy (SharePoint metadata expected); comparing content" "WARN"

                $tempFile = Join-Path `
                    ([System.IO.Path]::GetTempPath()) `
                    ("sp_" + [guid]::NewGuid().ToString("N") + $extension)

                Save-SpItemContent -DriveId $DriveId -ItemId $remoteItem.id -OutFile $tempFile

                try {
                    $diffs = @(Compare-OfficeContent $LocalFile $tempFile)
                }
                catch {
                    throw "Downloaded file is not a valid Office package: $($_.Exception.Message)"
                }

                foreach ($d in $diffs) {
                    Write-Log $d "ERROR"
                }

                if ($diffs.Count -gt 0) {
                    throw "Content validation failed"
                }

                Write-Log "Content parts identical (SharePoint metadata ignored)"

                Remove-Item -LiteralPath $tempFile -Force -ErrorAction SilentlyContinue
                $tempFile = $null
            }

            $validatedHash = $remoteHash
            $validated     = $true

            Write-Log "Remote file validation successful"

            break
        }
        catch {

            $lastError   = $_
            $lastMessage = $_.Exception.Message

            Write-LogException $_

            if ($tempFile -and (Test-Path -LiteralPath $tempFile)) {
                Write-Log "Downloaded copy kept for inspection: $tempFile" "WARN"
            }
        }

        if ($attempt -lt $maxRetries) {

            $delay = Get-ErrorRetryDelay -ErrorRecord $lastError -Attempt $attempt -BaseDelay $baseDelay

            # Throttle limit reached: stop retrying, leave it for later
            if ($delay -lt 0 -or (Test-ThrottleLimitReached)) {
                $lastMessage = "stopped by throttling limit ($lastMessage)"
                break
            }

            Write-Log "Retrying in $delay seconds" "WARN"

            Start-Sleep -Seconds $delay
        }
    }

    if (-not $validated) {

        # The invalid copy is only in staging; the target was never touched
        Remove-SpStagedItem -DriveId $DriveId -Item $stagedItem

        $result.Status  = "UploadFailed"
        $result.Message = "Upload failed after $attemptsMade attempt(s): $lastMessage"

        Write-Log $result.Message "ERROR"

        return $result
    }

    #----------------------------------------------------------------------
    # MOVE FROM STAGING TO TARGET
    #----------------------------------------------------------------------

    $behavior = if ($Overwrite) { "replace" } else { "fail" }

    try {

        $moved = Invoke-WithRetry `
            -Activity "Move to target" `
            -MaxRetries $maxRetries `
            -BaseDelay $baseDelay `
            -ShouldRetry { param($m) -not (Test-IsConflictError $m) } `
            -ScriptBlock {
                Move-SpItem `
                    -DriveId $DriveId `
                    -ItemId $stagedItem.id `
                    -DestinationFolderId $TargetFolderId `
                    -NewName $fileName `
                    -ConflictBehavior $behavior
            }
    }
    catch {

        $message = $_.Exception.Message

        Write-LogException $_

        Remove-SpStagedItem -DriveId $DriveId -Item $stagedItem

        # Someone created the target file between the check and the move
        if ((Test-IsConflictError $message) -and (-not $Overwrite)) {
            $result.Status  = "FileExists"
            $result.Message = "File appeared in target during upload and overwrite is off"
        }
        else {
            $result.Status  = "MoveFailed"
            $result.Message = "Move from staging to target failed: $message"
        }

        Write-Log $result.Message "ERROR"

        return $result
    }

    #----------------------------------------------------------------------
    # FINAL ITEM (for the log and the manifest)
    #----------------------------------------------------------------------

    $result.Status     = "Uploaded"
    $result.Message    = "Uploaded and validated"
    $result.ItemId     = $moved.id
    $result.RemoteHash = $validatedHash
    $result.WebUrl     = $moved.webUrl

    # A move doesn't change content, so the validated hash is the final one;
    # read the item only if the move response lacks the URL
    if (-not $result.WebUrl) {
        try {
            $finalItem     = Get-SpItem -DriveId $DriveId -ItemId $moved.id
            $result.WebUrl = $finalItem.webUrl
        }
        catch {
            # The file is in place; only the URL is missing from the log
            Write-Log "Uploaded, but could not read the final item URL" "WARN"
        }
    }

    Write-Log "Final Id    : $($result.ItemId)"
    Write-Log "Final Url   : $($result.WebUrl)"
    Write-Log "Upload complete: $fileName"

    return $result
}

#--------------------------------------------------------------------------
# RECEIVE ONE FILE
#--------------------------------------------------------------------------

# True for local file system errors that will fail the same way on every
# retry: access denied, disk full. Network errors (also IOExceptions) are
# not matched.
function Test-IsLocalWriteError {

    param($Exception)

    # 0x80070070 ERROR_DISK_FULL, 0x80070027 ERROR_HANDLE_DISK_FULL
    $diskFull = @(-2147024784, -2147024857)

    $e = $Exception

    while ($e) {

        if ($e -is [System.UnauthorizedAccessException]) {
            return $true
        }

        if ($e -is [System.IO.IOException] -and $diskFull -contains $e.HResult) {
            return $true
        }

        $e = $e.InnerException
    }

    return $false
}

# Puts a validated file in place in one step:
#   - destination exists : File.Replace (atomic swap on NTFS; the old file
#                          is never deleted before the new one is in place)
#   - otherwise          : File.Move (fails if a file appeared meanwhile)
function Move-FileIntoPlace {

    param(
        [Parameter(Mandatory = $true)][string]$Source,
        [Parameter(Mandatory = $true)][string]$Destination,
        [bool]$Overwrite = $true
    )

    if (Test-Path -LiteralPath $Destination -PathType Leaf) {

        if (-not $Overwrite) {
            throw [System.IO.IOException]::new("Destination already exists: $Destination")
        }

        [System.IO.File]::Replace($Source, $Destination, [NullString]::Value, $true)
    }
    else {
        [System.IO.File]::Move($Source, $Destination)
    }
}

# Downloads a SharePoint file item to $Destination (full local path):
#   1. skips it if the local file is already identical (size + QuickXorHash)
#   2. each attempt re-reads the item (current size, hash, a fresh download
#      URL), streams it to <Destination>.<id>.partial in the same folder
#      and validates size + QuickXorHash (a download returns the exact
#      stored bytes, so this also holds for Office files)
#   3. sets the file's modified time to SharePoint's
#   4. puts it in place atomically; if the destination is locked (open in
#      Excel), only this step is retried, the file is not downloaded again
# The destination never holds a partial or unvalidated file, and a failure
# leaves an existing local file untouched.
#
# Status: Downloaded, AlreadyCurrent, FileExists, DownloadFailed,
#         LocalWriteFailed
# Settings: MaxRetries, BaseDelay, DownloadTimeoutMinutes
function Receive-SpFile {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [Parameter(Mandatory = $true)]$Item,
        [Parameter(Mandatory = $true)][string]$Destination,
        [bool]$Overwrite = $true,
        [Parameter(Mandatory = $true)][System.Collections.IDictionary]$Settings
    )

    $maxRetries = [int]$Settings.MaxRetries
    $baseDelay  = [int]$Settings.BaseDelay
    $timeout    = [int]$Settings.DownloadTimeoutMinutes

    $result = New-SpTransferResult $Item.name

    $result.LocalPath  = $Destination
    $result.ItemId     = $Item.id
    $result.WebUrl     = $Item.webUrl
    $result.RemoteHash = Get-SpItemQuickXorHash $Item

    Write-Log "Remote     : $($Item.name)"
    Write-Log "Size       : $($Item.size)"
    $remoteModified = ConvertTo-SpDateUtc $Item.lastModifiedDateTime

    if ($remoteModified) {
        Write-Log "Modified   : $($remoteModified.ToString('yyyy-MM-dd HH:mm:ss')) UTC"
    }
    Write-Log "QuickXor   : $($result.RemoteHash)"
    Write-Log "Local      : $Destination"

    #----------------------------------------------------------------------
    # LOCAL FILE ALREADY THERE?
    #----------------------------------------------------------------------

    if (Test-Path -LiteralPath $Destination -PathType Leaf) {

        $localSize = (Get-Item -LiteralPath $Destination -ErrorAction Stop).Length

        if ($result.RemoteHash -and $localSize -eq $Item.size -and
            (Get-FileQuickXorHash $Destination) -ceq $result.RemoteHash) {

            $result.Status    = "AlreadyCurrent"
            $result.Message   = "Local file already identical to SharePoint"
            $result.LocalSize = $localSize
            $result.LocalHash = $result.RemoteHash

            Write-Log "Skipped: local file already identical to SharePoint"
            return $result
        }

        if (-not $Overwrite) {
            $result.Status  = "FileExists"
            $result.Message = "Local file exists with different content and overwrite is off"
            Write-Log $result.Message "ERROR"
            return $result
        }

        Write-Log "Local file differs and will be replaced"
    }

    # Same folder as the destination, so the final swap is on one volume
    $partial = "$Destination.$([guid]::NewGuid().ToString('N').Substring(0, 8)).partial"

    $lastMessage  = $null
    $attemptsMade = 0
    $downloaded   = $false
    $localError   = $false

    try {

        #------------------------------------------------------------------
        # DOWNLOAD + VALIDATE (with retries)
        #------------------------------------------------------------------

        for ($attempt = 1; $attempt -le $maxRetries; $attempt++) {

            $attemptsMade = $attempt
            $lastError    = $null

            try {

                Write-Log "Download attempt $attempt of $maxRetries"

                if (Test-Path -LiteralPath $partial) {
                    Remove-Item -LiteralPath $partial -Force -ErrorAction Stop
                }

                # Current metadata + fresh download URL (the URL expires, and
                # someone may have saved a new version since the lookup)
                $current = Get-SpItemForDownload -DriveId $DriveId -ItemId $Item.id
                $url     = $current['@microsoft.graph.downloadUrl']

                if (-not $url) {
                    throw "SharePoint returned no download URL"
                }

                $expectedSize = [long]$current.size
                $expectedHash = Get-SpItemQuickXorHash $current

                if ($expectedHash -cne $result.RemoteHash -or $expectedSize -ne $Item.size) {
                    Write-Log "Remote file changed since lookup; downloading the current version" "WARN"
                    Write-Log "QuickXor   : $expectedHash"
                }

                $result.RemoteHash = $expectedHash

                if (-not $expectedHash) {
                    Write-Log "SharePoint reports no QuickXorHash; validating size only" "WARN"
                }

                Save-SpDownloadUrl -Url $url -OutFile $partial -TimeoutMinutes $timeout

                $localSize = (Get-Item -LiteralPath $partial -ErrorAction Stop).Length

                if ($localSize -ne $expectedSize) {
                    throw "Size validation failed (remote $expectedSize, downloaded $localSize)"
                }

                $localHash = Get-FileQuickXorHash $partial

                Write-Log "Downloaded QuickXor : $localHash"

                if ($expectedHash -and $localHash -cne $expectedHash) {
                    throw "QuickXorHash validation failed"
                }

                $result.LocalSize = $localSize
                $result.LocalHash = $localHash

                # Keep SharePoint's modified time (best effort)
                $modified = ConvertTo-SpDateUtc $current.lastModifiedDateTime

                if ($modified) {
                    try {
                        [System.IO.File]::SetLastWriteTimeUtc($partial, $modified)
                    }
                    catch {
                        Write-Log "Could not set file modified time: $($_.Exception.Message)" "WARN"
                    }
                }

                Write-Log "Download validated"

                $downloaded = $true
                break
            }
            catch {
                $lastError   = $_
                $lastMessage = $_.Exception.Message

                Write-LogException $_

                # Access denied / disk full: retrying won't help
                if (Test-IsLocalWriteError $_.Exception) {
                    $localError = $true
                    break
                }
            }

            if ($attempt -lt $maxRetries) {

                $delay = Get-ErrorRetryDelay -ErrorRecord $lastError -Attempt $attempt -BaseDelay $baseDelay

                if ($delay -lt 0 -or (Test-ThrottleLimitReached)) {
                    $lastMessage = "stopped by throttling limit ($lastMessage)"
                    break
                }

                Write-Log "Retrying in $delay seconds" "WARN"

                Start-Sleep -Seconds $delay
            }
        }

        #------------------------------------------------------------------
        # PUT IN PLACE (retry only this step, e.g. file open in Excel)
        #------------------------------------------------------------------

        if ($downloaded) {

            for ($attempt = 1; $attempt -le $maxRetries; $attempt++) {

                try {
                    Move-FileIntoPlace -Source $partial -Destination $Destination -Overwrite $Overwrite

                    $result.Status  = "Downloaded"
                    $result.Message = "Downloaded and validated"

                    Write-Log "Download complete: $Destination"
                    break
                }
                catch {

                    # A file appeared at the destination during the download
                    if (-not $Overwrite -and (Test-Path -LiteralPath $Destination -PathType Leaf)) {
                        $result.Status  = "FileExists"
                        $result.Message = "Local file appeared during download and overwrite is off"
                        Write-Log $result.Message "ERROR"
                        break
                    }

                    $lastMessage = $_.Exception.Message

                    Write-Log "Could not put file in place (attempt $attempt of $maxRetries): $lastMessage" "WARN"

                    if ($attempt -lt $maxRetries) {
                        $delay = Get-RetryDelay -Attempt $attempt -BaseDelay $baseDelay
                        Write-Log "Destination may be open or locked; retrying in $delay seconds" "WARN"
                        Start-Sleep -Seconds $delay
                    }
                }
            }

            if (-not $result.Status) {
                $result.Status  = "LocalWriteFailed"
                $result.Message = "Downloaded and validated, but could not replace $Destination (open, locked or read-only?): $lastMessage"
                Write-Log $result.Message "ERROR"
            }
        }
        elseif ($localError) {
            $result.Status  = "LocalWriteFailed"
            $result.Message = "Cannot write to $(Split-Path $Destination -Parent): $lastMessage"
            Write-Log $result.Message "ERROR"
        }
        else {
            $result.Status  = "DownloadFailed"
            $result.Message = "Download failed after $attemptsMade attempt(s): $lastMessage"
            Write-Log $result.Message "ERROR"
        }
    }
    finally {
        # Never leave a partial file behind
        if (Test-Path -LiteralPath $partial) {
            Remove-Item -LiteralPath $partial -Force -ErrorAction SilentlyContinue
        }
    }

    return $result
}

#--------------------------------------------------------------------------
# RUN SUMMARY
#--------------------------------------------------------------------------

# Writes the end-of-run summary: counts, then one line per file:
#   DONE     uploaded / downloaded
#   SKIPPED  already identical, nothing to do
#   RETRY    failed in every pass for a temporary reason; a rerun retries it
#   REVIEW   failed for a reason a rerun won't fix (needs a person)
#   PENDING  not started (run stopped by throttling); a rerun does it
# Returns the counts so the script can choose its exit code.
function Write-SpTransferSummary {

    param(
        [Parameter(Mandatory = $true)][System.Collections.IDictionary]$Results,
        [string[]]$NotStarted = @(),
        [int]$Total,
        [Parameter(Mandatory = $true)][string]$DoneStatus,
        [Parameter(Mandatory = $true)][string]$DoneLabel,
        [Parameter(Mandatory = $true)][string]$SkippedStatus,
        [string]$SkippedReason = "already identical",
        [string[]]$RetryableStatuses = @()
    )

    $all     = @($Results.Values)
    $done    = @($all | Where-Object { $_.Status -eq $DoneStatus })
    $skipped = @($all | Where-Object { $_.Status -eq $SkippedStatus })
    $failed  = @($all | Where-Object { $_.Status -ne $DoneStatus -and $_.Status -ne $SkippedStatus })
    $retry   = @($failed | Where-Object { $_.Status -in $RetryableStatuses })
    $review  = @($failed | Where-Object { $_.Status -notin $RetryableStatuses })

    Write-LogSeparator
    Write-Log "SUMMARY"
    Write-Log ("  {0,-24}: {1}" -f "Files", $Total)
    Write-Log ("  {0,-24}: {1}" -f $DoneLabel, $done.Count)
    Write-Log ("  {0,-24}: {1} ({2})" -f "Skipped", $skipped.Count, $SkippedReason)
    Write-Log ("  {0,-24}: {1}" -f "Failed, retry on rerun", $retry.Count)
    Write-Log ("  {0,-24}: {1}" -f "Failed, needs review", $review.Count)
    Write-Log ("  {0,-24}: {1}" -f "Not started (rerun)", $NotStarted.Count)

    if ($all.Count -gt 0 -or $NotStarted.Count -gt 0) {
        Write-Log ""
    }

    foreach ($r in $done) {
        Write-Log "  DONE     $($r.FileName)"
    }

    foreach ($r in $skipped) {
        Write-Log "  SKIPPED  $($r.FileName) ($($r.Message))"
    }

    foreach ($r in $retry) {
        Write-Log "  RETRY    $($r.FileName) [$($r.Status)] $($r.Message)" "ERROR"
    }

    foreach ($r in $review) {
        Write-Log "  REVIEW   $($r.FileName) [$($r.Status)] $($r.Message)" "ERROR"
    }

    foreach ($name in $NotStarted) {
        Write-Log "  PENDING  $name (not started)" "WARN"
    }

    return [pscustomobject]@{
        Done       = $done.Count
        Skipped    = $skipped.Count
        Retry      = $retry.Count
        Review     = $review.Count
        NotStarted = $NotStarted.Count
        Failed     = $failed
    }
}

#--------------------------------------------------------------------------
# MANIFEST
#   <LogFolder>\state\<SiteName>_<TargetFolder>.json
#   One entry per file name: local size/hash, remote hash, item id.
#--------------------------------------------------------------------------

function Get-SpManifestPath {

    param(
        [Parameter(Mandatory = $true)][string]$LogFolder,
        [Parameter(Mandatory = $true)][string]$SiteName,
        [Parameter(Mandatory = $true)][string]$TargetFolder,
        [string]$StateFolderName = "state"
    )

    $name = ("{0}_{1}" -f $SiteName, $TargetFolder.Trim('/\')) -replace '[\\/:*?"<>|\s]+', '_'

    return Join-Path (Join-Path $LogFolder $StateFolderName) "$name.json"
}

# Returns a hashtable: file name -> entry (keys are case-insensitive).
# A missing or unreadable manifest gives an empty one (logged).
function Import-SpManifest {

    param([Parameter(Mandatory = $true)][string]$Path)

    $manifest = @{}

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        Write-Log "Manifest   : none yet ($Path)"
        return $manifest
    }

    try {
        $json = Get-Content -LiteralPath $Path -Raw -Encoding UTF8 -ErrorAction Stop

        if (-not [string]::IsNullOrWhiteSpace($json)) {

            $data = $json | ConvertFrom-Json -ErrorAction Stop

            foreach ($entry in @($data.Files)) {
                if ($entry -and $entry.FileName) {
                    $manifest[$entry.FileName] = $entry
                }
            }
        }

        Write-Log "Manifest   : $Path ($($manifest.Count) entries)"
    }
    catch {
        Write-Log "Manifest unreadable, starting empty: $Path" "WARN"
        Write-LogException $_
        $manifest = @{}
    }

    return $manifest
}

# Writes the manifest to a temp file and then replaces the real one, so a
# crash during the write never leaves a half-written manifest
function Save-SpManifest {

    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][hashtable]$Manifest
    )

    $folder = Split-Path $Path -Parent

    if (-not (Test-Path -LiteralPath $folder -PathType Container)) {
        New-Item -ItemType Directory -Path $folder -Force -ErrorAction Stop | Out-Null
    }

    $data = [ordered]@{
        Version   = $script:ManifestVersion
        UpdatedAt = (Get-Date -Format "yyyy-MM-ddTHH:mm:ss")
        Files     = @($Manifest.Values | Sort-Object FileName)
    }

    $tempPath = "$Path.tmp"

    $data | ConvertTo-Json -Depth 4 |
        Set-Content -LiteralPath $tempPath -Encoding UTF8 -ErrorAction Stop

    Move-Item -LiteralPath $tempPath -Destination $Path -Force -ErrorAction Stop
}

function New-SpManifestEntry {

    param([Parameter(Mandatory = $true)]$Result)

    return [pscustomobject]@{
        FileName   = $Result.FileName
        LocalSize  = $Result.LocalSize
        LocalHash  = $Result.LocalHash
        RemoteHash = $Result.RemoteHash
        ItemId     = $Result.ItemId
        UpdatedAt  = (Get-Date -Format "yyyy-MM-ddTHH:mm:ss")
    }
}

Export-ModuleMember -Function `
    New-SpTransferResult,
    Remove-SpStagedItem,
    New-SpTargetIndex,
    Write-SpTransferSummary,
    Clear-SpStaging,
    Publish-SpFile,
    Receive-SpFile,
    Get-SpManifestPath,
    Import-SpManifest,
    Save-SpManifest,
    New-SpManifestEntry
