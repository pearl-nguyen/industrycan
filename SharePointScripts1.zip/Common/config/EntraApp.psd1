#--------------------------------------------------------------------------
# EntraApp.psd1
#   Microsoft Entra app registration used by every Graph script
#   (SharePoint upload/download, email, certificate install).
#   No secrets here: authentication uses the certificate in the store.
#--------------------------------------------------------------------------

@{
    TenantId   = "b72ac62f-06d5-4cd5-824e-ee92319a4676"
    ClientId   = "452f66fa-4eea-4ba8-885b-ad65f3bd1e2c"
    Thumbprint = "F59E00898EF052136F3F562A4263A6D3491480AF"

    # Store the certificate is installed into (used by the install script)
    CertStore  = "CurrentUser\My"
}
