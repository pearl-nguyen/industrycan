DataExtract - scheduled extract / publish jobs
==============================================

Everything lives under one root folder (e.g. C:\SPECTRA_Automation\DataExtract):

  scripts\run_job.ps1          what Task Scheduler runs (one call per job)
  scripts\jobs.psd1            job definitions (type, names, destinations)
  scripts\job_config.psd1      database, XE, SFTP, retention, retry settings
  scripts\sharepoint_config.psd1   Graph app + certificate
  scripts\*.ps1                the steps (each can also be run on its own)
  scripts\modules\*.psm1       shared code
  sqls\<JobName>.sql, sqls\<JobName>-count.sql     extract jobs
  sqls\EMC_TDB_FREQPLAN\       BCP dump SQL (copy2tdb.sql, copy_win10.sql, ...)
  lib\Oracle.ManagedDataAccess.dll
  lib\WinSCP\WinSCPnet.dll + WinSCP.exe   (same version)
  secure\*.xml                 encrypted credentials (never in git)
  output\<JobName>\            files produced
  logs\<JobName>\yyyyMMdd.log  one log per job per day, all steps


Job types (jobs.psd1)
---------------------
  CsvToSftp          extract -> publish (SFTP)
  CsvToSharePoint    extract -> publish (SharePoint)
  ExcelToSharePoint  extract -> convert -> publish (SharePoint)
  DumpToSharePoint   copy -> dump -> publish (SharePoint)


Scheduling
----------
One Task Scheduler task per job, running as the job account:

  powershell.exe -NoProfile -ExecutionPolicy Bypass -File C:\SPECTRA_Automation\DataExtract\scripts\run_job.ps1 -JobName EMC_TDB_FREQPLAN

The task's result is the exit code of the step that failed (0 = success);
names are in scripts\modules\ExitCodes.psm1 and in the log.

Rerun after a failure (the log prints the exact command):

  run_job.ps1 -JobName EMC_TDB_FREQPLAN -From publish -RunDate 20261008

Retries happen inside the uploads. The copy and dump steps are not retried
automatically (the copy writes to prod and takes hours): rerun with -From.


One-time setup on the team machine
----------------------------------
Log in as the account that runs the jobs.

 1. Copy the zip contents to the root folder. Delete the old
    set_db_credential.ps1, SpLogging.psm1 and SpValidation.psm1 if present.

 2. Libraries
    - lib\Oracle.ManagedDataAccess.dll (NuGet Oracle.ManagedDataAccess,
      lib\net462 build)
    - lib\WinSCP\: WinSCPnet.dll and WinSCP.exe from the WinSCP
      ".NET assembly / COM library" download (both from the same package)
    - Install-Module ImportExcel -Scope AllUsers
    - Microsoft.Graph.Authentication (already installed)

 3. Settings
    - job_config.psd1: Oracle.DataSource, OracleXe.OracleHome, and the
      SFTP HostKey. To get the host key, run the old WinSCP command once
      with /log=... and copy the "Host key fingerprint is ..." line
      (e.g. ssh-ed25519 255 abc...=).
    - jobs.psd1: check names, folders and the yearly SharePoint folder.

 4. Credentials (each prompts for user name + password):
      set_credential.ps1 -Name db_credential -TestOracle
      set_credential.ps1 -Name sftp_6ghz
      set_credential.ps1 -Name prod_emc      (prod user that runs copy2tdb)
      set_credential.ps1 -Name xe_emctdb     (XE user the DB link uses)
      set_credential.ps1 -Name xe_system     (user SYSTEM, for expdp)
    Rerun the matching one whenever a password changes. They only work
    for this Windows account on this machine.

 5. BCP dump job (EMC_TDB_FREQPLAN)
    - Copy your existing config.sql and EMC_TDB_FREQPLAN_EXPORT.par into
      sqls\EMC_TDB_FREQPLAN\. In config.sql, DELETE the emc_password and
      emctdb_password lines (see config.sql.example).
    - copy2tdb.sql, copy_win10.sql and drop_linkToXeDb.sql in this zip
      replace the old ones (changes are listed at the top of each file).
    - Create output\EMC_TDB_FREQPLAN, then run once as SYSTEM on XE:
        sqlplus SYSTEM@XE @sqls\EMC_TDB_FREQPLAN\setup_dump_directory.sql
      (edit the path in it first if the root folder is different)
    - Disk space: KeepCopies (jobs.psd1) dated dumps of ~3 GB each, plus
      the fixed-name copy in C:\Lstelcom\maintenance_scripts. The dump
      step stops before exporting if there is not enough space.
    - Disable the old .bat tasks (copy2tdb, EMC_TDB_FREQPLAN_EXPORT,
      Copy_dump_file_to_U, Re_name_dump_file, drop_linkToXeDb).

 6. Test each job by hand from a normal (not elevated) prompt, then
    schedule it.


What the dump job does
----------------------
 copy    drops a leftover DB link, runs copy2tdb.sql (stops at the first
         SQL error), checks rows in prod = rows imported into XE, always
         drops the DB link at the end
 dump    deletes older dumps first (keeps KeepCopies), checks disk space,
         runs expdp -> output\EMC_TDB_FREQPLAN\EMC_TDB_FREQPLAN_yyyyMMdd.dmp,
         validates the expdp log, the size range and the rows per table,
         then replaces C:\Lstelcom\maintenance_scripts\EMC_TDB_FREQPLAN.dmp
         (no date). A dump that fails a check is renamed .dmp.rejected.
 publish uploads the dated dump to SMSOperations, validated with
         SharePoint's QuickXorHash (no download). Never replaces or
         deletes anything in the target folder; the only thing it
         deletes is its own temporary copy in _staging.
