@{
    #----------------------------------------------------------------------
    # Report database (extract jobs: oracle_extract.ps1)
    #----------------------------------------------------------------------
    Oracle = @{
        # EZConnect (host:port/service) works without tnsnames.ora
        DataSource        = "dbhost.example.gc.ca:1521/SERVICE_NAME"

        # Relative to the DataExtract root folder
        DriverPath        = "lib\Oracle.ManagedDataAccess.dll"

        # secure\<CredentialName>.xml, created with set_credential.ps1
        CredentialName    = "db_credential"

        ConnectionTimeout = 30      # seconds
        CommandTimeout    = 1800    # seconds per query, 0 = no limit
        FetchRows         = 1000    # rows per round trip
    }

    #----------------------------------------------------------------------
    # Local Oracle XE (dump jobs: copy_to_xe.ps1, export_dump.ps1)
    #----------------------------------------------------------------------
    OracleXe = @{
        OracleHome       = "C:\oraclexe\app\oracle\product\11.2.0\server"
        Sid              = "XE"

        # SYSTEM account used by expdp (user name + password in the file)
        SystemCredential = "xe_system"
    }

    #----------------------------------------------------------------------
    # SFTP servers (ftp_upload.ps1); jobs.psd1 refers to them by name
    #----------------------------------------------------------------------
    WinScpFolder = "lib\WinSCP"     # WinSCPnet.dll + WinSCP.exe, same version

    Sftp = @{
        ic_sftp = @{
            HostName       = "ftp.ic.gc.ca"
            Port           = 2222
            # From the WinSCP log ("Host key fingerprint is ...") or the
            # GUI: Session > Server/Protocol Information
            HostKey        = "ssh-ed25519 255 REPLACE_WITH_FINGERPRINT"
            CredentialName = "sftp_6ghz"

            # Default = .filepart + rename (receiver never sees a partial
            # file). Use Off if the WinSCP log shows the server refusing
            # the rename.
            ResumeSupport  = "Default"
            TimeoutSeconds = 60
        }
    }

    #----------------------------------------------------------------------
    # Files
    #----------------------------------------------------------------------
    Export = @{
        DateFormat = "yyyy-MM-dd HH:mm:ss"
    }

    Excel = @{
        WorksheetName = "Data"
    }

    # Days to keep; 0 disables cleanup. Dump files are kept by count
    # instead (jobs.psd1, Dump.KeepCopies).
    Retention = @{
        LogDays    = 30
        OutputDays = 14
    }

    Retry = @{
        MaxRetries = 3
        BaseDelay  = 5
    }
}
