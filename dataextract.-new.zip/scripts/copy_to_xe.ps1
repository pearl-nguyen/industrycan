<#
.SYNOPSIS
    Dump job step 1 - copies data from prod into the local XE database
    with the existing SQL*Plus scripts (copy2tdb.sql / copy_win10.sql).

.DESCRIPTION
    1. Drops the DB link if a previous run left it behind
    2. Runs copy2tdb.sql with SQL*Plus. Passwords are sent as DEFINEs on
       SQL*Plus's input (from the encrypted credential files), never on
       the command line. The script stops at the first SQL error.
    3. Checks the output: exit code, no ORA-/SP2-/PLS- errors, and the
       prod row counts equal the rows imported into XE (CountChecks)
    4. Always drops the DB link at the end, even if the copy failed
    5. Saves the counts to output\<JobName>\<JobName>_<RunDate>.copy.meta
       for the dump step

    Not retried automatically: each run writes an action to prod and
    can take hours. Rerun manually with run_job.ps1 -From copy.

.EXAMPLE
    powershell.exe -ExecutionPolicy Bypass -File C:\SPECTRA_Automation\DataExtract\scripts\copy_to_xe.ps1 -JobName EMC_TDB_FREQPLAN
#>

param(
    [Parameter(Mandatory = $true)]
    [string]$JobName,

    [string]$RunDate = (Get-Date -Format "yyyyMMdd")
)

#--------------------------------------------------------------------------
# EXIT CODES ($ExitCode in modules\ExitCodes.psm1)
#   Success, InputNotFound, SetupFailed, InvalidArgument, Unexpected,
#   CopyFailed, CopyCountMismatch, CopyTimeout
#--------------------------------------------------------------------------

$ErrorActionPreference = "Stop"

$Root         = Split-Path $PSScriptRoot -Parent
$ModuleFolder = Join-Path $PSScriptRoot "modules"
$LogFolder    = Join-Path $Root "logs\$JobName"
$OutputFolder = Join-Path $Root "output\$JobName"

try {
    Import-Module (Join-Path $ModuleFolder "ExitCodes.psm1") -Force
}
catch {
    Write-Host "Setup failed: $($_.Exception.Message)"
    exit 3   # SetupFailed (ExitCodes.psm1 itself could not be loaded)
}

try {
    Import-Module (Join-Path $ModuleFolder "JobLogging.psm1")     -Force
    Import-Module (Join-Path $ModuleFolder "JobCredentials.psm1") -Force
    Import-Module (Join-Path $ModuleFolder "OracleTools.psm1")    -Force

    $Config  = Import-PowerShellDataFile -Path (Join-Path $PSScriptRoot "job_config.psd1")
    $Jobs    = Import-PowerShellDataFile -Path (Join-Path $PSScriptRoot "jobs.psd1")
    $logPath = Initialize-Log -LogFolder $LogFolder -Step "COPY"
}
catch {
    Write-Host "Setup failed: $($_.Exception.Message)"
    exit $ExitCode.SetupFailed
}

function Exit-Job {

    param([int]$Code)

    Write-Log "Finished with exit code $Code ($(Get-ExitCodeName $Code))"

    exit $Code
}

trap {
    Write-LogException $_.Exception
    Exit-Job $ExitCode.Unexpected
}

# Runs the drop-link script. Never throws: a leftover link is reported,
# and the next run drops it before copying anyway.
function Remove-DbLink {

    param([string]$When)

    try {
        Write-Log "Dropping DB link ($When)"

        $r = Invoke-SqlPlusScript `
            -SqlPlusPath $sqlplus `
            -ScriptPath $dropScript `
            -Defines $defines `
            -Environment $oracleEnv `
            -TimeoutMinutes 10

        $errors = @(Find-OracleErrors $r.Output)

        if ($r.ExitCode -ne 0 -or $r.TimedOut -or $errors.Count -gt 0) {
            Write-Log "DB link drop reported a problem (exit $($r.ExitCode)); check the lines above" "WARN"
        }
        else {
            Write-Log "DB link dropped (or was not there)"
        }
    }
    catch {
        Write-Log "DB link drop failed: $($_.Exception.Message)" "WARN"
    }
}

#--------------------------------------------------------------------------
# START
#--------------------------------------------------------------------------

Write-Log "===================================================="
Write-Log "Copy to XE started"
Write-Log "Job        : $JobName"
Write-Log "Run date   : $RunDate"
Write-Log "Log file   : $logPath"

if ($RunDate -notmatch '^\d{8}$') {
    Write-Log "Invalid -RunDate '$RunDate' (expected yyyyMMdd)" "ERROR"
    Exit-Job $ExitCode.InvalidArgument
}

if (-not $Jobs.ContainsKey($JobName) -or -not $Jobs[$JobName].Copy) {
    Write-Log "Job '$JobName' has no Copy section in jobs.psd1" "ERROR"
    Exit-Job $ExitCode.InvalidArgument
}

$copy       = $Jobs[$JobName].Copy
$sqlFolder  = Join-Path $Root $copy.SqlFolder
$copyScript = Join-Path $sqlFolder $copy.Script
$dropScript = Join-Path $sqlFolder $copy.DropLinkScript
$metaPath   = Join-Path $OutputFolder "${JobName}_$RunDate.copy.meta"
$sqlplus    = Join-Path $Config.OracleXe.OracleHome "bin\sqlplus.exe"

$oracleEnv = @{
    ORACLE_HOME = $Config.OracleXe.OracleHome
    ORACLE_SID  = $Config.OracleXe.Sid
}

Write-Log "SQL folder : $sqlFolder"
Write-Log "Script     : $($copy.Script)"
Write-Log "Timeout    : $($copy.TimeoutHours) hours"

foreach ($f in @($copyScript, $dropScript, $sqlplus)) {
    if (-not (Test-Path -LiteralPath $f -PathType Leaf)) {
        Write-Log "File not found: $f" "ERROR"
        Exit-Job $ExitCode.InputNotFound
    }
}

#--------------------------------------------------------------------------
# PASSWORDS (as SQL*Plus DEFINEs, from encrypted credential files)
#--------------------------------------------------------------------------

try {
    $defines = [ordered]@{}

    foreach ($name in $copy.Secrets.Keys) {
        $cred = Get-StoredCredential -Root $Root -Name $copy.Secrets[$name]
        $defines[$name] = $cred.GetNetworkCredential().Password
    }

    # A DEFINE left in config.sql would replace the value sent here
    $configSql = Join-Path $sqlFolder "config.sql"

    if (Test-Path -LiteralPath $configSql) {

        $configText = Get-Content -LiteralPath $configSql -Raw

        foreach ($name in $defines.Keys) {
            if ($configText -match "(?im)^\s*def(ine)?\s+$name\b") {
                Write-Log "config.sql still defines '$name' in plain text; remove it (the encrypted credential is used instead)" "WARN"
            }
        }
    }

    if (-not (Test-Path -LiteralPath $OutputFolder -PathType Container)) {
        New-Item -ItemType Directory -Path $OutputFolder -Force | Out-Null
    }
}
catch {
    Write-LogException $_.Exception
    Exit-Job $ExitCode.SetupFailed
}

#--------------------------------------------------------------------------
# COPY
#--------------------------------------------------------------------------

$exitWith = $ExitCode.Success

# A previous run may have died before dropping the link
Remove-DbLink -When "before copy"

try {
    $started = Get-Date

    $r = Invoke-SqlPlusScript `
        -SqlPlusPath $sqlplus `
        -ScriptPath $copyScript `
        -Defines $defines `
        -Environment $oracleEnv `
        -TimeoutMinutes ([double]$copy.TimeoutHours * 60)

    Write-Log ("SQL*Plus finished in {0:hh\:mm\:ss} with exit code {1}" -f ((Get-Date) - $started), $r.ExitCode)

    $errors = @(Find-OracleErrors $r.Output)
    $counts = Get-CountLines $r.Output

    if ($r.TimedOut) {
        Write-Log "Copy stopped after $($copy.TimeoutHours) hours" "ERROR"
        $exitWith = $ExitCode.CopyTimeout
    }
    elseif ($r.ExitCode -ne 0 -or $errors.Count -gt 0) {

        foreach ($e in $errors) {
            Write-Log "Error: $e" "ERROR"
        }

        Write-Log "Copy failed (SQL*Plus exit code $($r.ExitCode))" "ERROR"
        $exitWith = $ExitCode.CopyFailed
    }
    else {

        #------------------------------------------------------------------
        # COUNT CHECKS: rows in prod = rows imported into XE
        #------------------------------------------------------------------

        foreach ($source in $copy.CountChecks.Keys) {

            $target = $copy.CountChecks[$source]

            if (-not $counts.ContainsKey($source) -or -not $counts.ContainsKey($target)) {
                Write-Log "Count line '$source=' or '$target=' not found in the SQL*Plus output" "ERROR"
                $exitWith = $ExitCode.CopyFailed
                continue
            }

            if ($counts[$source] -ne $counts[$target]) {
                Write-Log ("{0}={1:N0} but {2}={3:N0}" -f $source, $counts[$source], $target, $counts[$target]) "ERROR"
                $exitWith = $ExitCode.CopyCountMismatch
            }
            else {
                Write-Log ("{0} = {1} = {2:N0}" -f $source, $target, $counts[$target])
            }
        }

        if ($exitWith -eq $ExitCode.Success) {

            # Counts for the dump step (written via .tmp so it is never partial)
            $lines = @($counts.Keys | Sort-Object | ForEach-Object { "$_=$($counts[$_])" })

            Set-Content -LiteralPath "$metaPath.tmp" -Value $lines -Encoding ASCII
            Move-Item -LiteralPath "$metaPath.tmp" -Destination $metaPath -Force

            Write-Log "Counts     : $(Split-Path $metaPath -Leaf)"
        }
    }
}
catch {
    Write-LogException $_.Exception
    $exitWith = $ExitCode.CopyFailed
}
finally {
    # Always, even after a failure or timeout
    Remove-DbLink -When "after copy"

    # Passwords are no longer needed
    if ($defines) { $defines.Clear() }
}

if ($exitWith -eq $ExitCode.Success) {
    Write-Log "Copy to XE complete"
}

Exit-Job $exitWith
