<#
.SYNOPSIS
    Uploads a file to SharePoint Online through a staging folder.

.DESCRIPTION
    1. Uploads the file to the staging folder under a unique name
       (files over 250 MB in 10 MB chunks; a failed chunk is retried and
       the upload resumes where it stopped)
    2. Validates the uploaded copy:
         - Office files: downloaded back and compared part by part,
           ignoring the metadata SharePoint adds
         - all other files (CSV, dump, ...): SharePoint's QuickXorHash is
           compared with the local file's, so nothing is downloaded
    3. Moves the validated file into the target folder with its real name

    The target folder only ever receives a fully validated file. The only
    item this script ever deletes is its own uniquely named staging copy.
    Logs go to <LogFolder>\yyyyMMdd.log

.EXAMPLE
    powershell.exe -ExecutionPolicy Bypass -File C:\Development\scripts\sharepoint_upload.ps1 `
        -LocalFile "C:\Development\data\test.xlsx" `
        -SiteName "smsfc" `
        -TargetFolder "Mass Cancellation" `
        -LogFolder "C:\Development\logs\MassCancellation"

    Add -NoOverwrite to fail (exit TargetExists) instead of replacing a
    file of the same name in the target folder.

.NOTES
    Layout:
        scripts\sharepoint_upload.ps1
        scripts\sharepoint_config.psd1
        scripts\modules\ExitCodes.psm1
        scripts\modules\JobLogging.psm1
        scripts\modules\HttpHelpers.psm1
        scripts\modules\FileValidation.psm1
        scripts\modules\SpGraph.psm1
#>

param(
    [Parameter(Mandatory = $true)]
    [string]$LocalFile,

    [Parameter(Mandatory = $true)]
    [string]$SiteName,

    [Parameter(Mandatory = $true)]
    [string]$TargetFolder,

    # <rootfolder>\logs\<jobname>, passed by the calling job
    [Parameter(Mandatory = $true)]
    [string]$LogFolder,

    [string]$StagingFolder = "_staging",

    # Fail instead of replacing an existing file of the same name.
    # A switch (not a [bool]) so it works with powershell.exe -File.
    [switch]$NoOverwrite
)

$Overwrite = -not $NoOverwrite

#--------------------------------------------------------------------------
# EXIT CODES ($ExitCode in modules\ExitCodes.psm1)
#   Success, InputNotFound (local file), SetupFailed, Unexpected,
#   GraphAuthFailed, SiteNotFound, TargetExists, FolderNotFound,
#   MoveFailed, UploadFailed
#--------------------------------------------------------------------------

$ErrorActionPreference = "Stop"

#--------------------------------------------------------------------------
# SETUP
#--------------------------------------------------------------------------

$ModuleFolder = Join-Path $PSScriptRoot "modules"
$ConfigFile   = Join-Path $PSScriptRoot "sharepoint_config.psd1"

try {
    # Loaded first so even setup failures use the named codes
    Import-Module (Join-Path $PSScriptRoot "modules\ExitCodes.psm1") -Force
}
catch {
    Write-Host "Setup failed: $($_.Exception.Message)"
    exit 3   # SetupFailed (ExitCodes.psm1 itself could not be loaded)
}

try {
    Import-Module (Join-Path $ModuleFolder "JobLogging.psm1")     -Force
    Import-Module (Join-Path $ModuleFolder "HttpHelpers.psm1")    -Force
    Import-Module (Join-Path $ModuleFolder "FileValidation.psm1") -Force
    Import-Module (Join-Path $ModuleFolder "SpGraph.psm1")        -Force

    $Config  = Import-PowerShellDataFile -Path $ConfigFile
    $logPath = Initialize-Log -LogFolder $LogFolder -Step "PUBLISH"
}
catch {
    Write-Host "Setup failed: $($_.Exception.Message)"
    exit $ExitCode.SetupFailed
}

function Exit-Upload {

    param([int]$Code)

    Disconnect-SpGraph

    Write-Log "Finished with exit code $Code ($(Get-ExitCodeName $Code))"

    exit $Code
}

# Removes our own staging copy. Safe: the name is unique to this run,
# so no other file or version history is affected.
function Remove-StagedItem {

    param(
        [string]$DriveId,
        $Item
    )

    if (-not $Item) {
        return
    }

    try {
        Remove-SpItem -DriveId $DriveId -ItemId $Item.id
        Write-Log "Staging copy removed: $($Item.name)"
    }
    catch {
        Write-Log "Could not remove staging copy: $($Item.name)" "WARN"
        Write-LogException $_.Exception
    }
}

# Safety net: any unexpected terminating error outside a try/catch still
# gets logged, disconnects from Graph and returns a non-zero exit code
trap {
    Write-LogException $_.Exception
    Exit-Upload $ExitCode.Unexpected
}

#--------------------------------------------------------------------------
# START
#--------------------------------------------------------------------------

Write-Log "===================================================="
Write-Log "Upload started"
Write-Log "Log file   : $logPath"

if (-not (Test-Path -LiteralPath $LocalFile -PathType Leaf)) {

    Write-Log "Local file not found: $LocalFile" "ERROR"

    Exit-Upload $ExitCode.InputNotFound
}

$LocalFile = (Resolve-Path -LiteralPath $LocalFile).Path

$fileName  = Split-Path $LocalFile -Leaf
$extension = [System.IO.Path]::GetExtension($fileName).ToLower()
$isOffice  = Test-IsOfficeFile $LocalFile
$localSize = (Get-Item -LiteralPath $LocalFile).Length

# Office files are compared part by part after download; everything else
# by SharePoint's QuickXorHash (computed once here, before uploading)
if ($isOffice) {
    $localHash = Get-FileSHA256 $LocalFile
}
else {
    $localHash = Get-FileQuickXorHash $LocalFile
}

# Unique staging name so concurrent jobs never collide in _staging
$runId       = "{0}_{1}" -f (Get-Date -Format "yyyyMMddHHmmss"),
                            ([guid]::NewGuid().ToString("N").Substring(0, 8))
$stagingName = "${runId}_$fileName"
$stagingPath = ConvertTo-EncodedPath @($StagingFolder, $stagingName)

Write-Log "File       : $fileName"
Write-Log "Size       : $localSize"
if ($isOffice) {
    Write-Log "SHA256     : $localHash"
}
else {
    Write-Log "QuickXor   : $localHash"
}
Write-Log "Staging    : /$($StagingFolder.Trim('/\'))/$stagingName"
Write-Log "Target     : /$($TargetFolder.Trim('/\'))/$fileName"
Write-Log "Overwrite  : $Overwrite"

if ($isOffice) {
    Write-Log "Validation : Office content comparison (SharePoint metadata ignored)"
}
else {
    Write-Log "Validation : Size and QuickXorHash (no download)"
}

#--------------------------------------------------------------------------
# AUTHENTICATION
#--------------------------------------------------------------------------

try {
    Connect-SpGraph `
        -TenantId $Config.TenantId `
        -ClientId $Config.ClientId `
        -Thumbprint $Config.Thumbprint

    Write-Log "Graph authentication successful"
}
catch {
    Write-LogException $_.Exception
    Exit-Upload $ExitCode.GraphAuthFailed
}

#--------------------------------------------------------------------------
# LOCATE SITE AND DEFAULT DOCUMENT LIBRARY
#--------------------------------------------------------------------------

try {
    $drive = Get-SpDrive -SharePointHost $Config.SharePointHost -SiteName $SiteName

    Write-Log "Site       : $($drive.SiteUrl)"
    Write-Log "Library    : $($drive.Name)"
}
catch {
    Write-LogException $_.Exception
    Exit-Upload $ExitCode.SiteNotFound
}

#--------------------------------------------------------------------------
# FOLDERS
#--------------------------------------------------------------------------

try {
    $targetFolderItem = Get-SpFolder -DriveId $drive.Id -Path $TargetFolder

    if (-not $targetFolderItem) {
        throw "Target folder not found: $TargetFolder"
    }

    $stagingFolderItem = Get-SpFolder -DriveId $drive.Id -Path $StagingFolder -CreateIfMissing

    Write-Log "Folders ready (target and staging)"
}
catch {
    Write-LogException $_.Exception
    Exit-Upload $ExitCode.FolderNotFound
}

#--------------------------------------------------------------------------
# OVERWRITE PRE-CHECK (fail fast, before uploading anything)
#--------------------------------------------------------------------------

try {
    $existing = Get-SpItemByPath -DriveId $drive.Id -PathParts @($TargetFolder, $fileName)
}
catch {
    Write-LogException $_.Exception
    Exit-Upload $ExitCode.UploadFailed
}

if ($existing) {

    if (-not $Overwrite) {
        Write-Log "File already exists and Overwrite is false; nothing uploaded" "ERROR"
        Exit-Upload $ExitCode.TargetExists
    }

    Write-Log "Target file exists and will be replaced"
}

#--------------------------------------------------------------------------
# UPLOAD TO STAGING + VALIDATE (with retries)
#--------------------------------------------------------------------------

$stagedItem = $null
$validated  = $false

for ($attempt = 1; $attempt -le $Config.MaxRetries; $attempt++) {

    $tempFile = $null

    try {

        Write-Log "Upload attempt $attempt of $($Config.MaxRetries)"

        # Staging name is ours alone, so replace is always safe here
        $uploadResult = Send-SpFile `
            -DriveId $drive.Id `
            -ItemPath $stagingPath `
            -Path $LocalFile `
            -ConflictBehavior "replace"

        $stagedItem = $uploadResult

        # Log only safe fields (the full result contains a pre-authenticated
        # download URL that must not be written to logs)
        Write-Log "Upload Name : $($uploadResult.name)"
        Write-Log "Upload Id   : $($uploadResult.id)"
        Write-Log "Upload Size : $($uploadResult.size)"
        Write-Log "Upload to staging completed"

        Write-Log "Remote file validation starts"

        #--------------------------------------------------------------
        # VERIFY FILE EXISTS
        #--------------------------------------------------------------

        $remoteItem = Get-SpItem -DriveId $drive.Id -ItemId $uploadResult.id

        if (-not $remoteItem -or -not $remoteItem.id) {
            throw "Remote file not found"
        }

        Write-Log "Remote Size : $($remoteItem.size)"

        if ($isOffice) {

            #----------------------------------------------------------
            # OFFICE: download and compare content parts
            #----------------------------------------------------------

            # Give SharePoint time to finish processing (metadata injection)
            Start-Sleep -Seconds 5

            $tempFile = Join-Path `
                ([System.IO.Path]::GetTempPath()) `
                ("sp_" + [guid]::NewGuid().ToString() + $extension)

            Save-SpItemContent -DriveId $drive.Id -ItemId $remoteItem.id -OutFile $tempFile

            Write-Log "Remote SHA256 : $(Get-FileSHA256 $tempFile)"

            try {
                $diffs = @(Compare-OfficeContent $LocalFile $tempFile)
            }
            catch {
                throw "Downloaded file is not a valid Office package: $($_.Exception.Message)"
            }

            foreach ($d in $diffs) {
                Write-Log $d "ERROR"
            }

            if ($diffs.Count -gt 0) {
                throw "Content validation failed"
            }

            Write-Log "Content parts identical (SharePoint metadata ignored)"

            Remove-Item -LiteralPath $tempFile -Force -ErrorAction SilentlyContinue
        }
        else {

            #----------------------------------------------------------
            # OTHER FILES: size + SharePoint's QuickXorHash, no download
            #----------------------------------------------------------

            if ($remoteItem.size -ne $localSize) {
                throw "Size validation failed (local $localSize, remote $($remoteItem.size))"
            }

            $remoteHash = Wait-SpQuickXorHash `
                -DriveId $drive.Id `
                -ItemId $remoteItem.id `
                -TimeoutSeconds $Config.HashWaitSeconds

            if (-not $remoteHash) {
                throw "SharePoint did not provide a QuickXorHash within $($Config.HashWaitSeconds) seconds"
            }

            Write-Log "Remote QuickXor : $remoteHash"

            if ($remoteHash -ne $localHash) {
                throw "QuickXorHash validation failed"
            }

            Write-Log "QuickXorHash identical"
        }

        Write-Log "Remote file validation successful"

        $validated = $true

        break
    }
    catch {

        Write-LogException $_.Exception

        if ($tempFile -and (Test-Path -LiteralPath $tempFile)) {

            # Keep only the last failed download for inspection, so
            # retries do not pile up files in %TEMP%
            if ($attempt -lt $Config.MaxRetries) {
                Remove-Item -LiteralPath $tempFile -Force -ErrorAction SilentlyContinue
            }
            else {
                Write-Log "Downloaded copy kept for inspection: $tempFile" "WARN"
            }
        }
    }

    if ($attempt -lt $Config.MaxRetries) {

        $delay = Get-RetryDelay -Attempt $attempt -BaseDelay $Config.BaseDelay

        Write-Log "Retrying in $delay seconds" "WARN"

        Start-Sleep -Seconds $delay
    }
}

if (-not $validated) {

    Write-Log "Upload failed after $($Config.MaxRetries) attempts" "ERROR"

    # The invalid copy is only in staging; the target was never touched
    Remove-StagedItem -DriveId $drive.Id -Item $stagedItem

    Exit-Upload $ExitCode.UploadFailed
}

#--------------------------------------------------------------------------
# MOVE FROM STAGING TO TARGET
#--------------------------------------------------------------------------

$behavior = if ($Overwrite) { "replace" } else { "fail" }

try {

    $moved = Invoke-WithRetry `
        -Activity "Move to target" `
        -MaxRetries $Config.MaxRetries `
        -BaseDelay $Config.BaseDelay `
        -ShouldRetry { param($m) -not (Test-IsConflictError $m) } `
        -ScriptBlock {
            Move-SpItem `
                -DriveId $drive.Id `
                -ItemId $stagedItem.id `
                -DestinationFolderId $targetFolderItem.id `
                -NewName $fileName `
                -ConflictBehavior $behavior
        }

    $finalItem = Get-SpItem -DriveId $drive.Id -ItemId $moved.id

    Write-Log "Final Name  : $($finalItem.name)"
    Write-Log "Final Id    : $($finalItem.id)"
    Write-Log "Final Url   : $($finalItem.webUrl)"
}
catch {

    $message = $_.Exception.Message

    Write-LogException $_.Exception

    Remove-StagedItem -DriveId $drive.Id -Item $stagedItem

    # Someone created the target file between the pre-check and the move
    if ((Test-IsConflictError $message) -and (-not $Overwrite)) {
        Write-Log "File already exists and Overwrite is false" "ERROR"
        Exit-Upload $ExitCode.TargetExists
    }

    Write-Log "Move from staging to target failed" "ERROR"
    Exit-Upload $ExitCode.MoveFailed
}

Write-Log "Upload complete"

Exit-Upload $ExitCode.Success
