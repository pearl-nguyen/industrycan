@{
    TenantId       = "b72ac62f-06d5-4cd5-824e-ee92319a4676"
    ClientId       = "452f66fa-4eea-4ba8-885b-ad65f3bd1e2c"
    Thumbprint     = "F59E00898EF052136F3F562A4263A6D3491480AF"

    SharePointHost = "033gc.sharepoint.com"

    MaxRetries     = 3
    BaseDelay      = 5

    # How long to wait for SharePoint to compute a file's QuickXorHash
    # after upload (used to validate non-Office files without downloading)
    HashWaitSeconds = 300
}
