#--------------------------------------------------------------------------
# HttpHelpers.psm1
#   Generic helpers for calling HTTP / REST APIs:
#   URL path encoding, HTTP error classification, retry with backoff.
#   Not tied to SharePoint; reusable by any script.
#   Requires JobLogging.psm1 (Write-Log, Write-LogException) to be imported
#   by the calling script.
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
# PATH / ERROR HELPERS
#--------------------------------------------------------------------------

# URL-encodes each segment of a path so spaces, #, %, accents etc. are safe
function ConvertTo-EncodedPath {

    param([string[]]$Parts)

    $segments = @()

    foreach ($part in $Parts) {

        if ([string]::IsNullOrWhiteSpace($part)) {
            continue
        }

        foreach ($seg in ($part -split '[\\/]')) {

            if ($seg -ne '') {
                $segments += [uri]::EscapeDataString($seg)
            }
        }
    }

    return ($segments -join '/')
}

function Test-IsConflictError {

    param([string]$Message)

    return ($Message -match 'nameAlreadyExists|\(409\)|\b409\b|Conflict')
}

function Test-IsNotFoundError {

    param([string]$Message)

    return ($Message -match 'itemNotFound|NotFound|\(404\)|\b404\b')
}

#--------------------------------------------------------------------------
# RETRY
#--------------------------------------------------------------------------

# Exponential backoff with jitter: 5-10s, 10-15s, 20-25s, ...
function Get-RetryDelay {

    param(
        [int]$Attempt,
        [int]$BaseDelay = 5
    )

    return [int](($BaseDelay * [math]::Pow(2, $Attempt - 1)) +
                 (Get-Random -Minimum 1 -Maximum 6))
}

# Runs a script block with retries. $ShouldRetry receives the error message
# and returns $false for errors that must not be retried (e.g. conflicts).
function Invoke-WithRetry {

    param(
        [Parameter(Mandatory = $true)]
        [scriptblock]$ScriptBlock,

        [string]$Activity = "Operation",
        [int]$MaxRetries = 3,
        [int]$BaseDelay = 5,
        [scriptblock]$ShouldRetry = { param($Message) $true }
    )

    for ($attempt = 1; $attempt -le $MaxRetries; $attempt++) {

        try {
            Write-Log "$Activity - attempt $attempt of $MaxRetries"
            return & $ScriptBlock
        }
        catch {

            $message = $_.Exception.Message

            if ($attempt -ge $MaxRetries -or -not (& $ShouldRetry $message)) {
                throw
            }

            Write-LogException $_.Exception

            $delay = Get-RetryDelay -Attempt $attempt -BaseDelay $BaseDelay

            Write-Log "Retrying in $delay seconds" "WARN"

            Start-Sleep -Seconds $delay
        }
    }
}

Export-ModuleMember -Function `
    ConvertTo-EncodedPath,
    Test-IsConflictError,
    Test-IsNotFoundError,
    Get-RetryDelay,
    Invoke-WithRetry
