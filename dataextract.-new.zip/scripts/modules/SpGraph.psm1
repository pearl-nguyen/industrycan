#--------------------------------------------------------------------------
# SpGraph.psm1
#   Microsoft Graph / SharePoint helpers: auth, paths, folders,
#   upload (simple + chunked), download, move, delete.
#   Requires JobLogging.psm1 and HttpHelpers.psm1 to be imported by the
#   calling script (path encoding and error matching come from HttpHelpers).
#--------------------------------------------------------------------------

Add-Type -AssemblyName System.Net.Http

$script:GraphBase = "https://graph.microsoft.com/v1.0"

# Graph simple upload (PUT /content) supports files up to 250 MB;
# larger files go through an upload session in chunks
$script:SimpleUploadLimit = 250MB

# Upload session chunk size: must be a multiple of 320 KiB (this is 10 MiB)
$script:ChunkSize = 320KB * 32

# Retries per chunk before the whole upload is abandoned
$script:ChunkRetries = 5

#--------------------------------------------------------------------------
# AUTHENTICATION / SITE
#--------------------------------------------------------------------------

function Connect-SpGraph {

    param(
        [Parameter(Mandatory = $true)][string]$TenantId,
        [Parameter(Mandatory = $true)][string]$ClientId,
        [Parameter(Mandatory = $true)][string]$Thumbprint
    )

    Import-Module Microsoft.Graph.Authentication -ErrorAction Stop

    Connect-MgGraph `
        -TenantId $TenantId `
        -ClientId $ClientId `
        -CertificateThumbprint $Thumbprint `
        -NoWelcome `
        -ErrorAction Stop
}

function Disconnect-SpGraph {

    try {
        Disconnect-MgGraph -ErrorAction SilentlyContinue | Out-Null
    }
    catch {
    }
}

# Returns the site's default document library. Works regardless of
# language ("Documents", "Documents partagés", ...)
function Get-SpDrive {

    param(
        [Parameter(Mandatory = $true)][string]$SharePointHost,
        [Parameter(Mandatory = $true)][string]$SiteName
    )

    $sitePath = ConvertTo-EncodedPath @($SiteName)

    $site = Invoke-MgGraphRequest `
        -Method GET `
        -Uri "$script:GraphBase/sites/${SharePointHost}:/sites/$sitePath"

    $drive = Invoke-MgGraphRequest `
        -Method GET `
        -Uri "$script:GraphBase/sites/$($site.id)/drive"

    if (-not $drive -or -not $drive.id) {
        throw "Default document library not found"
    }

    return [pscustomobject]@{
        SiteUrl = $site.webUrl
        Id      = $drive.id
        Name    = $drive.name
    }
}

#--------------------------------------------------------------------------
# ITEMS / FOLDERS
#--------------------------------------------------------------------------

# Returns the item at the given (unencoded) path, or $null if it does not exist
function Get-SpItemByPath {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [string[]]$PathParts = @(),
        [string]$Select = "id,name,size,webUrl,folder,file,parentReference"
    )

    $encoded = ConvertTo-EncodedPath $PathParts

    if ($encoded) {
        $uri = "$script:GraphBase/drives/$DriveId/root:/$encoded"
    }
    else {
        $uri = "$script:GraphBase/drives/$DriveId/root"
    }

    $uri += "?`$select=$Select"

    try {
        return Invoke-MgGraphRequest -Method GET -Uri $uri
    }
    catch {
        if (Test-IsNotFoundError $_.Exception.Message) {
            return $null
        }
        throw
    }
}

function Get-SpItem {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [Parameter(Mandatory = $true)][string]$ItemId,
        [string]$Select = "id,name,size,webUrl,parentReference"
    )

    return Invoke-MgGraphRequest `
        -Method GET `
        -Uri "$script:GraphBase/drives/$DriveId/items/${ItemId}?`$select=$Select"
}

function New-SpFolder {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [string[]]$ParentParts = @(),
        [Parameter(Mandatory = $true)][string]$Name
    )

    $parent = ConvertTo-EncodedPath $ParentParts

    if ($parent) {
        $uri = "$script:GraphBase/drives/$DriveId/root:/${parent}:/children"
    }
    else {
        $uri = "$script:GraphBase/drives/$DriveId/root/children"
    }

    $body = @{
        name   = $Name
        folder = @{}
        "@microsoft.graph.conflictBehavior" = "fail"
    } | ConvertTo-Json

    try {
        $item = Invoke-MgGraphRequest `
            -Method POST `
            -Uri $uri `
            -Body $body `
            -ContentType "application/json"

        Write-Log "Folder created: $Name"

        return $item
    }
    catch {
        # Another job created it at the same time
        if (Test-IsConflictError $_.Exception.Message) {
            return Get-SpItemByPath -DriveId $DriveId -PathParts (@($ParentParts) + $Name)
        }
        throw
    }
}

# Returns the folder item for a path like "A/B/C", or $null if missing.
# With -CreateIfMissing, missing levels are created.
function Get-SpFolder {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [Parameter(Mandatory = $true)][string]$Path,
        [switch]$CreateIfMissing
    )

    $segments = @($Path -split '[\\/]' | Where-Object { $_ -ne '' })

    if ($segments.Count -eq 0) {
        throw "Folder path is empty"
    }

    $current = @()
    $item    = $null

    foreach ($seg in $segments) {

        $parentParts = $current
        $current    += $seg

        $item = Get-SpItemByPath -DriveId $DriveId -PathParts $current

        if (-not $item) {

            if (-not $CreateIfMissing) {
                return $null
            }

            $item = New-SpFolder -DriveId $DriveId -ParentParts $parentParts -Name $seg
        }

        if (-not $item.folder) {
            throw "'$($current -join '/')' exists but is not a folder"
        }
    }

    return $item
}

# Moves (and optionally renames) an item. ConflictBehavior applies when
# an item with the same name already exists in the destination.
function Move-SpItem {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [Parameter(Mandatory = $true)][string]$ItemId,
        [Parameter(Mandatory = $true)][string]$DestinationFolderId,
        [Parameter(Mandatory = $true)][string]$NewName,
        [ValidateSet("fail", "replace")]
        [string]$ConflictBehavior = "fail"
    )

    $body = @{
        parentReference = @{ id = $DestinationFolderId }
        name            = $NewName
    } | ConvertTo-Json -Depth 3

    return Invoke-MgGraphRequest `
        -Method PATCH `
        -Uri "$script:GraphBase/drives/$DriveId/items/${ItemId}?@microsoft.graph.conflictBehavior=$ConflictBehavior" `
        -Body $body `
        -ContentType "application/json"
}

function Remove-SpItem {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [Parameter(Mandatory = $true)][string]$ItemId
    )

    Invoke-MgGraphRequest `
        -Method DELETE `
        -Uri "$script:GraphBase/drives/$DriveId/items/$ItemId" | Out-Null
}

function Save-SpItemContent {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [Parameter(Mandatory = $true)][string]$ItemId,
        [Parameter(Mandatory = $true)][string]$OutFile
    )

    Invoke-MgGraphRequest `
        -Method GET `
        -Uri "$script:GraphBase/drives/$DriveId/items/$ItemId/content" `
        -OutputFilePath $OutFile
}

#--------------------------------------------------------------------------
# UPLOAD
#--------------------------------------------------------------------------

# Uploads a file to an encoded item path, choosing simple or chunked upload
function Send-SpFile {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [Parameter(Mandatory = $true)][string]$ItemPath,
        [Parameter(Mandatory = $true)][string]$Path,
        [ValidateSet("fail", "replace")]
        [string]$ConflictBehavior = "replace"
    )

    $size = (Get-Item -LiteralPath $Path).Length

    if ($size -gt $script:SimpleUploadLimit) {

        Write-Log "Method     : Upload session (chunked)"

        return Send-SpLargeUpload `
            -DriveId $DriveId -ItemPath $ItemPath -Path $Path `
            -ConflictBehavior $ConflictBehavior
    }

    Write-Log "Method     : Simple upload"

    return Send-SpSimpleUpload `
        -DriveId $DriveId -ItemPath $ItemPath -Path $Path `
        -ConflictBehavior $ConflictBehavior
}

# Simple upload for files up to 250 MB
function Send-SpSimpleUpload {

    param(
        [string]$DriveId,
        [string]$ItemPath,
        [string]$Path,
        [string]$ConflictBehavior
    )

    $uri = "$script:GraphBase/drives/$DriveId/root:/${ItemPath}:/content" +
           "?@microsoft.graph.conflictBehavior=$ConflictBehavior"

    return Invoke-MgGraphRequest `
        -Method PUT `
        -Uri $uri `
        -InputFilePath $Path `
        -ContentType "application/octet-stream"
}

# Chunked upload for files over 250 MB
function Send-SpLargeUpload {

    param(
        [string]$DriveId,
        [string]$ItemPath,
        [string]$Path,
        [string]$ConflictBehavior
    )

    $body = @{
        item = @{
            "@microsoft.graph.conflictBehavior" = $ConflictBehavior
        }
    } | ConvertTo-Json -Depth 3

    $session = Invoke-MgGraphRequest `
        -Method POST `
        -Uri "$script:GraphBase/drives/$DriveId/root:/${ItemPath}:/createUploadSession" `
        -Body $body `
        -ContentType "application/json"

    Write-Log "Upload session created"

    return Send-SpUploadChunks -UploadUrl $session.uploadUrl -Path $Path
}

# Cancels an upload session so SharePoint discards the partial upload
function Stop-SpUploadSession {

    param(
        $Client,
        [string]$UploadUrl
    )

    $response = $null

    try {
        $response = $Client.DeleteAsync($UploadUrl).GetAwaiter().GetResult()
        Write-Log "Upload session cancelled" "WARN"
    }
    catch {
        Write-Log "Could not cancel upload session (it expires on its own)" "WARN"
    }
    finally {
        if ($response) { $response.Dispose() }
    }
}

# Asks the upload session where to continue. Returns the next byte offset
# SharePoint expects, or $null if the session cannot be queried.
function Get-SpUploadSessionOffset {

    param(
        $Client,
        [string]$UploadUrl
    )

    $response = $null

    try {
        $response = $Client.GetAsync($UploadUrl).GetAwaiter().GetResult()

        if (-not $response.IsSuccessStatusCode) {
            return $null
        }

        $json  = $response.Content.ReadAsStringAsync().GetAwaiter().GetResult() | ConvertFrom-Json
        $range = @($json.nextExpectedRanges) | Select-Object -First 1

        if (-not $range) {
            return $null
        }

        # "26214400-" or "26214400-52428799"
        return [long](([string]$range -split '-')[0])
    }
    catch {
        return $null
    }
    finally {
        if ($response) { $response.Dispose() }
    }
}

# Sends the file in chunks to an upload session URL.
# The upload URL is pre-authenticated, so no Graph token is sent with it.
# A failed chunk is retried and the upload resumes from the byte SharePoint
# expects next, instead of restarting the whole file.
function Send-SpUploadChunks {

    param(
        [string]$UploadUrl,
        [string]$Path
    )

    $client = $null
    $fs     = $null
    $item   = $null

    try {

        $client = New-Object System.Net.Http.HttpClient
        $client.Timeout = [TimeSpan]::FromMinutes(10)

        $fs = [System.IO.File]::OpenRead($Path)

        [long]$total   = $fs.Length
        [long]$offset  = 0
        [long]$nextLog = 0
        $failures = 0
        $buffer   = New-Object byte[] $script:ChunkSize

        try {

            while ($offset -lt $total) {

                # Read the chunk at the current offset (a resume may move it)
                $count = [int][math]::Min([long]$script:ChunkSize, $total - $offset)
                $fs.Position = $offset

                $read = 0
                while ($read -lt $count) {
                    $n = $fs.Read($buffer, $read, $count - $read)
                    if ($n -le 0) {
                        throw "Unexpected end of file at byte $($offset + $read)"
                    }
                    $read += $n
                }

                $content   = $null
                $response  = $null
                $status    = 0
                $text      = ""
                $sendError = $null

                try {
                    try {
                        $content = New-Object System.Net.Http.ByteArrayContent($buffer, 0, $read)

                        $content.Headers.ContentRange =
                            New-Object System.Net.Http.Headers.ContentRangeHeaderValue(
                                $offset, ($offset + $read - 1), $total)

                        $response = $client.PutAsync($UploadUrl, $content).GetAwaiter().GetResult()
                        $status   = [int]$response.StatusCode
                        $text     = $response.Content.ReadAsStringAsync().GetAwaiter().GetResult()
                    }
                    catch {
                        # Network error or timeout: retried below
                        $sendError = $_.Exception.Message
                    }
                }
                finally {
                    try {
                        if ($content) { $content.Dispose() }
                    }
                    finally {
                        if ($response) { $response.Dispose() }
                    }
                }

                if (-not $sendError -and $status -ge 200 -and $status -lt 300) {

                    $offset  += $read
                    $failures = 0

                    # 200/201 = final chunk accepted, response body is the driveItem
                    if ($status -eq 200 -or $status -eq 201) {
                        $item = $text | ConvertFrom-Json
                    }

                    if ($offset -ge $nextLog -or $offset -ge $total) {
                        Write-Log ("Uploaded {0:N0} / {1:N0} bytes ({2:N0}%)" -f `
                            $offset, $total, (100.0 * $offset / [math]::Max(1, $total)))
                        $nextLog = $offset + [math]::Max([long]$script:ChunkSize, [long]($total / 10))
                    }

                    continue
                }

                if ($sendError) {
                    $reason = $sendError
                }
                else {
                    $reason = "HTTP $status $text"
                }

                # 404: the session expired or was lost; the caller restarts
                if ($status -eq 404) {
                    throw "Upload session no longer exists: $reason"
                }

                $failures++

                if ($failures -gt $script:ChunkRetries) {
                    throw "Chunk at byte $offset failed $failures times: $reason"
                }

                $delay = Get-RetryDelay -Attempt $failures

                Write-Log "Chunk at byte $offset failed ($reason); retry $failures of $($script:ChunkRetries) in $delay seconds" "WARN"

                Start-Sleep -Seconds $delay

                $resumeAt = Get-SpUploadSessionOffset -Client $client -UploadUrl $UploadUrl

                if ($null -ne $resumeAt -and $resumeAt -ne $offset) {
                    Write-Log "Resuming at byte $resumeAt (SharePoint already has the data before it)"
                    $offset = $resumeAt
                }
            }
        }
        catch {
            # Gave up: cancel the session so no partial upload is left behind
            Stop-SpUploadSession -Client $client -UploadUrl $UploadUrl
            throw
        }
    }
    finally {
        try {
            if ($fs) { $fs.Dispose() }
        }
        finally {
            if ($client) { $client.Dispose() }
        }
    }

    if (-not $item) {
        throw "Upload session ended without returning the uploaded item"
    }

    return $item
}

#--------------------------------------------------------------------------
# HASH
#--------------------------------------------------------------------------

# Waits until SharePoint has computed the item's QuickXorHash (usually
# immediate, sometimes a little later for large files). Returns the base64
# hash, or $null if it is still not available after $TimeoutSeconds.
function Wait-SpQuickXorHash {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [Parameter(Mandatory = $true)][string]$ItemId,
        [int]$TimeoutSeconds = 300,
        [int]$PollSeconds = 15
    )

    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)

    while ($true) {

        $item = Get-SpItem -DriveId $DriveId -ItemId $ItemId -Select "id,size,file"

        $hash = $null
        if ($item.file -and $item.file.hashes) {
            $hash = $item.file.hashes.quickXorHash
        }

        if ($hash) {
            return [string]$hash
        }

        if ((Get-Date) -gt $deadline) {
            return $null
        }

        Write-Log "SharePoint hash not available yet; checking again in $PollSeconds seconds"
        Start-Sleep -Seconds $PollSeconds
    }
}

Export-ModuleMember -Function `
    Connect-SpGraph,
    Disconnect-SpGraph,
    Get-SpDrive,
    Get-SpItemByPath,
    Get-SpItem,
    New-SpFolder,
    Get-SpFolder,
    Move-SpItem,
    Remove-SpItem,
    Save-SpItemContent,
    Send-SpFile,
    Wait-SpQuickXorHash
