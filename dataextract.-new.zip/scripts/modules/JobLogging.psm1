#--------------------------------------------------------------------------
# JobLogging.psm1
#   Daily log files: <LogFolder>\yyyyMMdd.log, one file per job per day,
#   shared by all steps. Each line is tagged with the step name, e.g.
#   2026-10-07 18:37:38 [INFO] [EXTRACT] Upload started
#--------------------------------------------------------------------------

$script:LogFile = $null
$script:Step    = $null

# Creates the log folder if needed and sets today's log file.
# Returns the full path of the log file.
function Initialize-Log {

    param(
        [Parameter(Mandatory = $true)]
        [string]$LogFolder,

        # EXTRACT, CONVERT, PUBLISH ...
        [string]$Step
    )

    if (-not (Test-Path -LiteralPath $LogFolder -PathType Container)) {
        New-Item -ItemType Directory -Path $LogFolder -Force | Out-Null
    }

    $script:LogFile = Join-Path $LogFolder ((Get-Date -Format "yyyyMMdd") + ".log")
    $script:Step    = $Step

    return $script:LogFile
}

function Write-Log {

    param(
        [Parameter(Position = 0)]
        [string]$Message,

        [Parameter(Position = 1)]
        [ValidateSet("INFO", "WARN", "ERROR")]
        [string]$Level = "INFO"
    )

    $time = Get-Date -Format "yyyy-MM-dd HH:mm:ss"

    if ($script:Step) {
        $line = "{0} [{1}] [{2}] {3}" -f $time, $Level, $script:Step, $Message
    }
    else {
        $line = "{0} [{1}] {2}" -f $time, $Level, $Message
    }

    Write-Host $line

    if ($script:LogFile) {
        try {
            Add-Content -LiteralPath $script:LogFile -Value $line -Encoding UTF8
        }
        catch {
        }
    }
}

function Write-LogException {

    param(
        [Parameter(Position = 0)]
        $Exception
    )

    Write-Log $Exception.Message "ERROR"

    if ($Exception.InnerException) {
        Write-Log $Exception.InnerException.Message "ERROR"
    }
}

Export-ModuleMember -Function Initialize-Log, Write-Log, Write-LogException
