#--------------------------------------------------------------------------
# FileRetention.psm1
#   Deletes files older than N days from one folder.
#   Safety rules:
#     - files only, never folders, never recursive
#     - only names matching the given patterns
#     - refuses to work outside the root folder (-RootGuard)
#     - every deletion is logged; supports -WhatIf for a dry run
#   Requires JobLogging.psm1 to be imported by the calling script.
#--------------------------------------------------------------------------

function Remove-ExpiredFiles {

    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,

        # 0 or less disables cleanup for this folder
        [int]$Days,

        # Wildcard patterns, e.g. "*.log" or "Report_*"
        [string[]]$Include = @("*"),

        # The folder must be inside this root
        [Parameter(Mandatory = $true)]
        [string]$RootGuard
    )

    if ($Days -le 0) {
        Write-Log "Retention disabled for $Path"
        return 0
    }

    if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
        return 0
    }

    $sep    = [System.IO.Path]::DirectorySeparatorChar
    $folder = (Resolve-Path -LiteralPath $Path).Path.TrimEnd('\', '/')
    $root   = (Resolve-Path -LiteralPath $RootGuard).Path.TrimEnd('\', '/')

    if (-not $folder.StartsWith($root + $sep, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Retention refused: '$folder' is outside '$root'"
    }

    # Whole days: with 30, files last modified before today minus 30 days go
    $cutoff = (Get-Date).Date.AddDays(-$Days)

    $files = Get-ChildItem -LiteralPath $folder -File |
        Where-Object { $_.LastWriteTime -lt $cutoff }

    $count = 0

    foreach ($file in $files) {

        $matched = $false

        foreach ($pattern in $Include) {
            if ($file.Name -like $pattern) {
                $matched = $true
                break
            }
        }

        if (-not $matched) {
            continue
        }

        if ($PSCmdlet.ShouldProcess($file.FullName, "Delete")) {

            try {
                Remove-Item -LiteralPath $file.FullName -Force
                Write-Log "Retention deleted: $($file.Name)"
                $count++
            }
            catch {
                Write-Log "Retention could not delete $($file.Name): $($_.Exception.Message)" "WARN"
            }
        }
    }

    Write-Log "Retention: $count file(s) older than $Days days removed from $folder"

    return $count
}

# Keeps only the newest $Keep files matching the patterns (by last write
# time) and deletes the rest. Same safety rules as Remove-ExpiredFiles.
# Files named in -Exclude are never deleted and not counted.
function Remove-ExcessFiles {

    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,

        [Parameter(Mandatory = $true)]
        [string[]]$Include,

        # Number of newest files to keep; 0 deletes all matching files
        [Parameter(Mandatory = $true)]
        [int]$Keep,

        [string[]]$Exclude = @(),

        [Parameter(Mandatory = $true)]
        [string]$RootGuard
    )

    if ($Keep -lt 0) {
        throw "Keep must be 0 or more"
    }

    if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
        return 0
    }

    $sep    = [System.IO.Path]::DirectorySeparatorChar
    $folder = (Resolve-Path -LiteralPath $Path).Path.TrimEnd('\', '/')
    $root   = (Resolve-Path -LiteralPath $RootGuard).Path.TrimEnd('\', '/')

    if (-not $folder.StartsWith($root + $sep, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Retention refused: '$folder' is outside '$root'"
    }

    $files = @(Get-ChildItem -LiteralPath $folder -File | Where-Object {

        $name = $_.Name

        if ($Exclude -contains $name) {
            return $false
        }

        foreach ($pattern in $Include) {
            if ($name -like $pattern) {
                return $true
            }
        }

        return $false

    } | Sort-Object LastWriteTime -Descending)

    $count = 0

    foreach ($file in ($files | Select-Object -Skip $Keep)) {

        if ($PSCmdlet.ShouldProcess($file.FullName, "Delete")) {

            try {
                Remove-Item -LiteralPath $file.FullName -Force
                Write-Log "Retention deleted: $($file.Name)"
                $count++
            }
            catch {
                Write-Log "Retention could not delete $($file.Name): $($_.Exception.Message)" "WARN"
            }
        }
    }

    Write-Log "Retention: kept newest $Keep of $($Include -join ', '); $count file(s) removed from $folder"

    return $count
}

Export-ModuleMember -Function Remove-ExpiredFiles, Remove-ExcessFiles
