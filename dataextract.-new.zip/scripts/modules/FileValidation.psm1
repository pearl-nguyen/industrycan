#--------------------------------------------------------------------------
# FileValidation.psm1
#   File checks used by all steps:
#     - SHA256 hashing
#     - Office package comparison (ignores SharePoint-injected metadata)
#     - CSV structure validation
#     - Excel workbook validation (needs the ImportExcel module, loaded
#       only when Test-ExcelFile is called)
#   Requires JobLogging.psm1 to be imported by the calling script.
#--------------------------------------------------------------------------

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
Add-Type -AssemblyName Microsoft.VisualBasic

# Office Open XML formats: SharePoint injects metadata into these on upload,
# so they are validated by comparing content parts instead of whole-file hash
$script:OfficeExtensions = @(".docx", ".docm", ".dotx", ".dotm",
                             ".xlsx", ".xlsm", ".xltx", ".xlam",
                             ".pptx", ".pptm", ".potx", ".ppsx", ".ppsm")

# Matches relationship / content-type entries that point at SharePoint's parts
$script:InjectedPattern = 'customXml|docProps/custom\.xml|custom-properties'

# Stop listing individual bad rows after this many
$script:MaxReportedProblems = 10

# QuickXorHash: the hash SharePoint / OneDrive compute for every file
# (driveItem.file.hashes.quickXorHash). Comparing it with a local hash
# validates an upload without downloading the file back.
# Port of Microsoft's reference implementation.
if (-not ('DataExtract.QuickXorHash' -as [type])) {

    Add-Type -TypeDefinition @'
using System;
using System.Security.Cryptography;

namespace DataExtract
{
    public class QuickXorHash : HashAlgorithm
    {
        private const int BitsInLastCell = 32;
        private const byte Shift = 11;
        private const byte WidthInBits = 160;

        private ulong[] _data;
        private long _lengthSoFar;
        private int _shiftSoFar;

        public QuickXorHash()
        {
            this.Initialize();
        }

        protected override void HashCore(byte[] array, int ibStart, int cbSize)
        {
            unchecked
            {
                int currentShift = _shiftSoFar;
                int vectorArrayIndex = currentShift / 64;
                int vectorOffset = currentShift % 64;
                int iterations = Math.Min(cbSize, WidthInBits);

                for (int i = 0; i < iterations; i++)
                {
                    bool isLastCell = vectorArrayIndex == _data.Length - 1;
                    int bitsInVectorCell = isLastCell ? BitsInLastCell : 64;

                    if (vectorOffset <= bitsInVectorCell - 8)
                    {
                        for (int j = ibStart + i; j < cbSize + ibStart; j += WidthInBits)
                        {
                            _data[vectorArrayIndex] ^= (ulong)array[j] << vectorOffset;
                        }
                    }
                    else
                    {
                        int index1 = vectorArrayIndex;
                        int index2 = isLastCell ? 0 : (vectorArrayIndex + 1);
                        byte low = (byte)(bitsInVectorCell - vectorOffset);

                        byte xoredByte = 0;
                        for (int j = ibStart + i; j < cbSize + ibStart; j += WidthInBits)
                        {
                            xoredByte ^= array[j];
                        }

                        _data[index1] ^= (ulong)xoredByte << vectorOffset;
                        _data[index2] ^= (ulong)xoredByte >> low;
                    }

                    vectorOffset += Shift;
                    while (vectorOffset >= bitsInVectorCell)
                    {
                        vectorArrayIndex = isLastCell ? 0 : vectorArrayIndex + 1;
                        vectorOffset -= bitsInVectorCell;
                    }
                }

                _shiftSoFar = (_shiftSoFar + Shift * (cbSize % WidthInBits)) % WidthInBits;
            }

            _lengthSoFar += cbSize;
        }

        protected override byte[] HashFinal()
        {
            byte[] rgb = new byte[(WidthInBits - 1) / 8 + 1];

            for (int i = 0; i < _data.Length - 1; i++)
            {
                Buffer.BlockCopy(BitConverter.GetBytes(_data[i]), 0, rgb, i * 8, 8);
            }

            Buffer.BlockCopy(BitConverter.GetBytes(_data[_data.Length - 1]), 0, rgb,
                (_data.Length - 1) * 8, rgb.Length - (_data.Length - 1) * 8);

            byte[] lengthBytes = BitConverter.GetBytes(_lengthSoFar);
            for (int i = 0; i < lengthBytes.Length; i++)
            {
                rgb[(WidthInBits / 8) - lengthBytes.Length + i] ^= lengthBytes[i];
            }

            return rgb;
        }

        public override void Initialize()
        {
            _data = new ulong[(WidthInBits - 1) / 64 + 1];
            _shiftSoFar = 0;
            _lengthSoFar = 0;
        }

        public override int HashSize
        {
            get { return WidthInBits; }
        }
    }
}
'@
}

#--------------------------------------------------------------------------
# HASHING
#--------------------------------------------------------------------------

function Test-IsOfficeFile {

    param([string]$Path)

    $extension = [System.IO.Path]::GetExtension($Path).ToLower()

    return ($script:OfficeExtensions -contains $extension)
}

function Get-FileSHA256 {

    param([string]$Path)

    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash
}

# Base64 QuickXorHash of a file, as SharePoint reports it
function Get-FileQuickXorHash {

    param([Parameter(Mandatory = $true)][string]$Path)

    $hash   = $null
    $stream = $null

    try {
        $hash   = New-Object DataExtract.QuickXorHash
        $stream = New-Object System.IO.FileStream(
            $Path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read,
            [System.IO.FileShare]::Read, 4MB)

        return [Convert]::ToBase64String($hash.ComputeHash($stream))
    }
    finally {
        try {
            if ($stream) { $stream.Dispose() }
        }
        finally {
            if ($hash) { $hash.Dispose() }
        }
    }
}

function Get-StringSHA256 {

    param([string]$Text)

    $sha = $null

    try {
        $sha   = [System.Security.Cryptography.SHA256]::Create()
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
        return ([BitConverter]::ToString($sha.ComputeHash($bytes)) -replace '-')
    }
    finally {
        if ($sha) { $sha.Dispose() }
    }
}

#--------------------------------------------------------------------------
# OFFICE PACKAGE COMPARISON
#--------------------------------------------------------------------------

# Returns a hashtable: part name -> SHA256, skipping SharePoint metadata parts.
# For .rels and [Content_Types].xml, entries pointing at injected parts are
# removed and the rest are compared order-independently (Ids ignored).
function Get-OfficeContentHashes {

    param([string]$Path)

    $result = @{}
    $zip    = $null
    $sha    = $null

    try {

        $zip = [System.IO.Compression.ZipFile]::OpenRead($Path)
        $sha = [System.Security.Cryptography.SHA256]::Create()

        foreach ($entry in $zip.Entries) {

            $name = $entry.FullName

            if ($name.EndsWith('/') -or
                $name.StartsWith('customXml/') -or
                $name.StartsWith('docProps/') -or
                $name.StartsWith('[trash]/')) {
                continue
            }

            $stream = $null
            $reader = $null

            try {

                $stream = $entry.Open()

                if ($name.EndsWith('.rels') -or $name -eq '[Content_Types].xml') {

                    $reader = New-Object System.IO.StreamReader($stream)

                    [xml]$xml = $reader.ReadToEnd()

                    $items = @()

                    foreach ($node in $xml.DocumentElement.ChildNodes) {

                        if ($node.NodeType -ne [System.Xml.XmlNodeType]::Element) {
                            continue
                        }

                        $attrs = ($node.Attributes |
                            Where-Object { $_.Name -ne 'Id' } |
                            Sort-Object Name |
                            ForEach-Object { "$($_.Name)=$($_.Value)" }) -join '|'

                        if ($attrs -match $script:InjectedPattern) {
                            continue
                        }

                        $items += "$($node.LocalName)|$attrs"
                    }

                    $result[$name] = Get-StringSHA256 (($items | Sort-Object) -join "`n")
                }
                else {

                    $result[$name] =
                        [BitConverter]::ToString($sha.ComputeHash($stream)) -replace '-'
                }
            }
            finally {
                # Disposing the reader also closes the entry stream;
                # the stream is disposed too in case the reader was never created
                try {
                    if ($reader) { $reader.Dispose() }
                }
                finally {
                    if ($stream) { $stream.Dispose() }
                }
            }
        }
    }
    finally {
        # Nested so the zip is closed even if the hash object fails to dispose
        try {
            if ($sha) { $sha.Dispose() }
        }
        finally {
            if ($zip) { $zip.Dispose() }
        }
    }

    return $result
}

# Returns a list of differences; empty list means content is identical
function Compare-OfficeContent {

    param(
        [string]$Original,
        [string]$Downloaded
    )

    $a = Get-OfficeContentHashes $Original
    $b = Get-OfficeContentHashes $Downloaded

    Write-Log "Office package comparison started"
    Write-Log "Original parts : $($a.Count)"
    Write-Log "Remote parts   : $($b.Count)"

    $problems = @()

    foreach ($k in $a.Keys) {

        if (-not $b.ContainsKey($k)) {
            $problems += "Missing part: $k"
        }
        elseif ($a[$k] -ne $b[$k]) {
            $problems += "Changed part: $k"
        }
    }

    foreach ($k in $b.Keys) {

        if (-not $a.ContainsKey($k)) {
            $problems += "Extra part: $k"
        }
    }

    return $problems
}

#--------------------------------------------------------------------------
# HEADER CHECKS
#--------------------------------------------------------------------------

# Empty or duplicate column names break Import-Csv and confuse users
function Get-HeaderProblems {

    param([string[]]$Header)

    $problems = @()

    for ($i = 0; $i -lt $Header.Count; $i++) {

        if ([string]::IsNullOrWhiteSpace($Header[$i])) {
            $problems += "Column $($i + 1) has an empty name"
        }
    }

    $dups = $Header |
        Where-Object { -not [string]::IsNullOrWhiteSpace($_) } |
        Group-Object |
        Where-Object { $_.Count -gt 1 }

    foreach ($d in $dups) {
        $problems += "Duplicate column name '$($d.Name)' (use distinct aliases in the SQL)"
    }

    return $problems
}

function Compare-Header {

    param(
        [string[]]$Actual,
        [string[]]$Expected
    )

    $problems = @()

    if ($Actual.Count -ne $Expected.Count) {
        $problems += "Column count is $($Actual.Count), expected $($Expected.Count)"
        return $problems
    }

    for ($i = 0; $i -lt $Expected.Count; $i++) {

        if ($Actual[$i] -cne $Expected[$i]) {
            $problems += "Column $($i + 1) is '$($Actual[$i])', expected '$($Expected[$i])'"
        }
    }

    return $problems
}

#--------------------------------------------------------------------------
# CSV
#--------------------------------------------------------------------------

# Reads only the header row with the CSV parser (quoted names handled).
# Returns an empty array for an empty file.
function Get-CsvHeader {

    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    $parser = $null

    try {
        $parser = New-Object Microsoft.VisualBasic.FileIO.TextFieldParser(
            $Path, [System.Text.Encoding]::UTF8)

        $parser.TextFieldType = [Microsoft.VisualBasic.FileIO.FieldType]::Delimited
        $parser.SetDelimiters(",")
        $parser.HasFieldsEnclosedInQuotes = $true
        $parser.TrimWhiteSpace = $false

        if ($parser.EndOfData) {
            return @()
        }

        return [string[]]$parser.ReadFields()
    }
    finally {
        if ($parser) { $parser.Dispose() }
    }
}

# Parses the whole CSV (quoted fields, embedded commas/newlines handled) and
# returns Rows (data rows, header excluded), Columns, Header and Problems.
# Problems is empty when the file is valid.
function Test-CsvFile {

    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,

        # Data rows expected; -1 skips the check
        [long]$ExpectedRows = -1,

        # Expected column names in order; omit to skip the check
        [string[]]$ExpectedHeader
    )

    $problems = @()
    $header   = @()
    [long]$rows    = 0
    [long]$badRows = 0
    $parser   = $null

    try {

        $parser = New-Object Microsoft.VisualBasic.FileIO.TextFieldParser(
            $Path, [System.Text.Encoding]::UTF8)

        $parser.TextFieldType = [Microsoft.VisualBasic.FileIO.FieldType]::Delimited
        $parser.SetDelimiters(",")
        $parser.HasFieldsEnclosedInQuotes = $true
        $parser.TrimWhiteSpace = $false

        if ($parser.EndOfData) {
            $problems += "File is empty (no header row)"
        }
        else {

            $header = [string[]]$parser.ReadFields()

            while (-not $parser.EndOfData) {

                $fields = $parser.ReadFields()
                $rows++

                if ($fields.Count -ne $header.Count) {

                    $badRows++

                    if ($badRows -le $script:MaxReportedProblems) {
                        $problems += "Data row $rows has $($fields.Count) fields, expected $($header.Count)"
                    }
                }
            }

            if ($badRows -gt $script:MaxReportedProblems) {
                $problems += "... $badRows rows in total have the wrong number of fields"
            }
        }
    }
    catch {
        $problems += "CSV could not be parsed near data row $($rows + 1): $($_.Exception.Message)"
    }
    finally {
        if ($parser) { $parser.Dispose() }
    }

    if ($header.Count -gt 0) {

        $problems += @(Get-HeaderProblems $header)

        if ($ExpectedHeader) {
            $problems += @(Compare-Header -Actual $header -Expected $ExpectedHeader)
        }
    }

    if ($ExpectedRows -ge 0 -and $rows -ne $ExpectedRows) {
        $problems += "CSV has $rows data rows, expected $ExpectedRows"
    }

    return [pscustomobject]@{
        Rows     = $rows
        Columns  = $header.Count
        Header   = $header
        Problems = @($problems)
    }
}

#--------------------------------------------------------------------------
# EXCEL
#--------------------------------------------------------------------------

# Opens the workbook read-only and checks the worksheet's data rows,
# column count and header. Returns Rows, Columns, Header and Problems.
function Test-ExcelFile {

    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,

        [Parameter(Mandatory = $true)]
        [string]$WorksheetName,

        [long]$ExpectedRows = -1,

        [string[]]$ExpectedHeader
    )

    Import-Module ImportExcel -ErrorAction Stop

    $problems = @()
    $header   = @()
    [long]$rows = 0
    $pkg      = $null

    try {

        $pkg = Open-ExcelPackage -Path $Path

        $ws = $pkg.Workbook.Worksheets[$WorksheetName]

        if (-not $ws) {
            $problems += "Worksheet '$WorksheetName' not found"
        }
        elseif (-not $ws.Dimension) {
            $problems += "Worksheet '$WorksheetName' is empty"
        }
        else {

            $rows = $ws.Dimension.End.Row - 1
            $cols = $ws.Dimension.End.Column

            $header = [string[]](1..$cols | ForEach-Object { [string]$ws.Cells[1, $_].Value })
        }
    }
    catch {
        $problems += "Workbook could not be opened: $($_.Exception.Message)"
    }
    finally {
        if ($pkg) {
            Close-ExcelPackage -ExcelPackage $pkg -NoSave
        }
    }

    if ($header.Count -gt 0 -and $ExpectedHeader) {
        $problems += @(Compare-Header -Actual $header -Expected $ExpectedHeader)
    }

    if ($ExpectedRows -ge 0 -and $rows -ne $ExpectedRows) {
        $problems += "Worksheet has $rows data rows, expected $ExpectedRows"
    }

    return [pscustomobject]@{
        Rows     = $rows
        Columns  = $header.Count
        Header   = $header
        Problems = @($problems)
    }
}

Export-ModuleMember -Function `
    Test-IsOfficeFile,
    Get-FileSHA256,
    Get-FileQuickXorHash,
    Get-StringSHA256,
    Get-OfficeContentHashes,
    Compare-OfficeContent,
    Get-CsvHeader,
    Test-CsvFile,
    Test-ExcelFile
