#--------------------------------------------------------------------------
# OracleExport.psm1
#   Oracle access through the ODP.NET Managed Driver
#   (Oracle.ManagedDataAccess.dll - no Oracle client install needed)
#   and streaming export of a query result to CSV.
#   Requires JobLogging.psm1 to be imported by the calling script.
#--------------------------------------------------------------------------

$script:Invariant       = [System.Globalization.CultureInfo]::InvariantCulture
$script:CsvSpecialChars = [char[]]@(',', '"', "`r", "`n")

#--------------------------------------------------------------------------
# SETUP
#--------------------------------------------------------------------------

function Import-OracleDriver {

    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    if ('Oracle.ManagedDataAccess.Client.OracleConnection' -as [type]) {
        return
    }

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "Oracle driver not found: $Path"
    }

    Add-Type -Path $Path
}

# Reads a .sql file and removes the SQL*Plus / Toad terminators
# (trailing ';' or a '/' line) that ODP.NET does not accept
function Read-SqlFile {

    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    $sql = Get-Content -LiteralPath $Path -Raw -Encoding UTF8

    if ([string]::IsNullOrWhiteSpace($sql)) {
        throw "SQL file is empty: $Path"
    }

    $sql = $sql -replace '(\r?\n)\s*/\s*$', ''
    $sql = $sql.Trim().TrimEnd(';').Trim()

    return $sql
}

#--------------------------------------------------------------------------
# CONNECTION / COMMANDS
#--------------------------------------------------------------------------

# Returns an open connection; the caller must dispose it.
# The connection string is built here and never logged.
function New-OracleConnection {

    param(
        [Parameter(Mandatory = $true)]
        [string]$DataSource,

        [Parameter(Mandatory = $true)]
        [System.Management.Automation.PSCredential]$Credential,

        [int]$ConnectionTimeout = 30
    )

    $builder = New-Object Oracle.ManagedDataAccess.Client.OracleConnectionStringBuilder
    $builder["Data Source"]        = $DataSource
    $builder["User Id"]            = $Credential.UserName
    $builder["Password"]           = $Credential.GetNetworkCredential().Password
    $builder["Connection Timeout"] = $ConnectionTimeout
    $builder["Pooling"]            = $false

    $conn = New-Object Oracle.ManagedDataAccess.Client.OracleConnection($builder.ConnectionString)

    try {
        $conn.Open()
    }
    catch {
        $conn.Dispose()
        throw
    }

    return $conn
}

function New-OracleCommand {

    param(
        $Connection,
        $Transaction,
        [string]$Sql,
        [int]$CommandTimeout
    )

    $cmd = $Connection.CreateCommand()

    try {
        $cmd.CommandText    = $Sql
        $cmd.CommandTimeout = $CommandTimeout

        if ($Transaction) {
            $cmd.Transaction = $Transaction
        }
    }
    catch {
        # Not returned to the caller, so it must be disposed here
        $cmd.Dispose()
        throw
    }

    # Fetch CLOB values in full with the row instead of one round trip each
    try {
        $cmd.InitialLOBFetchSize = -1
    }
    catch {
    }

    return $cmd
}

# Rolls back and disposes a transaction, then disposes its connection.
# Never throws: used in finally blocks, where it must not hide the real error.
function Close-OracleConnection {

    param(
        $Connection,
        $Transaction
    )

    if ($Transaction) {
        try { $Transaction.Rollback() } catch { }
        try { $Transaction.Dispose()  } catch { }
    }

    if ($Connection) {
        try { $Connection.Dispose() } catch { }
    }
}

# Runs a query that returns one value (e.g. the count SQL)
function Invoke-OracleScalar {

    param(
        [Parameter(Mandatory = $true)] $Connection,
        $Transaction,
        [Parameter(Mandatory = $true)] [string]$Sql,
        [int]$CommandTimeout = 1800
    )

    $cmd = $null

    try {
        $cmd = New-OracleCommand -Connection $Connection -Transaction $Transaction `
                                 -Sql $Sql -CommandTimeout $CommandTimeout

        return $cmd.ExecuteScalar()
    }
    finally {
        if ($cmd) { $cmd.Dispose() }
    }
}

#--------------------------------------------------------------------------
# CSV EXPORT
#--------------------------------------------------------------------------

# Streams the query result to a UTF-8 (with BOM, so Excel shows accents)
# CSV file, row by row, without loading the result into memory.
# Fields are quoted only when they contain a comma, quote or line break.
# Returns Rows, Columns and Header.
function Export-OracleQueryToCsv {

    param(
        [Parameter(Mandatory = $true)] $Connection,
        $Transaction,
        [Parameter(Mandatory = $true)] [string]$Sql,
        [Parameter(Mandatory = $true)] [string]$Path,
        [string]$DateFormat = "yyyy-MM-dd HH:mm:ss",
        [int]$CommandTimeout = 1800,
        [int]$FetchRows = 1000,
        [int]$ProgressEvery = 100000
    )

    $inv     = $script:Invariant
    $special = $script:CsvSpecialChars

    $cmd    = $null
    $reader = $null
    $writer = $null

    try {

        $cmd = New-OracleCommand -Connection $Connection -Transaction $Transaction `
                                 -Sql $Sql -CommandTimeout $CommandTimeout

        $reader = $cmd.ExecuteReader()

        # Bigger fetch batches = fewer round trips to the database
        try {
            $reader.FetchSize = $reader.RowSize * $FetchRows
        }
        catch {
        }

        # NUMBER values with more than 28 digits (e.g. AVG results) would
        # otherwise throw an overflow; they are rounded to 28 digits instead
        try {
            $reader.SuppressGetDecimalInvalidCastException = $true
        }
        catch {
        }

        $fieldCount = $reader.FieldCount
        $header     = [string[]](0..($fieldCount - 1) | ForEach-Object { $reader.GetName($_) })

        $writer = New-Object System.IO.StreamWriter(
            $Path, $false, (New-Object System.Text.UTF8Encoding($true)))

        # Header
        $fields = New-Object string[] $fieldCount

        for ($i = 0; $i -lt $fieldCount; $i++) {

            $s = $header[$i]

            if ($s.IndexOfAny($special) -ge 0) {
                $s = '"' + $s.Replace('"', '""') + '"'
            }

            $fields[$i] = $s
        }

        $writer.WriteLine([string]::Join(',', $fields))

        # Rows (formatting is inlined: a function call per field is slow)
        [long]$rows = 0

        while ($reader.Read()) {

            for ($i = 0; $i -lt $fieldCount; $i++) {

                if ($reader.IsDBNull($i)) {
                    $fields[$i] = ''
                    continue
                }

                $v = $reader.GetValue($i)

                if ($v -is [datetime]) {
                    $s = $v.ToString($DateFormat, $inv)
                }
                elseif ($v -is [byte[]]) {
                    $s = [Convert]::ToBase64String($v)
                }
                elseif ($v -is [System.IFormattable]) {
                    # Invariant culture: always '.' as decimal separator,
                    # even on a French-Canadian machine
                    $s = $v.ToString($null, $inv)
                }
                else {
                    $s = [string]$v
                }

                if ($s.IndexOfAny($special) -ge 0) {
                    $s = '"' + $s.Replace('"', '""') + '"'
                }

                $fields[$i] = $s
            }

            $writer.WriteLine([string]::Join(',', $fields))

            $rows++

            if ($rows % $ProgressEvery -eq 0) {
                Write-Log ("Rows written: {0:N0}" -f $rows)
            }
        }

        # Flush here, inside try, so a write error (e.g. disk full) fails
        # the export instead of surfacing during cleanup
        $writer.Flush()

        return [pscustomobject]@{
            Rows    = $rows
            Columns = $fieldCount
            Header  = $header
        }
    }
    finally {
        # Nested so each object is disposed even if an earlier Dispose throws
        try {
            if ($writer) { $writer.Dispose() }
        }
        finally {
            try {
                if ($reader) { $reader.Dispose() }
            }
            finally {
                if ($cmd) { $cmd.Dispose() }
            }
        }
    }
}

Export-ModuleMember -Function `
    Import-OracleDriver,
    Read-SqlFile,
    New-OracleConnection,
    Close-OracleConnection,
    Invoke-OracleScalar,
    Export-OracleQueryToCsv
