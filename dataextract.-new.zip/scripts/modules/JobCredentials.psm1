#--------------------------------------------------------------------------
# JobCredentials.psm1
#   Named credentials stored with Windows DPAPI in <root>\secure\<Name>.xml
#   (created by set_credential.ps1). Only the Windows account that saved a
#   file, on the same machine, can decrypt it.
#
#   Names used by the jobs (see job_config.psd1 and jobs.psd1), e.g.
#     db_credential   report database (extract jobs)
#     prod_emc        prod user that runs the copy (copy2tdb.sql)
#     xe_emctdb       local XE user the DB link connects to
#     xe_system       SYSTEM on XE (expdp)
#     sftp_6ghz       SFTP upload account
#--------------------------------------------------------------------------

function Get-CredentialPath {

    param(
        [Parameter(Mandatory = $true)][string]$Root,
        [Parameter(Mandatory = $true)][string]$Name
    )

    if ($Name -notmatch '^[A-Za-z0-9_\-]+$') {
        throw "Invalid credential name '$Name' (letters, digits, _ and - only)"
    }

    return Join-Path $Root "secure\$Name.xml"
}

function Get-StoredCredential {

    param(
        [Parameter(Mandatory = $true)][string]$Root,
        [Parameter(Mandatory = $true)][string]$Name
    )

    $path = Get-CredentialPath -Root $Root -Name $Name

    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        throw ("Credential '$Name' not found: $path. Run set_credential.ps1 -Name $Name " +
               "as $env:USERDOMAIN\$env:USERNAME on this machine.")
    }

    try {
        $cred = Import-Clixml -LiteralPath $path
    }
    catch {
        throw ("Credential '$Name' could not be decrypted. It must be saved by the same " +
               "Windows account on the same machine (run set_credential.ps1 -Name $Name " +
               "as $env:USERDOMAIN\$env:USERNAME). $($_.Exception.Message)")
    }

    if (-not ($cred -is [System.Management.Automation.PSCredential])) {
        throw "Credential file does not contain a credential: $path"
    }

    return $cred
}

function Save-StoredCredential {

    param(
        [Parameter(Mandatory = $true)][string]$Root,
        [Parameter(Mandatory = $true)][string]$Name,
        [Parameter(Mandatory = $true)][System.Management.Automation.PSCredential]$Credential
    )

    $path   = Get-CredentialPath -Root $Root -Name $Name
    $folder = Split-Path $path -Parent

    if (-not (Test-Path -LiteralPath $folder -PathType Container)) {
        New-Item -ItemType Directory -Path $folder -Force | Out-Null
    }

    $Credential | Export-Clixml -Path $path -Force

    return $path
}

Export-ModuleMember -Function Get-CredentialPath, Get-StoredCredential, Save-StoredCredential
