#--------------------------------------------------------------------------
# WinScpTransfer.psm1
#   SFTP upload through the WinSCP .NET assembly (WinSCPnet.dll).
#   WinSCPnet.dll and WinSCP.exe must be the SAME version: copy both from
#   the WinSCP ".NET assembly / COM library" download into lib\WinSCP.
#   Requires JobLogging.psm1 to be imported by the calling script.
#--------------------------------------------------------------------------

function Import-WinScp {

    param(
        [Parameter(Mandatory = $true)][string]$Folder
    )

    if ('WinSCP.Session' -as [type]) {
        return
    }

    $dll = Join-Path $Folder "WinSCPnet.dll"
    $exe = Join-Path $Folder "WinSCP.exe"

    foreach ($f in @($dll, $exe)) {
        if (-not (Test-Path -LiteralPath $f -PathType Leaf)) {
            throw "WinSCP file not found: $f"
        }
    }

    Add-Type -Path $dll
}

# Uploads one file and checks the remote size. Errors are prefixed with the
# stage that failed: "CONNECT:", "UPLOAD:" or "VERIFY:".
# The session (and the WinSCP.exe process behind it) is always disposed.
function Send-SftpFile {

    param(
        [Parameter(Mandatory = $true)][string]$WinScpFolder,
        [Parameter(Mandatory = $true)][string]$HostName,
        [int]$Port = 22,
        # "ssh-ed25519 255 xxxxxxxx..." from the WinSCP log or GUI
        [Parameter(Mandatory = $true)][string]$HostKey,
        [Parameter(Mandatory = $true)][System.Management.Automation.PSCredential]$Credential,
        [Parameter(Mandatory = $true)][string]$LocalFile,
        [string]$RemoteFolder = "/",
        [Parameter(Mandatory = $true)][string]$RemoteFileName,
        # Default: files over 100 KB go up as .filepart and are renamed at the end
        # Off:     write the final name directly (for servers that refuse renames)
        [ValidateSet("Default", "On", "Off", "Smart")]
        [string]$ResumeSupport = "Default",
        [string]$SessionLogPath,
        [int]$TimeoutSeconds = 60
    )

    if ($RemoteFileName -match '[\*\?\\/]') {
        throw "Remote file name must not contain * ? / or \: $RemoteFileName"
    }

    $localSize  = (Get-Item -LiteralPath $LocalFile).Length
    $remotePath = [WinSCP.RemotePath]::Combine($RemoteFolder, $RemoteFileName)
    $session    = $null

    try {
        $options = New-Object WinSCP.SessionOptions
        $options.Protocol              = [WinSCP.Protocol]::Sftp
        $options.HostName              = $HostName
        $options.PortNumber            = $Port
        $options.UserName              = $Credential.UserName
        $options.SecurePassword        = $Credential.Password
        $options.SshHostKeyFingerprint = $HostKey
        $options.Timeout               = [TimeSpan]::FromSeconds($TimeoutSeconds)

        $session = New-Object WinSCP.Session
        $session.ExecutablePath = Join-Path $WinScpFolder "WinSCP.exe"

        if ($SessionLogPath) {
            $session.SessionLogPath = $SessionLogPath
        }

        try {
            $session.Open($options)
        }
        catch {
            throw "CONNECT: $($_.Exception.Message)"
        }

        Write-Log "Connected to $HostName`:$Port"

        $transfer = New-Object WinSCP.TransferOptions
        $transfer.TransferMode        = [WinSCP.TransferMode]::Binary
        $transfer.OverwriteMode       = [WinSCP.OverwriteMode]::Overwrite
        $transfer.ResumeSupport.State = [WinSCP.TransferResumeSupportState]::$ResumeSupport

        try {
            $result = $session.PutFiles(
                [WinSCP.RemotePath]::EscapeFileMask($LocalFile), $remotePath, $false, $transfer)

            # Throws the first transfer error, if any
            $result.Check()

            if ($result.Transfers.Count -ne 1) {
                throw "expected 1 file transferred, got $($result.Transfers.Count)"
            }
        }
        catch {
            throw "UPLOAD: $($_.Exception.Message)"
        }

        Write-Log "Uploaded to $remotePath"

        try {
            $info = $session.GetFileInfo($remotePath)
        }
        catch {
            throw "VERIFY: remote file not found after upload: $($_.Exception.Message)"
        }

        if ($info.Length -ne $localSize) {
            throw "VERIFY: remote size $($info.Length) differs from local size $localSize"
        }

        return [pscustomobject]@{
            RemotePath = $remotePath
            Size       = $info.Length
        }
    }
    finally {
        if ($session) {
            $session.Dispose()
        }
    }
}

Export-ModuleMember -Function Import-WinScp, Send-SftpFile
