#--------------------------------------------------------------------------
# OracleTools.psm1
#   Runs Oracle command-line tools and reads their output:
#     - Invoke-LoggedProcess   run an exe, stream its output to the job log,
#                              feed secrets through stdin, enforce a timeout
#     - Invoke-SqlPlusScript   run a .sql script with SQL*Plus (/nolog);
#                              passwords are passed as DEFINEs on stdin,
#                              never on the command line or in a file
#     - Invoke-DataPumpExport  run expdp with a temporary parameter file
#                              (holds the password; deleted afterwards)
#     - Find-OracleErrors      ORA- / SP2- / PLS- lines in output
#     - Get-CountLines         NAME_ROWS=123 lines printed by the scripts
#     - Read-ExpdpLog          completion, errors and rows per table
#   Requires JobLogging.psm1 to be imported by the calling script.
#--------------------------------------------------------------------------

#--------------------------------------------------------------------------
# PROCESS
#--------------------------------------------------------------------------

# Starts a process, writes $StdinLines to its standard input (never logged),
# logs every output line as it arrives and returns ExitCode, Output, TimedOut.
# Process and streams are always disposed; on timeout the process is killed.
function Invoke-LoggedProcess {

    param(
        [Parameter(Mandatory = $true)][string]$FilePath,
        [string]$Arguments = "",
        [string]$WorkingDirectory = (Get-Location).Path,
        [string[]]$StdinLines = @(),
        [hashtable]$Environment = @{},
        # 0 = no limit
        [double]$TimeoutMinutes = 0,
        [string]$LogPrefix = ""
    )

    if (-not (Test-Path -LiteralPath $FilePath -PathType Leaf)) {
        throw "Program not found: $FilePath"
    }

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName               = $FilePath
    $psi.Arguments              = $Arguments
    $psi.WorkingDirectory       = $WorkingDirectory
    $psi.UseShellExecute        = $false
    $psi.CreateNoWindow         = $true
    $psi.RedirectStandardInput  = $true
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError  = $true

    foreach ($key in $Environment.Keys) {
        $psi.EnvironmentVariables[$key] = [string]$Environment[$key]
    }

    $output   = New-Object System.Collections.Generic.List[string]
    $timedOut = $false
    $process  = New-Object System.Diagnostics.Process
    $process.StartInfo = $psi

    try {
        [void]$process.Start()

        # Secrets go through stdin; closing it lets the tool exit at the end
        try {
            foreach ($line in $StdinLines) {
                $process.StandardInput.WriteLine($line)
            }
        }
        catch {
            Write-Log "Could not write to $([IO.Path]::GetFileName($FilePath)) input: $($_.Exception.Message)" "WARN"
        }
        finally {
            try { $process.StandardInput.Close() } catch { }
        }

        # Stderr is drained in the background so the process never blocks on it
        $errTask = $process.StandardError.ReadToEndAsync()

        $deadline = $null
        if ($TimeoutMinutes -gt 0) {
            $deadline = (Get-Date).AddMinutes($TimeoutMinutes)
        }

        # Read stdout line by line without blocking, so the timeout is checked
        $readTask = $null

        while ($true) {

            if (-not $readTask) {
                $readTask = $process.StandardOutput.ReadLineAsync()
            }

            if ($readTask.Wait(1000)) {

                $line     = $readTask.Result
                $readTask = $null

                if ($null -eq $line) {
                    break    # end of output: the process is exiting
                }

                $output.Add($line)

                if ($line.Trim()) {
                    Write-Log "$LogPrefix$line"
                }
            }
            elseif ($deadline -and (Get-Date) -gt $deadline) {

                $timedOut = $true
                Write-Log "Timeout after $TimeoutMinutes minutes: stopping $([IO.Path]::GetFileName($FilePath))" "ERROR"

                try { $process.Kill() } catch { }
                break
            }
        }

        [void]$process.WaitForExit(60000)

        if ($errTask.Wait(10000)) {
            foreach ($line in ($errTask.Result -split "\r?\n")) {
                if ($line.Trim()) {
                    $output.Add($line)
                    Write-Log "$LogPrefix$line"
                }
            }
        }

        $exitCode = -1
        if ($process.HasExited) {
            $exitCode = $process.ExitCode
        }

        return [pscustomobject]@{
            ExitCode = $exitCode
            Output   = $output.ToArray()
            TimedOut = $timedOut
        }
    }
    finally {
        $process.Dispose()
    }
}

#--------------------------------------------------------------------------
# SQL*PLUS
#--------------------------------------------------------------------------

# Runs a script with "sqlplus -S /nolog". $Defines (name -> value) are sent
# as DEFINE commands on stdin before the script, so passwords never appear
# on the command line, in a file or in the log. The script runs from its
# own folder, so START/@ of sibling scripts works as before.
function Invoke-SqlPlusScript {

    param(
        [Parameter(Mandatory = $true)][string]$SqlPlusPath,
        [Parameter(Mandatory = $true)][string]$ScriptPath,
        [System.Collections.IDictionary]$Defines = @{},
        [hashtable]$Environment = @{},
        [double]$TimeoutMinutes = 0,
        [string]$LogPrefix = "sqlplus> "
    )

    if (-not (Test-Path -LiteralPath $ScriptPath -PathType Leaf)) {
        throw "SQL script not found: $ScriptPath"
    }

    $stdin = New-Object System.Collections.Generic.List[string]
    $stdin.Add("SET DEFINE ON")

    foreach ($name in $Defines.Keys) {

        $value = [string]$Defines[$name]

        if ($value.Contains('"') -or $value -match '[\r\n]') {
            throw "Value for DEFINE $name contains a double quote or line break, which SQL*Plus cannot take"
        }

        $stdin.Add("DEFINE $name = `"$value`"")
    }

    $stdin.Add("@`"$ScriptPath`"")
    $stdin.Add("EXIT")

    return Invoke-LoggedProcess `
        -FilePath $SqlPlusPath `
        -Arguments "-S /nolog" `
        -WorkingDirectory (Split-Path $ScriptPath -Parent) `
        -StdinLines $stdin.ToArray() `
        -Environment $Environment `
        -TimeoutMinutes $TimeoutMinutes `
        -LogPrefix $LogPrefix
}

# Lines reporting an Oracle, SQL*Plus or PL/SQL error
function Find-OracleErrors {

    param([string[]]$Lines)

    return @($Lines | Where-Object { $_ -match '\b(ORA|SP2|PLS)-\d{4,5}\b' })
}

# Collects lines like "IMPORTED_TX_ROWS=12345" into a hashtable
function Get-CountLines {

    param([string[]]$Lines)

    $counts = @{}

    foreach ($line in $Lines) {
        if ($line -match '^\s*([A-Z][A-Z0-9_]*_ROWS)\s*=\s*(\d+)\s*$') {
            $counts[$Matches[1]] = [long]$Matches[2]
        }
    }

    return $counts
}

#--------------------------------------------------------------------------
# DATA PUMP
#--------------------------------------------------------------------------

# Runs expdp with a temporary parameter file built from $ParameterLines
# (which include USERID with the password). The file is created in the
# job account's own %TEMP% folder and always deleted afterwards.
function Invoke-DataPumpExport {

    param(
        [Parameter(Mandatory = $true)][string]$ExpdpPath,
        [Parameter(Mandatory = $true)][string[]]$ParameterLines,
        [hashtable]$Environment = @{},
        [double]$TimeoutMinutes = 0,
        [string]$LogPrefix = "expdp> "
    )

    $parFile = Join-Path ([System.IO.Path]::GetTempPath()) ("dx_" + [guid]::NewGuid().ToString("N") + ".par")

    try {
        # ASCII: expdp reads the parameter file in the client character set
        [System.IO.File]::WriteAllLines($parFile, $ParameterLines, [System.Text.Encoding]::ASCII)

        return Invoke-LoggedProcess `
            -FilePath $ExpdpPath `
            -Arguments "parfile=`"$parFile`"" `
            -WorkingDirectory ([System.IO.Path]::GetTempPath()) `
            -Environment $Environment `
            -TimeoutMinutes $TimeoutMinutes `
            -LogPrefix $LogPrefix
    }
    finally {
        Remove-Item -LiteralPath $parFile -Force -ErrorAction SilentlyContinue
    }
}

# Reads an expdp log: Completed (job "successfully completed" without
# errors), Errors (ORA- lines) and Rows (table name -> rows; partitions summed)
function Read-ExpdpLog {

    param([Parameter(Mandatory = $true)][string]$Path)

    $lines = @(Get-Content -LiteralPath $Path)

    $rows = @{}

    foreach ($line in $lines) {

        # . . exported "EMCTDB"."TX_RES_TAB"      1.234 GB  1234567 rows
        # . . exported "EMCTDB"."T":"P1"           10.5 MB     1000 rows
        if ($line -match 'exported\s+"[^"]+"\."([^"]+)"(?::"[^"]+")?\s.*?(\d+)\s+rows\s*$') {

            $table = $Matches[1].ToUpperInvariant()

            if (-not $rows.ContainsKey($table)) {
                $rows[$table] = [long]0
            }

            $rows[$table] += [long]$Matches[2]
        }
    }

    $completed = [bool]($lines | Where-Object { $_ -match 'successfully completed' -and $_ -notmatch 'with \d+ error' })

    return [pscustomobject]@{
        Completed = $completed
        Errors    = @(Find-OracleErrors $lines)
        Rows      = $rows
    }
}

Export-ModuleMember -Function `
    Invoke-LoggedProcess,
    Invoke-SqlPlusScript,
    Find-OracleErrors,
    Get-CountLines,
    Invoke-DataPumpExport,
    Read-ExpdpLog
