<#
.SYNOPSIS
    Runs one job from jobs.psd1: all its steps in order, stopping at the
    first failure. This is what Task Scheduler calls.

.DESCRIPTION
    1. Cleans up old logs (and old CSV/Excel outputs) per job_config.psd1
    2. Runs each step of the job type in its own PowerShell process
    3. Stops at the first failed step and exits with that step's code,
       logging the command to rerun from that step

    Every step gets the same -RunDate, so a job that runs past midnight
    still uses one date for all its files.

.EXAMPLE
    Scheduled run:
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File C:\SPECTRA_Automation\DataExtract\scripts\run_job.ps1 -JobName EMC_TDB_FREQPLAN

    Rerun only the upload of today's dump after a failure:
    ... -JobName EMC_TDB_FREQPLAN -From publish

    Rerun from the convert step for an earlier day:
    ... -JobName Reinstate_LIC -From convert -RunDate 20261006
#>

param(
    [Parameter(Mandatory = $true)]
    [string]$JobName,

    # Start at this step instead of the first one (manual rerun)
    [ValidateSet("extract", "convert", "copy", "dump", "publish")]
    [string]$From,

    # yyyyMMdd used in every file name of this run; defaults to today
    [string]$RunDate = (Get-Date -Format "yyyyMMdd")
)

$ErrorActionPreference = "Stop"

$Root         = Split-Path $PSScriptRoot -Parent
$ModuleFolder = Join-Path $PSScriptRoot "modules"
$LogFolder    = Join-Path $Root "logs\$JobName"
$OutputFolder = Join-Path $Root "output\$JobName"

try {
    Import-Module (Join-Path $ModuleFolder "ExitCodes.psm1") -Force
}
catch {
    Write-Host "Setup failed: $($_.Exception.Message)"
    exit 3   # SetupFailed (ExitCodes.psm1 itself could not be loaded)
}

try {
    Import-Module (Join-Path $ModuleFolder "JobLogging.psm1")    -Force
    Import-Module (Join-Path $ModuleFolder "FileRetention.psm1") -Force

    $Config  = Import-PowerShellDataFile -Path (Join-Path $PSScriptRoot "job_config.psd1")
    $Jobs    = Import-PowerShellDataFile -Path (Join-Path $PSScriptRoot "jobs.psd1")
    $logPath = Initialize-Log -LogFolder $LogFolder -Step "RUN"
}
catch {
    Write-Host "Setup failed: $($_.Exception.Message)"
    exit $ExitCode.SetupFailed
}

function Exit-Job {

    param([int]$Code)

    Write-Log "Job finished with exit code $Code ($(Get-ExitCodeName $Code))"

    exit $Code
}

trap {
    Write-LogException $_.Exception
    Exit-Job $ExitCode.Unexpected
}

#--------------------------------------------------------------------------
# JOB DEFINITION
#--------------------------------------------------------------------------

$StepsByType = @{
    CsvToSftp         = @("extract", "publish")
    CsvToSharePoint   = @("extract", "publish")
    ExcelToSharePoint = @("extract", "convert", "publish")
    DumpToSharePoint  = @("copy", "dump", "publish")
}

Write-Log "####################################################"
Write-Log "Job started: $JobName"
Write-Log "Run date   : $RunDate"
Write-Log "Log file   : $logPath"

if ($RunDate -notmatch '^\d{8}$') {
    Write-Log "Invalid -RunDate '$RunDate' (expected yyyyMMdd)" "ERROR"
    Exit-Job $ExitCode.InvalidArgument
}

if (-not $Jobs.ContainsKey($JobName)) {
    Write-Log "Job '$JobName' is not defined in jobs.psd1" "ERROR"
    Exit-Job $ExitCode.InvalidArgument
}

$Job  = $Jobs[$JobName]
$Type = $Job.Type

if (-not $StepsByType.ContainsKey([string]$Type)) {
    Write-Log "Job '$JobName' has unknown Type '$Type'" "ERROR"
    Exit-Job $ExitCode.InvalidArgument
}

$steps = @($StepsByType[$Type])

if ($From) {

    $index = [array]::IndexOf($steps, $From)

    if ($index -lt 0) {
        Write-Log "Step '$From' is not part of a $Type job (steps: $($steps -join ', '))" "ERROR"
        Exit-Job $ExitCode.InvalidArgument
    }

    $steps = @($steps[$index..($steps.Count - 1)])
}

Write-Log "Type       : $Type"
Write-Log "Steps      : $($steps -join ' -> ')"

#--------------------------------------------------------------------------
# RETENTION (never fails the job)
#--------------------------------------------------------------------------

try {
    Remove-ExpiredFiles -Path $LogFolder -Days $Config.Retention.LogDays `
        -Include @("*.log") -RootGuard $Root | Out-Null

    # Dumps are kept by count in the dump step, never by age here
    if ($Type -ne "DumpToSharePoint") {
        Remove-ExpiredFiles -Path $OutputFolder -Days $Config.Retention.OutputDays `
            -Include @("$($Job.OutputName)_*") -RootGuard $Root | Out-Null
    }
}
catch {
    Write-Log "Retention cleanup failed: $($_.Exception.Message)" "WARN"
}

#--------------------------------------------------------------------------
# STEP ARGUMENTS
#--------------------------------------------------------------------------

# Returns @(script, arguments). Empty values are never passed: Windows
# PowerShell drops empty arguments to native programs, which would shift
# the remaining ones.
function Get-StepCommand {

    param([string]$Step)

    $a = New-Object System.Collections.Generic.List[string]

    switch ($Step) {

        "extract" {
            $stepScript = "oracle_extract.ps1"
            $a.AddRange([string[]]@("-JobName", $JobName, "-OutputName", $Job.OutputName, "-RunDate", $RunDate))

            if ($null -ne $Job.ExpectedCount) {
                $a.AddRange([string[]]@("-ExpectedCount", [string]$Job.ExpectedCount,
                                        "-CountTolerance", [string]([long]$Job.CountTolerance)))
            }
        }

        "convert" {
            $stepScript = "excel_convert.ps1"
            $a.AddRange([string[]]@("-JobName", $JobName, "-OutputName", $Job.OutputName, "-RunDate", $RunDate))

            if ($Job.TextColumns) {
                $a.AddRange([string[]]@("-TextColumns", $Job.TextColumns))
            }
        }

        "copy" {
            $stepScript = "copy_to_xe.ps1"
            $a.AddRange([string[]]@("-JobName", $JobName, "-RunDate", $RunDate))
        }

        "dump" {
            $stepScript = "export_dump.ps1"
            $a.AddRange([string[]]@("-JobName", $JobName, "-RunDate", $RunDate))
        }

        "publish" {

            switch ($Type) {
                "CsvToSftp"         { $file = Join-Path $OutputFolder "$($Job.OutputName)_$RunDate.csv" }
                "CsvToSharePoint"   { $file = Join-Path $OutputFolder "$($Job.OutputName)_$RunDate.csv" }
                "ExcelToSharePoint" { $file = Join-Path $OutputFolder "$($Job.OutputName)_$RunDate.xlsx" }
                "DumpToSharePoint"  { $file = Join-Path $OutputFolder "$($Job.Dump.FileName)_$RunDate.dmp" }
            }

            if ($Type -eq "CsvToSftp") {
                $stepScript = "ftp_upload.ps1"
                $a.AddRange([string[]]@("-JobName", $JobName, "-LocalFile", $file))
            }
            else {
                $sp = $Job.SharePoint
                $stepScript = "sharepoint_upload.ps1"
                $a.AddRange([string[]]@("-LocalFile", $file, "-SiteName", $sp.SiteName,
                                        "-TargetFolder", $sp.TargetFolder, "-LogFolder", $LogFolder))

                if ($sp.StagingFolder) {
                    $a.AddRange([string[]]@("-StagingFolder", $sp.StagingFolder))
                }

                if ($sp.Overwrite -eq $false) {
                    $a.Add("-NoOverwrite")
                }
            }
        }
    }

    return @((Join-Path $PSScriptRoot $stepScript), $a.ToArray())
}

#--------------------------------------------------------------------------
# RUN STEPS
#--------------------------------------------------------------------------

$powershell = Join-Path $PSHOME "powershell.exe"

foreach ($step in $steps) {

    $command    = Get-StepCommand -Step $step
    $scriptPath = $command[0]
    $stepArgs   = $command[1]

    Write-Log "---- Step '$step' starting: $(Split-Path $scriptPath -Leaf)"

    # Each step runs in its own process: clean state, and its exit code
    # cannot be confused with this script's
    & $powershell -NoProfile -ExecutionPolicy Bypass -File $scriptPath @stepArgs
    $code = $LASTEXITCODE

    # Steps write to the same log file; make sure ours is set again
    Initialize-Log -LogFolder $LogFolder -Step "RUN" | Out-Null

    if ($code -ne $ExitCode.Success) {

        Write-Log "Step '$step' failed with exit code $code ($(Get-ExitCodeName $code))" "ERROR"
        Write-Log ("To rerun from this step: run_job.ps1 -JobName $JobName -From $step -RunDate $RunDate") "ERROR"

        Exit-Job $code
    }

    Write-Log "---- Step '$step' completed"
}

Exit-Job $ExitCode.Success
