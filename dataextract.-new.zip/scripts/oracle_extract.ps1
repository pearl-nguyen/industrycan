<#
.SYNOPSIS
    Step 1 - Extracts an Oracle query to CSV.

.DESCRIPTION
    (Old logs and outputs are cleaned up by run_job.ps1.)
    1. Runs sqls\<JobName>-count.sql and sqls\<JobName>.sql in one
       serializable transaction, so both see the same data snapshot
    2. Streams the result to output\<JobName>\<OutputName>_yyyyMMdd.csv.tmp
    3. Validates: rows written = count query, CSV structure and header,
       and optionally the row count against ExpectedCount +/- CountTolerance
    4. Writes the validated counts to <OutputName>_yyyyMMdd.csv.meta
       (Rows=..., Columns=...) for the optional convert step
    5. Renames the .tmp file to <OutputName>_yyyyMMdd.csv

    A file with the final name is always complete and validated.
    An existing file for the same day is replaced (manual rerun).

.EXAMPLE
    powershell.exe -ExecutionPolicy Bypass -File C:\SPECTRA_Automation\DataExtract\scripts\oracle_extract.ps1 -JobName "Reinstate_LIC" -OutputName "Reinstate_LIC" -ExpectedCount 1200 -CountTolerance 300

    Normally started by run_job.ps1, which passes the same -RunDate to
    every step of the job.

.NOTES
    Layout (root = parent of the scripts folder):
        scripts\oracle_extract.ps1, job_config.psd1
        scripts\modules\*.psm1
        sqls\<JobName>.sql, sqls\<JobName>-count.sql
        lib\Oracle.ManagedDataAccess.dll
        secure\<CredentialName>.xml (set_credential.ps1, not in git)
        output\<JobName>\
        logs\<JobName>\yyyyMMdd.log
#>

param(
    [Parameter(Mandatory = $true)]
    [string]$JobName,

    # Existing report name; the run date is appended
    [Parameter(Mandatory = $true)]
    [string]$OutputName,

    # Average expected row count; omit to skip the range check
    [long]$ExpectedCount = -1,

    # Accepted difference (+/-) from ExpectedCount
    [long]$CountTolerance = 0,

    # yyyyMMdd added to the file name; run_job.ps1 passes the job's run date
    [string]$RunDate = (Get-Date -Format "yyyyMMdd")
)

#--------------------------------------------------------------------------
# EXIT CODES ($ExitCode in modules\ExitCodes.psm1)
#   Success, InputNotFound (SQL file), SetupFailed, InvalidArgument, Unexpected,
#   DbError, CsvValidationFailed, RowCountOutOfRange
#--------------------------------------------------------------------------

$ErrorActionPreference = "Stop"

#--------------------------------------------------------------------------
# SETUP
#--------------------------------------------------------------------------

$Root         = Split-Path $PSScriptRoot -Parent
$ModuleFolder = Join-Path $PSScriptRoot "modules"
$ConfigFile   = Join-Path $PSScriptRoot "job_config.psd1"

$LogFolder    = Join-Path $Root "logs\$JobName"
$OutputFolder = Join-Path $Root "output\$JobName"
$SqlFile      = Join-Path $Root "sqls\$JobName.sql"
$CountSqlFile = Join-Path $Root "sqls\$JobName-count.sql"

$CsvPath = Join-Path $OutputFolder "${OutputName}_$RunDate.csv"
$TmpPath = "$CsvPath.tmp"

try {
    # Loaded first so even setup failures use the named codes
    Import-Module (Join-Path $PSScriptRoot "modules\ExitCodes.psm1") -Force
}
catch {
    Write-Host "Setup failed: $($_.Exception.Message)"
    exit 3   # SetupFailed (ExitCodes.psm1 itself could not be loaded)
}

try {
    Import-Module (Join-Path $ModuleFolder "JobLogging.psm1")     -Force
    Import-Module (Join-Path $ModuleFolder "HttpHelpers.psm1")    -Force
    Import-Module (Join-Path $ModuleFolder "FileValidation.psm1") -Force
    Import-Module (Join-Path $ModuleFolder "JobCredentials.psm1") -Force
    Import-Module (Join-Path $ModuleFolder "OracleExport.psm1")   -Force

    $Config  = Import-PowerShellDataFile -Path $ConfigFile
    $logPath = Initialize-Log -LogFolder $LogFolder -Step "EXTRACT"
}
catch {
    Write-Host "Setup failed: $($_.Exception.Message)"
    exit $ExitCode.SetupFailed
}

function Exit-Job {

    param([int]$Code)

    Write-Log "Finished with exit code $Code ($(Get-ExitCodeName $Code))"

    exit $Code
}

# Safety net: any unexpected error outside a try/catch is logged
trap {
    Write-LogException $_.Exception
    Exit-Job $ExitCode.Unexpected
}

#--------------------------------------------------------------------------
# START
#--------------------------------------------------------------------------

Write-Log "===================================================="
Write-Log "Extract started"
Write-Log "Job        : $JobName"
Write-Log "Log file   : $logPath"
Write-Log "SQL        : $SqlFile"
Write-Log "Count SQL  : $CountSqlFile"
Write-Log "Output     : $CsvPath"

if ($ExpectedCount -ge 0) {
    Write-Log "Expected   : $ExpectedCount +/- $CountTolerance rows"
}
else {
    Write-Log "Expected   : no range check"
}

if ($RunDate -notmatch '^\d{8}$') {
    Write-Log "Invalid -RunDate '$RunDate' (expected yyyyMMdd)" "ERROR"
    Exit-Job $ExitCode.InvalidArgument
}

#--------------------------------------------------------------------------
# INPUTS
#--------------------------------------------------------------------------

foreach ($f in @($SqlFile, $CountSqlFile)) {

    if (-not (Test-Path -LiteralPath $f -PathType Leaf)) {
        Write-Log "SQL file not found: $f" "ERROR"
        Exit-Job $ExitCode.InputNotFound
    }
}

try {
    $sql      = Read-SqlFile $SqlFile
    $countSql = Read-SqlFile $CountSqlFile

    Import-OracleDriver -Path (Join-Path $Root $Config.Oracle.DriverPath)

    $credential = Get-StoredCredential -Root $Root -Name $Config.Oracle.CredentialName

    if (-not (Test-Path -LiteralPath $OutputFolder -PathType Container)) {
        New-Item -ItemType Directory -Path $OutputFolder -Force | Out-Null
    }

    Write-Log "Database   : $($Config.Oracle.DataSource) as $($credential.UserName)"
}
catch {
    Write-LogException $_.Exception
    Exit-Job $ExitCode.SetupFailed
}

#--------------------------------------------------------------------------
# EXTRACT + VALIDATE (with retries)
#--------------------------------------------------------------------------

try {

    $result = Invoke-WithRetry `
        -Activity "Extract" `
        -MaxRetries $Config.Retry.MaxRetries `
        -BaseDelay $Config.Retry.BaseDelay `
        -ScriptBlock {

            $conn = $null
            $tx   = $null

            try {

                $conn = New-OracleConnection `
                    -DataSource $Config.Oracle.DataSource `
                    -Credential $credential `
                    -ConnectionTimeout $Config.Oracle.ConnectionTimeout

                Write-Log "Connected"

                # Serializable = both queries read the same snapshot,
                # so the count cannot drift from the exported rows
                $tx = $conn.BeginTransaction([System.Data.IsolationLevel]::Serializable)

                $countValue = Invoke-OracleScalar -Connection $conn -Transaction $tx `
                    -Sql $countSql -CommandTimeout $Config.Oracle.CommandTimeout

                if ($null -eq $countValue -or $countValue -is [System.DBNull]) {
                    throw "VALIDATION: count query returned no value"
                }

                [long]$expectedRows = [decimal]$countValue

                Write-Log ("Count query : {0:N0} rows" -f $expectedRows)

                $export = Export-OracleQueryToCsv -Connection $conn -Transaction $tx `
                    -Sql $sql -Path $TmpPath `
                    -DateFormat $Config.Export.DateFormat `
                    -CommandTimeout $Config.Oracle.CommandTimeout `
                    -FetchRows $Config.Oracle.FetchRows

                Write-Log ("Rows written: {0:N0} ({1} columns)" -f $export.Rows, $export.Columns)

                if ($export.Rows -ne $expectedRows) {
                    throw "VALIDATION: $($export.Rows) rows written but count query returned $expectedRows"
                }

                # Re-read the file to prove it parses back exactly
                $check = Test-CsvFile -Path $TmpPath `
                    -ExpectedRows $expectedRows -ExpectedHeader $export.Header

                foreach ($p in $check.Problems) {
                    Write-Log $p "ERROR"
                }

                if ($check.Problems.Count -gt 0) {
                    throw "VALIDATION: CSV structure check failed"
                }

                Write-Log "CSV validation successful"

                return $export
            }
            finally {
                # Read-only work: roll back, then dispose transaction and
                # connection; never throws, so the real error is kept
                Close-OracleConnection -Connection $conn -Transaction $tx
            }
        }
}
catch {

    $message = $_.Exception.Message

    Write-LogException $_.Exception

    if (Test-Path -LiteralPath $TmpPath) {
        Write-Log "Unvalidated file kept for inspection: $TmpPath" "WARN"
    }

    if ($message -like "VALIDATION:*") {
        Exit-Job $ExitCode.CsvValidationFailed
    }

    Exit-Job $ExitCode.DbError
}

#--------------------------------------------------------------------------
# EXPECTED RANGE (not retried: same data gives the same count)
#--------------------------------------------------------------------------

if ($ExpectedCount -ge 0) {

    $min = [math]::Max(0, $ExpectedCount - $CountTolerance)
    $max = $ExpectedCount + $CountTolerance

    if ($result.Rows -lt $min -or $result.Rows -gt $max) {

        Write-Log ("Row count {0:N0} is outside the expected range {1:N0} - {2:N0}" -f `
            $result.Rows, $min, $max) "ERROR"

        Write-Log "Unvalidated file kept for inspection: $TmpPath" "WARN"

        Exit-Job $ExitCode.RowCountOutOfRange
    }

    Write-Log ("Row count within expected range {0:N0} - {1:N0}" -f $min, $max)
}

#--------------------------------------------------------------------------
# PUBLISH LOCALLY
#--------------------------------------------------------------------------

if (Test-Path -LiteralPath $CsvPath) {
    Write-Log "Replacing existing file for today" "WARN"
}

# Validated counts for the convert step: the calling task passes them as
# -ExpectedRows / -ExpectedColumns, or excel_convert.ps1 reads this file
# when they are omitted (manual rerun)
$MetaPath = "$CsvPath.meta"

@(
    "Rows=$($result.Rows)"
    "Columns=$($result.Columns)"
) | Set-Content -LiteralPath $MetaPath -Encoding ASCII

Move-Item -LiteralPath $TmpPath -Destination $CsvPath -Force

Write-Log "Output     : $CsvPath"
Write-Log "Counts     : Rows=$($result.Rows) Columns=$($result.Columns) (saved to $(Split-Path $MetaPath -Leaf))"
Write-Log "Extract complete"

Exit-Job $ExitCode.Success
