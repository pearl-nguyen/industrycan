#--------------------------------------------------------------------------
# jobs.psd1 - one entry per scheduled job, used by run_job.ps1
#
# Task Scheduler runs:
#   powershell.exe -NoProfile -ExecutionPolicy Bypass -File <root>\scripts\run_job.ps1 -JobName <name>
#
# Types and their steps:
#   CsvToSftp          extract -> publish (SFTP)
#   CsvToSharePoint    extract -> publish (SharePoint)
#   ExcelToSharePoint  extract -> convert -> publish (SharePoint)
#   DumpToSharePoint   copy -> dump -> publish (SharePoint)
#
# Extract jobs read sqls\<JobName>.sql and sqls\<JobName>-count.sql.
# Files go to output\<JobName>\, logs to logs\<JobName>\yyyyMMdd.log.
#--------------------------------------------------------------------------
@{
    #----------------------------------------------------------------------
    # Job 1: CSV to SFTP (6 GHz)
    #----------------------------------------------------------------------
    Stations_Data_Extract = @{
        Type       = "CsvToSftp"
        OutputName = "Stations_Data_Extract"   # local file: <OutputName>_yyyyMMdd.csv

        # Optional sanity check on the row count (remove to skip)
        # ExpectedCount  = 5000
        # CountTolerance = 500

        Sftp = @{
            Server         = "ic_sftp"         # job_config.psd1, Sftp section
            RemoteFolder   = "/"
            RemoteFileName = "Stations_Data_Extract.csv"   # name on the server (no date)
        }
    }

    #----------------------------------------------------------------------
    # Job 2: CSV -> Excel -> SharePoint
    #----------------------------------------------------------------------
    Reinstate_LIC = @{
        Type        = "ExcelToSharePoint"
        OutputName  = "Reinstate_LIC"
        TextColumns = ""                       # e.g. "CLIENT_ID,POSTAL_CODE"

        SharePoint = @{
            SiteName     = "smsfc"
            # Change the date part once a year
            TargetFolder = "Mass_Cancellation/Mass_Cancellation_20260630"
            Overwrite    = $true
        }
    }

    #----------------------------------------------------------------------
    # Job 3: BCP dump (prod -> XE -> expdp -> SharePoint)
    #----------------------------------------------------------------------
    EMC_TDB_FREQPLAN = @{
        Type = "DumpToSharePoint"

        Copy = @{
            SqlFolder      = "sqls\EMC_TDB_FREQPLAN"
            Script         = "copy2tdb.sql"
            DropLinkScript = "drop_linkToXeDb.sql"
            TimeoutHours   = 12

            # DEFINE name in the SQL -> credential name (set_credential.ps1).
            # Remove these DEFINEs from config.sql.
            Secrets = @{
                emc_password    = "prod_emc"
                emctdb_password = "xe_emctdb"
            }

            # Copy fails unless each pair of counts printed by the SQL match
            CountChecks = @{
                PROD_TX_ROWS = "IMPORTED_TX_ROWS"
                PROD_RX_ROWS = "IMPORTED_RX_ROWS"
            }
        }

        Dump = @{
            # Your existing expdp parameter file; DIRECTORY, DUMPFILE,
            # LOGFILE and USERID in it are ignored (set by the script)
            ParFile         = "sqls\EMC_TDB_FREQPLAN\EMC_TDB_FREQPLAN_EXPORT.par"

            # Oracle DIRECTORY object pointing to output\EMC_TDB_FREQPLAN
            # (sqls\EMC_TDB_FREQPLAN\setup_dump_directory.sql)
            OracleDirectory = "DATAEXTRACT_DUMP"

            FileName        = "EMC_TDB_FREQPLAN"    # -> EMC_TDB_FREQPLAN_yyyyMMdd.dmp
            TimeoutHours    = 4

            # Same range as the old Copy_dump_file_to_U.bat check
            MinBytes        = 2830000000
            MaxBytes        = 3130000000

            # Dated dumps kept in output\EMC_TDB_FREQPLAN (newest first)
            KeepCopies      = 3

            # Fixed-name copy for the BCP application (replaced only after
            # the new dump is validated)
            MaintenanceCopy = "C:\Lstelcom\maintenance_scripts\EMC_TDB_FREQPLAN.dmp"

            # Rows exported per table must match the copy step's counts
            CountChecks = @{
                TX_RES_TAB = "IMPORTED_TX_ROWS"
                RX_RES_TAB = "IMPORTED_RX_ROWS"
            }
        }

        SharePoint = @{
            SiteName     = "SMSOperations"
            TargetFolder = "SPECTRAbcp Files/BCP_V40/SPECTRA_BCP_V40"
            # Never replace anything in the business team's folder
            Overwrite    = $false
        }
    }
}
