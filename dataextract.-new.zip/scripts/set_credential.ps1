<#
.SYNOPSIS
    One-time setup: stores a user name and password encrypted, under a name
    the jobs refer to (job_config.psd1 / jobs.psd1).

.DESCRIPTION
    Saves <root>\secure\<Name>.xml using Windows DPAPI. Only the Windows
    account that runs this script, on this machine, can decrypt it.

    Run it on the team machine, logged in as the account that runs the
    jobs, once per name, and again whenever a password changes:

      db_credential  report database (extract jobs)       -TestOracle
      prod_emc       prod user that runs copy2tdb.sql
      xe_emctdb      local XE user the DB link connects to
      xe_system      SYSTEM on XE (expdp)
      sftp_6ghz      SFTP account

    The secure folder must never be committed to git.

.EXAMPLE
    powershell.exe -ExecutionPolicy Bypass -File C:\SPECTRA_Automation\DataExtract\scripts\set_credential.ps1 -Name db_credential -TestOracle
    powershell.exe -ExecutionPolicy Bypass -File C:\SPECTRA_Automation\DataExtract\scripts\set_credential.ps1 -Name xe_system
#>

param(
    [Parameter(Mandatory = $true)]
    [string]$Name,

    # Opens a connection to job_config.psd1 Oracle.DataSource with the
    # saved credential (report database only)
    [switch]$TestOracle
)

$ErrorActionPreference = "Stop"

Import-Module (Join-Path $PSScriptRoot "modules\ExitCodes.psm1")      -Force
Import-Module (Join-Path $PSScriptRoot "modules\JobLogging.psm1")     -Force
Import-Module (Join-Path $PSScriptRoot "modules\JobCredentials.psm1") -Force

$Root   = Split-Path $PSScriptRoot -Parent
$Config = Import-PowerShellDataFile -Path (Join-Path $PSScriptRoot "job_config.psd1")

$path = Get-CredentialPath -Root $Root -Name $Name

Write-Host "Name    : $Name"
Write-Host "Account : $env:USERDOMAIN\$env:USERNAME"
Write-Host "Machine : $env:COMPUTERNAME"
Write-Host "File    : $path"
Write-Host "Only this account on this machine will be able to read it."
Write-Host ""

$cred = Get-Credential -Message "User name and password for '$Name'"

if (-not $cred) {
    Write-Host "Cancelled."
    exit $ExitCode.InvalidArgument
}

Save-StoredCredential -Root $Root -Name $Name -Credential $cred | Out-Null

Write-Host "Credential saved."

if ($TestOracle) {

    Import-Module (Join-Path $PSScriptRoot "modules\OracleExport.psm1") -Force

    Import-OracleDriver -Path (Join-Path $Root $Config.Oracle.DriverPath)

    $conn = $null

    try {
        $conn = New-OracleConnection `
            -DataSource $Config.Oracle.DataSource `
            -Credential (Get-StoredCredential -Root $Root -Name $Name) `
            -ConnectionTimeout $Config.Oracle.ConnectionTimeout

        $value = Invoke-OracleScalar -Connection $conn -Sql "SELECT 1 FROM DUAL"

        Write-Host "Connection test OK (SELECT 1 FROM DUAL returned $value)"
    }
    catch {
        Write-Host "Connection test FAILED: $($_.Exception.Message)"
        exit $ExitCode.DbError
    }
    finally {
        Close-OracleConnection -Connection $conn
    }
}

exit $ExitCode.Success
