<#
.SYNOPSIS
    Step 2 (optional) - Converts the validated CSV from step 1 to Excel.

.DESCRIPTION
    The CSV was already validated in step 1 (parser + row count), so it is
    not re-parsed here. Step 1's row and column counts are the reference:

    1. Takes the expected counts from -ExpectedRows / -ExpectedColumns,
       or, when omitted, from <OutputName>_<RunDate>.csv.meta (step 1)
    2. Reads the CSV header and checks its column count
    3. Converts to <OutputName>_<RunDate>.tmp.xlsx with ImportExcel
       (Excel does not need to be installed)
    4. Validates the workbook: data rows, column count and header
    5. Renames it to <OutputName>_<RunDate>.xlsx

    The CSV is kept. If this step fails, rerun it alone.

.EXAMPLE
    Counts passed by the calling task (values from step 1):
    powershell.exe -ExecutionPolicy Bypass -File C:\SPECTRA_Automation\DataExtract\scripts\excel_convert.ps1 -JobName "Reinstate_LIC" -OutputName "Reinstate_LIC" -ExpectedRows 1187 -ExpectedColumns 12

    Manual rerun for an earlier day (counts read from the .meta file),
    keeping two ID columns as text:
    ... -JobName "Reinstate_LIC" -OutputName "Reinstate_LIC" -RunDate 20261006 -TextColumns "CLIENT_ID,POSTAL_CODE"
#>

param(
    [Parameter(Mandatory = $true)]
    [string]$JobName,

    [Parameter(Mandatory = $true)]
    [string]$OutputName,

    # Data rows (header excluded) from step 1; omit to read the .meta file
    [long]$ExpectedRows = -1,

    # Column count from step 1; omit to read the .meta file
    [int]$ExpectedColumns = -1,

    # yyyyMMdd of the CSV to convert; defaults to today
    [string]$RunDate = (Get-Date -Format "yyyyMMdd"),

    # Comma-separated columns to keep as text (leading zeros, long IDs).
    # A single string because powershell.exe -File cannot pass arrays.
    [string]$TextColumns = ""
)

#--------------------------------------------------------------------------
# EXIT CODES ($ExitCode in modules\ExitCodes.psm1)
#   Success, InputNotFound (CSV), SetupFailed, InvalidArgument (-RunDate),
#   Unexpected, ExpectedCountsMissing, CsvHeaderMismatch,
#   ExcelConversionFailed, ExcelValidationFailed, ExcelTooManyRows
#--------------------------------------------------------------------------

$ErrorActionPreference = "Stop"

$ExcelMaxRows = 1048576

#--------------------------------------------------------------------------
# SETUP
#--------------------------------------------------------------------------

$Root         = Split-Path $PSScriptRoot -Parent
$ModuleFolder = Join-Path $PSScriptRoot "modules"
$ConfigFile   = Join-Path $PSScriptRoot "job_config.psd1"

$LogFolder    = Join-Path $Root "logs\$JobName"
$OutputFolder = Join-Path $Root "output\$JobName"

try {
    # Loaded first so even setup failures use the named codes
    Import-Module (Join-Path $PSScriptRoot "modules\ExitCodes.psm1") -Force
}
catch {
    Write-Host "Setup failed: $($_.Exception.Message)"
    exit 3   # SetupFailed (ExitCodes.psm1 itself could not be loaded)
}

try {
    Import-Module (Join-Path $ModuleFolder "JobLogging.psm1")     -Force
    Import-Module (Join-Path $ModuleFolder "FileValidation.psm1") -Force
    Import-Module ImportExcel -ErrorAction Stop

    $Config  = Import-PowerShellDataFile -Path $ConfigFile
    $logPath = Initialize-Log -LogFolder $LogFolder -Step "CONVERT"
}
catch {
    Write-Host "Setup failed: $($_.Exception.Message)"
    exit $ExitCode.SetupFailed
}

function Exit-Job {

    param([int]$Code)

    Write-Log "Finished with exit code $Code ($(Get-ExitCodeName $Code))"

    exit $Code
}

trap {
    Write-LogException $_.Exception
    Exit-Job $ExitCode.Unexpected
}

# Reads Rows=... and Columns=... written by oracle_extract.ps1.
# Returns $null if the file is missing or incomplete.
function Read-CountsFile {

    param([string]$Path)

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        return $null
    }

    $values = @{}

    foreach ($line in (Get-Content -LiteralPath $Path)) {
        if ($line -match '^\s*(\w+)\s*=\s*(\d+)\s*$') {
            $values[$Matches[1]] = [long]$Matches[2]
        }
    }

    if (-not $values.ContainsKey('Rows') -or -not $values.ContainsKey('Columns')) {
        return $null
    }

    return [pscustomobject]@{
        Rows    = $values['Rows']
        Columns = [int]$values['Columns']
    }
}

# Writes the CSV into a new workbook. The script opens and owns the Excel
# package, so it is always disposed (and the file unlocked), even if the
# conversion fails part way through.
function Convert-CsvToWorkbook {

    param(
        [string]$CsvPath,
        [string]$Path,
        [string]$WorksheetName,
        [string[]]$Header,
        [long]$Rows,
        [string[]]$TextColumns
    )

    $pkg = $null

    try {
        $pkg = Open-ExcelPackage -Path $Path -Create

        if ($Rows -eq 0) {

            # Export-Excel writes nothing without data rows: header only
            $ws = Add-Worksheet -ExcelPackage $pkg -WorksheetName $WorksheetName

            for ($c = 0; $c -lt $Header.Count; $c++) {
                $ws.Cells[1, $c + 1].Value = $Header[$c]
            }

            $ws.Row(1).Style.Font.Bold = $true
        }
        else {

            $excelParams = @{
                ExcelPackage  = $pkg
                WorksheetName = $WorksheetName
                FreezeTopRow  = $true
                AutoFilter    = $true
                BoldTopRow    = $true
                # Keep the package open: it is saved and disposed below
                PassThru      = $true
            }

            if ($TextColumns.Count -gt 0) {
                $excelParams.NoNumberConversion = $TextColumns
            }

            Import-Csv -LiteralPath $CsvPath -Encoding UTF8 |
                Export-Excel @excelParams |
                Out-Null
        }

        # Saves the file and disposes the package
        Close-ExcelPackage -ExcelPackage $pkg
        $pkg = $null
    }
    finally {
        # Only reached with $pkg set if something failed: discard it
        if ($pkg) {
            try { Close-ExcelPackage -ExcelPackage $pkg -NoSave } catch { }
        }
    }
}

#--------------------------------------------------------------------------
# START
#--------------------------------------------------------------------------

$WorksheetName = $Config.Excel.WorksheetName

Write-Log "===================================================="
Write-Log "Convert started"
Write-Log "Job        : $JobName"
Write-Log "Log file   : $logPath"

if ($RunDate -notmatch '^\d{8}$') {
    Write-Log "Invalid -RunDate '$RunDate' (expected yyyyMMdd)" "ERROR"
    Exit-Job $ExitCode.InvalidArgument
}

$CsvPath  = Join-Path $OutputFolder "${OutputName}_$RunDate.csv"
$MetaPath = "$CsvPath.meta"
$XlsxPath = Join-Path $OutputFolder "${OutputName}_$RunDate.xlsx"
$TmpPath  = Join-Path $OutputFolder "${OutputName}_$RunDate.tmp.xlsx"

$textCols = @($TextColumns -split ',' |
    ForEach-Object { $_.Trim() } |
    Where-Object { $_ -ne '' })

Write-Log "CSV        : $CsvPath"
Write-Log "Excel      : $XlsxPath"
Write-Log "Worksheet  : $WorksheetName"

if ($textCols.Count -gt 0) {
    Write-Log "Text cols  : $($textCols -join ', ')"
}

if (-not (Test-Path -LiteralPath $CsvPath -PathType Leaf)) {
    Write-Log "CSV not found: $CsvPath" "ERROR"
    Exit-Job $ExitCode.InputNotFound
}

#--------------------------------------------------------------------------
# EXPECTED COUNTS (from step 1)
#--------------------------------------------------------------------------

if ($ExpectedRows -lt 0 -or $ExpectedColumns -lt 0) {

    $meta = Read-CountsFile $MetaPath

    if (-not $meta) {
        Write-Log ("Expected counts not passed and no valid counts file from step 1: " +
                   "$MetaPath. Pass -ExpectedRows and -ExpectedColumns.") "ERROR"
        Exit-Job $ExitCode.ExpectedCountsMissing
    }

    if ($ExpectedRows -lt 0)    { $ExpectedRows    = $meta.Rows }
    if ($ExpectedColumns -lt 0) { $ExpectedColumns = $meta.Columns }

    Write-Log "Counts from: $(Split-Path $MetaPath -Leaf)"
}
else {
    Write-Log "Counts from: parameters"
}

Write-Log ("Expected   : {0:N0} rows, {1} columns" -f $ExpectedRows, $ExpectedColumns)

if (($ExpectedRows + 1) -gt $ExcelMaxRows) {
    Write-Log ("{0:N0} data rows exceed the Excel limit of {1:N0} rows" -f `
        $ExpectedRows, ($ExcelMaxRows - 1)) "ERROR"
    Exit-Job $ExitCode.ExcelTooManyRows
}

#--------------------------------------------------------------------------
# CSV HEADER (the rows were validated in step 1)
#--------------------------------------------------------------------------

try {
    $header = @(Get-CsvHeader -Path $CsvPath)
}
catch {
    Write-Log "CSV header could not be read: $($_.Exception.Message)" "ERROR"
    Exit-Job $ExitCode.CsvHeaderMismatch
}

if ($header.Count -ne $ExpectedColumns) {
    Write-Log "CSV header has $($header.Count) columns, expected $ExpectedColumns" "ERROR"
    Exit-Job $ExitCode.CsvHeaderMismatch
}

foreach ($col in $textCols) {
    if ($header -notcontains $col) {
        Write-Log "Text column '$col' is not in the CSV header" "WARN"
    }
}

#--------------------------------------------------------------------------
# CONVERT
#--------------------------------------------------------------------------

try {

    # Open-ExcelPackage adds to an existing workbook, so always start clean
    if (Test-Path -LiteralPath $TmpPath) {
        Remove-Item -LiteralPath $TmpPath -Force
    }

    Convert-CsvToWorkbook `
        -CsvPath $CsvPath `
        -Path $TmpPath `
        -WorksheetName $WorksheetName `
        -Header $header `
        -Rows $ExpectedRows `
        -TextColumns $textCols

    Write-Log "Conversion completed"
}
catch {
    Write-LogException $_.Exception

    # A partial workbook is useless; the package is already disposed
    Remove-Item -LiteralPath $TmpPath -Force -ErrorAction SilentlyContinue

    Exit-Job $ExitCode.ExcelConversionFailed
}

#--------------------------------------------------------------------------
# VALIDATE EXCEL AGAINST STEP 1 COUNTS
#--------------------------------------------------------------------------

$xl = Test-ExcelFile -Path $TmpPath -WorksheetName $WorksheetName `
    -ExpectedRows $ExpectedRows -ExpectedHeader $header

foreach ($p in $xl.Problems) {
    Write-Log $p "ERROR"
}

if ($xl.Problems.Count -gt 0) {
    Write-Log "Unvalidated workbook kept for inspection: $TmpPath" "WARN"
    Exit-Job $ExitCode.ExcelValidationFailed
}

Write-Log ("Excel rows : {0:N0} ({1} columns) - matches step 1" -f $xl.Rows, $xl.Columns)

if (Test-Path -LiteralPath $XlsxPath) {
    Write-Log "Replacing existing workbook for $RunDate" "WARN"
}

Move-Item -LiteralPath $TmpPath -Destination $XlsxPath -Force

Write-Log "Output     : $XlsxPath"
Write-Log "Convert complete"

Exit-Job $ExitCode.Success
