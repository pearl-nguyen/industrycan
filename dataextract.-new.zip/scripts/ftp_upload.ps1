<#
.SYNOPSIS
    Uploads a file to an SFTP server with the WinSCP .NET assembly.

.DESCRIPTION
    Server, folder and remote file name come from jobs.psd1 (Sftp section
    of the job) and job_config.psd1 (Sftp servers). For each attempt:
    1. Opens a session (host key pinned, password from the encrypted
       credential file)
    2. Uploads the file under its remote name (by default WinSCP writes
       a .filepart file and renames it at the end, so the receiver never
       sees a partial file)
    3. Checks the remote size equals the local size
    A WinSCP session log is written for each attempt to logs\<JobName>\.
    Failed attempts are retried (job_config.psd1, Retry).

.EXAMPLE
    powershell.exe -ExecutionPolicy Bypass -File C:\SPECTRA_Automation\DataExtract\scripts\ftp_upload.ps1 -JobName Stations_Data_Extract -LocalFile C:\SPECTRA_Automation\DataExtract\output\Stations_Data_Extract\Stations_Data_Extract_20261008.csv
#>

param(
    [Parameter(Mandatory = $true)]
    [string]$JobName,

    [Parameter(Mandatory = $true)]
    [string]$LocalFile
)

#--------------------------------------------------------------------------
# EXIT CODES ($ExitCode in modules\ExitCodes.psm1)
#   Success, InputNotFound, SetupFailed, InvalidArgument, Unexpected,
#   SftpConnectFailed, SftpUploadFailed, SftpVerifyFailed
#--------------------------------------------------------------------------

$ErrorActionPreference = "Stop"

$Root         = Split-Path $PSScriptRoot -Parent
$ModuleFolder = Join-Path $PSScriptRoot "modules"
$LogFolder    = Join-Path $Root "logs\$JobName"

try {
    Import-Module (Join-Path $ModuleFolder "ExitCodes.psm1") -Force
}
catch {
    Write-Host "Setup failed: $($_.Exception.Message)"
    exit 3   # SetupFailed (ExitCodes.psm1 itself could not be loaded)
}

try {
    Import-Module (Join-Path $ModuleFolder "JobLogging.psm1")     -Force
    Import-Module (Join-Path $ModuleFolder "HttpHelpers.psm1")    -Force
    Import-Module (Join-Path $ModuleFolder "JobCredentials.psm1") -Force
    Import-Module (Join-Path $ModuleFolder "WinScpTransfer.psm1") -Force

    $Config  = Import-PowerShellDataFile -Path (Join-Path $PSScriptRoot "job_config.psd1")
    $Jobs    = Import-PowerShellDataFile -Path (Join-Path $PSScriptRoot "jobs.psd1")
    $logPath = Initialize-Log -LogFolder $LogFolder -Step "SFTP"
}
catch {
    Write-Host "Setup failed: $($_.Exception.Message)"
    exit $ExitCode.SetupFailed
}

function Exit-Job {

    param([int]$Code)

    Write-Log "Finished with exit code $Code ($(Get-ExitCodeName $Code))"

    exit $Code
}

trap {
    Write-LogException $_.Exception
    Exit-Job $ExitCode.Unexpected
}

#--------------------------------------------------------------------------
# START
#--------------------------------------------------------------------------

Write-Log "===================================================="
Write-Log "SFTP upload started"
Write-Log "Job        : $JobName"
Write-Log "Log file   : $logPath"

if (-not $Jobs.ContainsKey($JobName) -or -not $Jobs[$JobName].Sftp) {
    Write-Log "Job '$JobName' has no Sftp section in jobs.psd1" "ERROR"
    Exit-Job $ExitCode.InvalidArgument
}

$target = $Jobs[$JobName].Sftp

if (-not $Config.Sftp.ContainsKey([string]$target.Server)) {
    Write-Log "SFTP server '$($target.Server)' is not defined in job_config.psd1" "ERROR"
    Exit-Job $ExitCode.InvalidArgument
}

$server = $Config.Sftp[[string]$target.Server]

if (-not (Test-Path -LiteralPath $LocalFile -PathType Leaf)) {
    Write-Log "Local file not found: $LocalFile" "ERROR"
    Exit-Job $ExitCode.InputNotFound
}

$LocalFile    = (Resolve-Path -LiteralPath $LocalFile).Path
$remoteFolder = if ($target.RemoteFolder) { $target.RemoteFolder } else { "/" }
$resume       = if ($server.ResumeSupport) { $server.ResumeSupport } else { "Default" }
$timeout      = if ($server.TimeoutSeconds) { [int]$server.TimeoutSeconds } else { 60 }

Write-Log "File       : $LocalFile"
Write-Log "Size       : $((Get-Item -LiteralPath $LocalFile).Length)"
Write-Log "Server     : $($server.HostName):$($server.Port)"
Write-Log "Remote     : $($remoteFolder.TrimEnd('/'))/$($target.RemoteFileName)"
Write-Log "Resume     : $resume"

try {
    Import-WinScp -Folder (Join-Path $Root $Config.WinScpFolder)

    $credential = Get-StoredCredential -Root $Root -Name $server.CredentialName
}
catch {
    Write-LogException $_.Exception
    Exit-Job $ExitCode.SetupFailed
}

#--------------------------------------------------------------------------
# UPLOAD (with retries; a new session for every attempt)
#--------------------------------------------------------------------------

$script:attemptNumber = 0

try {
    $result = Invoke-WithRetry `
        -Activity "SFTP upload" `
        -MaxRetries $Config.Retry.MaxRetries `
        -BaseDelay $Config.Retry.BaseDelay `
        -ScriptBlock {

            $script:attemptNumber++

            $sessionLog = Join-Path $LogFolder ("winscp_{0}_a{1}.log" -f `
                (Get-Date -Format "yyyyMMdd_HHmmss"), $script:attemptNumber)

            Write-Log "WinSCP log : $sessionLog"

            Send-SftpFile `
                -WinScpFolder (Join-Path $Root $Config.WinScpFolder) `
                -HostName $server.HostName `
                -Port $server.Port `
                -HostKey $server.HostKey `
                -Credential $credential `
                -LocalFile $LocalFile `
                -RemoteFolder $remoteFolder `
                -RemoteFileName $target.RemoteFileName `
                -ResumeSupport $resume `
                -SessionLogPath $sessionLog `
                -TimeoutSeconds $timeout
        }
}
catch {

    $message = $_.Exception.Message

    Write-LogException $_.Exception

    if ($message -like "CONNECT:*") { Exit-Job $ExitCode.SftpConnectFailed }
    if ($message -like "VERIFY:*")  { Exit-Job $ExitCode.SftpVerifyFailed }

    Exit-Job $ExitCode.SftpUploadFailed
}

Write-Log "Remote file : $($result.RemotePath) ($($result.Size) bytes, size verified)"
Write-Log "SFTP upload complete"

Exit-Job $ExitCode.Success
