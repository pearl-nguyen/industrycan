<#
.SYNOPSIS
    Dump job step 2 - exports the local XE schema with expdp, validates the
    dump and refreshes the fixed-name copy used by the BCP application.

.DESCRIPTION
    1. Frees disk space first: keeps only the newest (KeepCopies - 1) dated
       dumps, so KeepCopies remain once this run succeeds
    2. Checks there is enough free space for the new dump (and for the
       maintenance copy)
    3. Runs expdp with a temporary parameter file: your existing .par file
       plus DIRECTORY, DUMPFILE=<FileName>_<RunDate>.dmp, LOGFILE and the
       SYSTEM login from the encrypted credential file
    4. Validates: expdp exit code, "successfully completed" in the expdp
       log, no ORA- errors, dump size within MinBytes..MaxBytes, and the
       rows exported per table equal the copy step's counts
       A dump that fails any check is renamed to .dmp.rejected, so it can
       never be uploaded; the next run deletes it
    5. Replaces MaintenanceCopy (fixed name, no date) only after all checks
       pass: copied as .tmp next to it, then swapped in

    Not retried automatically; rerun with run_job.ps1 -From dump.

.EXAMPLE
    powershell.exe -ExecutionPolicy Bypass -File C:\SPECTRA_Automation\DataExtract\scripts\export_dump.ps1 -JobName EMC_TDB_FREQPLAN
#>

param(
    [Parameter(Mandatory = $true)]
    [string]$JobName,

    [string]$RunDate = (Get-Date -Format "yyyyMMdd")
)

#--------------------------------------------------------------------------
# EXIT CODES ($ExitCode in modules\ExitCodes.psm1)
#   Success, InputNotFound, SetupFailed, InvalidArgument, Unexpected,
#   ExpectedCountsMissing, DumpFailed, DumpValidationFailed,
#   DumpCountMismatch, NotEnoughDiskSpace, MaintenanceCopyFailed
#--------------------------------------------------------------------------

$ErrorActionPreference = "Stop"

$Root         = Split-Path $PSScriptRoot -Parent
$ModuleFolder = Join-Path $PSScriptRoot "modules"
$LogFolder    = Join-Path $Root "logs\$JobName"
$OutputFolder = Join-Path $Root "output\$JobName"

try {
    Import-Module (Join-Path $ModuleFolder "ExitCodes.psm1") -Force
}
catch {
    Write-Host "Setup failed: $($_.Exception.Message)"
    exit 3   # SetupFailed (ExitCodes.psm1 itself could not be loaded)
}

try {
    Import-Module (Join-Path $ModuleFolder "JobLogging.psm1")     -Force
    Import-Module (Join-Path $ModuleFolder "JobCredentials.psm1") -Force
    Import-Module (Join-Path $ModuleFolder "OracleTools.psm1")    -Force
    Import-Module (Join-Path $ModuleFolder "FileRetention.psm1")  -Force

    $Config  = Import-PowerShellDataFile -Path (Join-Path $PSScriptRoot "job_config.psd1")
    $Jobs    = Import-PowerShellDataFile -Path (Join-Path $PSScriptRoot "jobs.psd1")
    $logPath = Initialize-Log -LogFolder $LogFolder -Step "DUMP"
}
catch {
    Write-Host "Setup failed: $($_.Exception.Message)"
    exit $ExitCode.SetupFailed
}

function Exit-Job {

    param([int]$Code)

    Write-Log "Finished with exit code $Code ($(Get-ExitCodeName $Code))"

    exit $Code
}

trap {
    Write-LogException $_.Exception
    Exit-Job $ExitCode.Unexpected
}

# Renames a dump that failed validation to <name>.dmp.rejected so it can
# never be published by mistake (run_job -From publish would not find it).
# Kept for inspection until the next run, which deletes it to free space.
function Set-DumpRejected {

    if (Test-Path -LiteralPath $dumpPath) {
        try {
            Move-Item -LiteralPath $dumpPath -Destination "$dumpPath.rejected" -Force
            Write-Log "Dump renamed to $(Split-Path "$dumpPath.rejected" -Leaf); if it is actually fine (e.g. the data grew), adjust MinBytes/MaxBytes and rerun with -From dump" "ERROR"
        }
        catch {
            Write-Log "Could not rename the rejected dump: $($_.Exception.Message)" "WARN"
        }
    }
}

function Format-Size {

    param([double]$Bytes)

    return ("{0:N2} GB" -f ($Bytes / 1GB))
}

function Get-FreeBytes {

    param([string]$Path)

    $drive = New-Object System.IO.DriveInfo((Split-Path -Qualifier $Path))

    return $drive.AvailableFreeSpace
}

#--------------------------------------------------------------------------
# START
#--------------------------------------------------------------------------

Write-Log "===================================================="
Write-Log "Dump export started"
Write-Log "Job        : $JobName"
Write-Log "Run date   : $RunDate"
Write-Log "Log file   : $logPath"

if ($RunDate -notmatch '^\d{8}$') {
    Write-Log "Invalid -RunDate '$RunDate' (expected yyyyMMdd)" "ERROR"
    Exit-Job $ExitCode.InvalidArgument
}

if (-not $Jobs.ContainsKey($JobName) -or -not $Jobs[$JobName].Dump) {
    Write-Log "Job '$JobName' has no Dump section in jobs.psd1" "ERROR"
    Exit-Job $ExitCode.InvalidArgument
}

$dump        = $Jobs[$JobName].Dump
$baseName    = "$($dump.FileName)_$RunDate"
$dumpFile    = "$baseName.dmp"
$dumpLog     = "$baseName.log"
$dumpPath    = Join-Path $OutputFolder $dumpFile
$dumpLogPath = Join-Path $OutputFolder $dumpLog
$metaPath    = Join-Path $OutputFolder "${JobName}_$RunDate.copy.meta"
$parSource   = Join-Path $Root $dump.ParFile
$expdp       = Join-Path $Config.OracleXe.OracleHome "bin\expdp.exe"
$keep        = [int]$dump.KeepCopies
$minBytes    = [long]$dump.MinBytes
$maxBytes    = [long]$dump.MaxBytes
$maintenance = [string]$dump.MaintenanceCopy

Write-Log "Dump file  : $dumpPath"
Write-Log "Directory  : $($dump.OracleDirectory) (must point to $OutputFolder)"
Write-Log "Size range : $(Format-Size $minBytes) - $(Format-Size $maxBytes)"
Write-Log "Keep       : $keep dated dump(s)"

if ($maintenance) {
    Write-Log "BCP copy   : $maintenance"
}

if ($keep -lt 1) {
    Write-Log "KeepCopies must be 1 or more" "ERROR"
    Exit-Job $ExitCode.InvalidArgument
}

foreach ($f in @($parSource, $expdp)) {
    if (-not (Test-Path -LiteralPath $f -PathType Leaf)) {
        Write-Log "File not found: $f" "ERROR"
        Exit-Job $ExitCode.InputNotFound
    }
}

#--------------------------------------------------------------------------
# EXPECTED COUNTS (from the copy step)
#--------------------------------------------------------------------------

$expected = @{}

if ($dump.CountChecks -and $dump.CountChecks.Count -gt 0) {

    if (-not (Test-Path -LiteralPath $metaPath -PathType Leaf)) {
        Write-Log "Counts from the copy step not found: $metaPath (run the copy step for $RunDate first)" "ERROR"
        Exit-Job $ExitCode.ExpectedCountsMissing
    }

    foreach ($line in (Get-Content -LiteralPath $metaPath)) {
        if ($line -match '^\s*(\w+)\s*=\s*(\d+)\s*$') {
            $expected[$Matches[1]] = [long]$Matches[2]
        }
    }

    foreach ($table in $dump.CountChecks.Keys) {
        $key = $dump.CountChecks[$table]
        if (-not $expected.ContainsKey($key)) {
            Write-Log "'$key' missing from $metaPath" "ERROR"
            Exit-Job $ExitCode.ExpectedCountsMissing
        }
    }
}

#--------------------------------------------------------------------------
# RETENTION FIRST: make room before exporting
#--------------------------------------------------------------------------

try {
    if (-not (Test-Path -LiteralPath $OutputFolder -PathType Container)) {
        New-Item -ItemType Directory -Path $OutputFolder -Force | Out-Null
    }

    # Today's files (a rerun) are replaced, so they are not counted
    $exclude = @($dumpFile, $dumpLog, "${JobName}_$RunDate.copy.meta")

    # Dumps rejected by an earlier run: kept only until now
    Remove-ExcessFiles -Path $OutputFolder -Include @("$($dump.FileName)_*.dmp.rejected") `
        -Keep 0 -RootGuard $Root | Out-Null

    Remove-ExcessFiles -Path $OutputFolder -Include @("$($dump.FileName)_*.dmp") `
        -Keep ($keep - 1) -Exclude $exclude -RootGuard $Root | Out-Null

    Remove-ExcessFiles -Path $OutputFolder -Include @("$($dump.FileName)_*.log") `
        -Keep ($keep - 1) -Exclude $exclude -RootGuard $Root | Out-Null

    Remove-ExcessFiles -Path $OutputFolder -Include @("${JobName}_*.copy.meta") `
        -Keep $keep -Exclude $exclude -RootGuard $Root | Out-Null
}
catch {
    Write-Log "Retention cleanup failed: $($_.Exception.Message)" "WARN"
}

#--------------------------------------------------------------------------
# DISK SPACE
#--------------------------------------------------------------------------

# A same-day rerun overwrites today's dump, so its space counts as free
$reusable = 0
if (Test-Path -LiteralPath $dumpPath) {
    $reusable = (Get-Item -LiteralPath $dumpPath).Length
}

$needed = @{}
$dumpDrive = Split-Path -Qualifier $OutputFolder
$needed[$dumpDrive] = $maxBytes - $reusable

if ($maintenance) {
    # The new copy is written next to the old one before replacing it
    $maintDrive = Split-Path -Qualifier $maintenance
    if (-not $needed.ContainsKey($maintDrive)) { $needed[$maintDrive] = 0 }
    $needed[$maintDrive] += $maxBytes
}

foreach ($drive in $needed.Keys) {

    $free = Get-FreeBytes "$drive\"

    Write-Log "Free space : $drive $(Format-Size $free) (needs $(Format-Size $needed[$drive]))"

    if ($free -lt $needed[$drive]) {
        Write-Log "Not enough free space on $drive (reduce KeepCopies or free space)" "ERROR"
        Exit-Job $ExitCode.NotEnoughDiskSpace
    }
}

#--------------------------------------------------------------------------
# EXPDP
#--------------------------------------------------------------------------

try {
    $system = Get-StoredCredential -Root $Root -Name $Config.OracleXe.SystemCredential
    $pw     = $system.GetNetworkCredential().Password

    if ($pw.Contains('"')) {
        throw "The SYSTEM password contains a double quote, which expdp parameter files cannot take"
    }

    # Your .par file, without the parameters this script sets
    $overridden = '^\s*(userid|directory|dumpfile|logfile|reuse_dumpfiles)\s*='
    $parLines   = @(Get-Content -LiteralPath $parSource | Where-Object { $_ -notmatch $overridden })

    $parLines += @(
        "USERID=$($system.UserName)/`"$pw`""
        "DIRECTORY=$($dump.OracleDirectory)"
        "DUMPFILE=$dumpFile"
        "LOGFILE=$dumpLog"
        "REUSE_DUMPFILES=Y"
    )

    $pw = $null
}
catch {
    Write-LogException $_.Exception
    Exit-Job $ExitCode.SetupFailed
}

# A same-day rerun: old log must not be mistaken for the new one
Remove-Item -LiteralPath $dumpLogPath -Force -ErrorAction SilentlyContinue

try {
    $started = Get-Date

    $r = Invoke-DataPumpExport `
        -ExpdpPath $expdp `
        -ParameterLines $parLines `
        -Environment @{ ORACLE_HOME = $Config.OracleXe.OracleHome; ORACLE_SID = $Config.OracleXe.Sid } `
        -TimeoutMinutes ([double]$dump.TimeoutHours * 60)

    Write-Log ("expdp finished in {0:hh\:mm\:ss} with exit code {1}" -f ((Get-Date) - $started), $r.ExitCode)
}
catch {
    Write-LogException $_.Exception
    Exit-Job $ExitCode.DumpFailed
}
finally {
    # The parameter lines hold the password
    $parLines = $null
}

if ($r.TimedOut) {
    Write-Log "expdp stopped after $($dump.TimeoutHours) hours. The Data Pump job may still exist in XE (DBA_DATAPUMP_JOBS)." "ERROR"
    Set-DumpRejected
    Exit-Job $ExitCode.DumpFailed
}

if ($r.ExitCode -ne 0) {
    Write-Log "expdp failed with exit code $($r.ExitCode)" "ERROR"
    Set-DumpRejected
    Exit-Job $ExitCode.DumpFailed
}

#--------------------------------------------------------------------------
# VALIDATE
#--------------------------------------------------------------------------

$problems = @()

if (-not (Test-Path -LiteralPath $dumpLogPath -PathType Leaf)) {
    $problems += "expdp log not found: $dumpLogPath (check that DIRECTORY $($dump.OracleDirectory) points to $OutputFolder)"
}

if (-not (Test-Path -LiteralPath $dumpPath -PathType Leaf)) {
    $problems += "Dump file not found: $dumpPath (check that DIRECTORY $($dump.OracleDirectory) points to $OutputFolder)"
}

if ($problems.Count -eq 0) {

    $expdpLog = Read-ExpdpLog -Path $dumpLogPath

    if (-not $expdpLog.Completed) {
        $problems += "expdp log does not say 'successfully completed'"
    }

    foreach ($e in $expdpLog.Errors) {
        $problems += "expdp log: $e"
    }

    $size = (Get-Item -LiteralPath $dumpPath).Length

    Write-Log "Dump size  : $(Format-Size $size) ($size bytes)"

    if ($size -lt $minBytes -or $size -gt $maxBytes) {
        $problems += "Dump size $size bytes is outside $minBytes - $maxBytes"
    }
}

if ($problems.Count -gt 0) {

    foreach ($p in $problems) {
        Write-Log $p "ERROR"
    }

    Set-DumpRejected
    Exit-Job $ExitCode.DumpValidationFailed
}

# Rows in the dump = rows the copy step imported
$mismatch = $false

foreach ($table in $dump.CountChecks.Keys) {

    $key       = $dump.CountChecks[$table]
    $tableName = ([string]$table).ToUpperInvariant()

    if (-not $expdpLog.Rows.ContainsKey($tableName)) {
        Write-Log "Table $tableName not found in the expdp log" "ERROR"
        $mismatch = $true
        continue
    }

    if ($expdpLog.Rows[$tableName] -ne $expected[$key]) {
        Write-Log ("{0}: {1:N0} rows exported, but the copy imported {2:N0}" -f `
            $tableName, $expdpLog.Rows[$tableName], $expected[$key]) "ERROR"
        $mismatch = $true
    }
    else {
        Write-Log ("{0}: {1:N0} rows exported = rows copied" -f $tableName, $expdpLog.Rows[$tableName])
    }
}

if ($mismatch) {
    Set-DumpRejected
    Exit-Job $ExitCode.DumpCountMismatch
}

Write-Log "Dump validation successful"

#--------------------------------------------------------------------------
# FIXED-NAME COPY FOR THE BCP APPLICATION
#--------------------------------------------------------------------------

if ($maintenance) {

    $tmp = "$maintenance.tmp"

    try {
        $folder = Split-Path $maintenance -Parent

        if (-not (Test-Path -LiteralPath $folder -PathType Container)) {
            New-Item -ItemType Directory -Path $folder -Force | Out-Null
        }

        Copy-Item -LiteralPath $dumpPath -Destination $tmp -Force

        if ((Get-Item -LiteralPath $tmp).Length -ne (Get-Item -LiteralPath $dumpPath).Length) {
            throw "Copied file size differs from the dump"
        }

        # Swap in the new file; the old one stays until this succeeds
        if (Test-Path -LiteralPath $maintenance) {
            # [NullString]::Value: PowerShell would turn $null into "" (rejected)
            [System.IO.File]::Replace($tmp, $maintenance, [NullString]::Value)
        }
        else {
            Move-Item -LiteralPath $tmp -Destination $maintenance
        }

        Write-Log "BCP copy   : $maintenance updated"
    }
    catch {
        Write-LogException $_.Exception
        Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
        Write-Log "The previous $maintenance was left unchanged" "ERROR"
        Exit-Job $ExitCode.MaintenanceCopyFailed
    }
}

Write-Log "Dump export complete"

Exit-Job $ExitCode.Success
