-- setup_dump_directory.sql - run ONCE on XE as SYSTEM:
--   sqlplus SYSTEM@XE @setup_dump_directory.sql
--
-- Creates the Oracle DIRECTORY expdp writes the dated dumps to. The name
-- must match Dump.OracleDirectory in jobs.psd1; the path is the job's
-- output folder <DataExtract root>\output\EMC_TDB_FREQPLAN (create the
-- folder first). The Oracle XE Windows service account needs write access
-- to it (by default it runs as Local System, which has it).

CREATE OR REPLACE DIRECTORY DATAEXTRACT_DUMP AS 'C:\SPECTRA_Automation\DataExtract\output\EMC_TDB_FREQPLAN';

SELECT directory_name, directory_path
  FROM dba_directories
 WHERE directory_name = 'DATAEXTRACT_DUMP';
