-- copy2tdb.sql - copies the prod monitoring results into the local XE (TDB)
--
-- Run by copy_to_xe.ps1 with "sqlplus -S /nolog". The passwords
-- (emc_password, emctdb_password) are DEFINEd by copy_to_xe.ps1 from the
-- encrypted credential files before this script starts.
--
-- Changes from the original:
--   - WHENEVER SQLERROR: stop at the first error instead of carrying on
--   - CONNECT to prod at the start (was the sqlplus command-line login)
--   - passwords in double quotes (special characters allowed)
--   - SPOOL removed: all output goes into the job log
--   - IMPORTED_*_ROWS lines at the end, checked by copy_to_xe.ps1
--   - trailing "/" removed (it re-ran the last count query)
--   - copy_to_xe.ps1 also drops the DB link before and after this
--     script, so a failure can no longer leave it behind

SET VERIFY OFF;
SET ECHO OFF;
SET HEADING OFF;

WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
WHENEVER OSERROR  EXIT FAILURE ROLLBACK

START config.sql;

CONNECT &&emc_username/"&&emc_password"@&&hostname;

-- After CONNECT: SQL*Plus starts with /nolog
SET SERVEROUTPUT ON SIZE 1000000;

select 
'>>> /*----------------------------------*/' || chr(10) ||
'>>>   Copy to TDB' || chr(10) ||
'>>> /*----------------------------------*/' || chr(10)
from dual;

-- Grants for emc_user and truncate _res tables of emctdb_user

CONNECT &&emctdb_username/"&&emctdb_password"@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=&&xe_hostname)(PORT=&&xe_port))(CONNECT_DATA=(SID=&&xe_sid)));

-- START grants_from_emctdb_to_emc.sql;

TRUNCATE TABLE tx_res_tab REUSE STORAGE;

TRUNCATE TABLE rx_res_tab REUSE STORAGE;

--Andrew, need also to truncate Tx_Rx_Geom_tab

TRUNCATE TABLE tx_rx_geom_tab REUSE STORAGE;
TRUNCATE TABLE tx_rx_vector_tab REUSE STORAGE;

-- recreate sequence with large value to avoid issues caused by trigger due to empty TX/RX_RES_EFL_ID values in central DB
drop sequence EMC_EFL_SEQ;
CREATE SEQUENCE EMC_EFL_SEQ
 INCREMENT BY 1
 START WITH 2000000
 MINVALUE 1
 NOMAXVALUE
 NOCYCLE
 NOCACHE
 NOORDER
;

-- Execute copying

CONNECT &&emc_username/"&&emc_password"@&&hostname;

CREATE DATABASE LINK linkToXeDb
CONNECT TO &&emctdb_username
IDENTIFIED BY "&&emctdb_password"
USING '&&xe_hostname:&&xe_port/&&xe_sid';

START copy_win10.sql;

ALTER SESSION CLOSE DATABASE LINK linkToXeDb;

DROP DATABASE LINK linkToXeDb;

CONNECT &&emctdb_username/"&&emctdb_password"@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=&&xe_hostname)(PORT=&&xe_port))(CONNECT_DATA=(SID=&&xe_sid)));

select 
'>>> /*----------------------------------*/' || chr(10) ||
'>>>   Copy to TDB finished' || chr(10) ||
'>>> /*----------------------------------*/' || chr(10)
from dual;

prompt ### Number of transmitters imported:
SELECT count(*) FROM tx_res_tab;

prompt ### Number of receivers imported:
SELECT count(*) FROM rx_res_tab;

-- Read by copy_to_xe.ps1: must equal PROD_TX_ROWS / PROD_RX_ROWS
SELECT 'IMPORTED_TX_ROWS=' || count(*) FROM tx_res_tab;
SELECT 'IMPORTED_RX_ROWS=' || count(*) FROM rx_res_tab;
