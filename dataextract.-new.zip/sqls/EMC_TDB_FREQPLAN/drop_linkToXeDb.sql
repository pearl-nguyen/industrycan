-- drop_linkToXeDb.sql - drops the DB link if it exists.
--
-- Run by copy_to_xe.ps1 before and after copy2tdb.sql (always, even when
-- the copy failed). Does not fail when the link is already gone
-- (ORA-02024), so it replaces the three separate drops of the old .bat
-- chain. emc_password is DEFINEd by copy_to_xe.ps1.

SET VERIFY OFF;
SET ECHO OFF;
SET FEEDBACK OFF;

WHENEVER SQLERROR CONTINUE

START config.sql;

CONNECT &&emc_username/"&&emc_password"@&&hostname;

-- After CONNECT: SQL*Plus starts with /nolog
SET SERVEROUTPUT ON;

BEGIN
  EXECUTE IMMEDIATE 'DROP DATABASE LINK linkToXeDb';
  DBMS_OUTPUT.PUT_LINE('DB link linkToXeDb dropped');
EXCEPTION
  WHEN OTHERS THEN
    IF SQLCODE != -2024 THEN   -- ORA-02024: database link not found
      RAISE;
    END IF;
END;
/
