#--------------------------------------------------------------------------
# ExitCodes.psm1
#   One table of named exit codes shared by every step, so each number
#   means the same thing everywhere and the calling task can tell which
#   step failed and why. Import this module first in every script.
#
#   Usage:  Exit-Job -Code $ExitCode.DbError -Cleanup { ... }   (JobLogging.psm1)
#           Get-ExitCodeName 20      ->  "DbError"
#
#   Ranges:
#     0       Success
#     1 - 9   General (any step)
#     10 - 19 Publish  (SharePoint\sharepoint_upload.ps1)
#     20 - 29 Extract  (oracle_extract.ps1)
#     30 - 39 Convert  (excel_convert.ps1)
#     40 - 49 SFTP     (ftp_upload.ps1)
#     50 - 59 Copy / dump (copy_to_xe.ps1, export_dump.ps1)
#--------------------------------------------------------------------------

# Module functions do not inherit the calling script's preference:
# make every cmdlet error terminating so the callers' catch blocks see it.
$ErrorActionPreference = "Stop"

$codes = [ordered]@{

    Success               = 0

    # General
    Unexpected            = 1    # unhandled error (caught by the safety-net trap)
    InputNotFound         = 2    # SQL file, CSV or local file to upload missing
    SetupFailed           = 3    # modules, config, log folder, driver, credential
    InvalidArgument       = 4    # e.g. -RunDate not in yyyyMMdd format

    # Publish (SharePoint)
    GraphAuthFailed       = 10   # Connect-MgGraph failed (certificate, app)
    SiteNotFound          = 11   # site or default document library not found
    TargetExists          = 12   # file exists in target and -Overwrite is $false
    FolderNotFound        = 13   # target folder missing, or staging not creatable
    MoveFailed            = 14   # validated file could not be moved to target
    UploadFailed          = 15   # upload or remote validation failed after retries

    # Extract (Oracle -> CSV)
    DbError               = 20   # connection or query failed after retries
    CsvValidationFailed   = 22   # row count / CSV parser check failed after retries
    RowCountOutOfRange    = 24   # rows outside ExpectedCount +/- CountTolerance

    # Convert (CSV -> Excel)
    ExpectedCountsMissing = 30   # no -ExpectedRows/-ExpectedColumns and no .meta file
    CsvHeaderMismatch     = 31   # CSV header column count differs from step 1
    ExcelConversionFailed = 32   # writing the workbook failed
    ExcelValidationFailed = 33   # workbook rows / columns / header differ from step 1
    ExcelTooManyRows      = 34   # over Excel's 1,048,576-row limit

    # SFTP (WinSCP)
    SftpConnectFailed     = 40   # could not open the session (host, key, login)
    SftpUploadFailed      = 41   # transfer failed after retries
    SftpVerifyFailed      = 42   # remote size differs from local after upload

    # Copy prod -> XE (SQL*Plus) and dump (expdp)
    CopyFailed            = 50   # SQL*Plus error (ORA- / SP2-) or non-zero exit
    CopyCountMismatch     = 51   # rows imported into XE differ from prod
    CopyTimeout           = 52   # copy ran longer than TimeoutHours
    DumpFailed            = 53   # expdp error, non-zero exit or timeout
    DumpValidationFailed  = 54   # expdp log, file missing or size out of range
    DumpCountMismatch     = 55   # rows in the dump differ from the copy step
    NotEnoughDiskSpace    = 56   # not enough free space for the dump
    MaintenanceCopyFailed = 57   # validated dump could not be copied for the BCP app
}

# Reverse lookup for log messages: 20 -> "DbError"
$script:CodeNames = @{}

foreach ($name in $codes.Keys) {
    $script:CodeNames[[int]$codes[$name]] = $name
}

# ReadOnly: scripts cannot reassign $ExitCode by accident
New-Variable -Name ExitCode -Value ([pscustomobject]$codes) -Option ReadOnly -Scope Script -Force

function Get-ExitCodeName {

    param(
        [Parameter(Mandatory = $true)]
        [int]$Code
    )

    if ($script:CodeNames.ContainsKey($Code)) {
        return $script:CodeNames[$Code]
    }

    return "Unknown"
}

Export-ModuleMember -Variable ExitCode -Function Get-ExitCodeName
