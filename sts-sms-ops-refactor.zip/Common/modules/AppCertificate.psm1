#--------------------------------------------------------------------------
# AppCertificate.psm1
#   The Entra app certificate: finding it, its expiry status, installing
#   a PFX into a specific key provider, and who can read its private key.
#   Used by the upload, the job report email and the install script.
#
#   Status codes ($CertStatus) are a contract with the calling jobs:
#     0 Ok, 1 ExpiringSoon, 2 Expired, 3 NotFound
#
#   Certificates are IDisposable (they hold a key handle). Functions that
#   return live certificates say so; the caller releases them with
#   Close-AppCertificate. Everything else releases what it opens.
#--------------------------------------------------------------------------

# Module functions do not inherit the calling script's preference:
# make every cmdlet error terminating so the callers' catch blocks see it.
$ErrorActionPreference = "Stop"

$codes = [ordered]@{
    Ok           = 0
    ExpiringSoon = 1
    Expired      = 2
    NotFound     = 3
}

$script:StatusNames = @{}

foreach ($name in $codes.Keys) {
    $script:StatusNames[[int]$codes[$name]] = $name
}

New-Variable -Name CertStatus -Value ([pscustomobject]$codes) -Option ReadOnly -Scope Script -Force

# Windows tools used for the PFX import and key permissions
$script:CertutilExe = "certutil.exe"
$script:IcaclsExe   = "icacls.exe"

# Runs a native program and returns ExitCode and Output (stdout + stderr).
# Windows PowerShell 5.1 turns stderr into terminating errors when the
# preference is Stop, so it is relaxed here only; success is judged by
# the exit code.
function Invoke-NativeCommand {

    param(
        [Parameter(Mandatory = $true)][string]$FilePath,
        [string[]]$Arguments = @()
    )

    $ErrorActionPreference = "Continue"

    $output = & $FilePath @Arguments 2>&1 | ForEach-Object { "$_" }

    return [pscustomobject]@{
        ExitCode = $LASTEXITCODE
        Output   = ($output -join [Environment]::NewLine)
    }
}

# 0 -> "Ok", 3 -> "NotFound"
function Get-CertStatusName {

    param(
        [Parameter(Mandatory = $true)]
        [int]$Code
    )

    if ($script:StatusNames.ContainsKey($Code)) {
        return $script:StatusNames[$Code]
    }

    return "Unknown"
}

function Get-CertStorePath {

    param(
        [string]$StoreLocation,
        [string]$StoreName
    )

    return "Cert:\$StoreLocation\$StoreName"
}

# certutil switch for the user store (machine store is the default)
function Get-CertutilStoreArgs {

    param([string]$StoreLocation)

    if ($StoreLocation -eq "CurrentUser") {
        return @("-user")
    }

    return @()
}

# Releases certificates (and their key handles). Safe with $null.
function Close-AppCertificate {

    param($Certificates)

    foreach ($c in @($Certificates)) {
        if ($c -is [System.IDisposable]) {
            $c.Dispose()
        }
    }
}

# Plain facts about a certificate, so callers need not hold the live object
function Get-CertificateSummary {

    param([Parameter(Mandatory = $true)]$Certificate)

    return [pscustomobject]@{
        Subject    = $Certificate.Subject
        Thumbprint = $Certificate.Thumbprint
        NotBefore  = $Certificate.NotBefore
        NotAfter   = $Certificate.NotAfter
    }
}

#--------------------------------------------------------------------------
# FIND / EXPIRY
#--------------------------------------------------------------------------

# Newest certificate with this subject and a private key, or $null.
# With -All, every match, newest first.
# Returns LIVE certificates: release them with Close-AppCertificate.
function Get-AppCertificate {

    param(
        [Parameter(Mandatory = $true)][string]$Subject,
        [Parameter(Mandatory = $true)][string]$StoreLocation,
        [Parameter(Mandatory = $true)][string]$StoreName,
        [switch]$All
    )

    $inStore = @(Get-ChildItem -Path (Get-CertStorePath $StoreLocation $StoreName))

    $matched = @($inStore |
        Where-Object { $_.Subject -eq $Subject -and $_.HasPrivateKey } |
        Sort-Object NotAfter -Descending)

    if ($All) {
        $keep = $matched
    }
    else {
        $keep = @($matched | Select-Object -First 1)
    }

    # Release every certificate opened from the store that is not returned
    # (matched by thumbprint: exact, and unique within a store)
    $keepThumbprints = @($keep | ForEach-Object { $_.Thumbprint })
    Close-AppCertificate @($inStore | Where-Object { $keepThumbprints -notcontains $_.Thumbprint })

    return $keep
}

# Expiry status of the newest certificate. Returns Code, Status, Subject,
# Thumbprint, NotAfter, DaysLeft (no live certificate is returned).
function Get-CertExpiryStatus {

    param(
        [Parameter(Mandatory = $true)][string]$Subject,
        [Parameter(Mandatory = $true)][int]$WarningDays,
        [Parameter(Mandatory = $true)][string]$StoreLocation,
        [Parameter(Mandatory = $true)][string]$StoreName,
        [datetime]$Now = (Get-Date)
    )

    $cert = Get-AppCertificate -Subject $Subject -StoreLocation $StoreLocation -StoreName $StoreName

    if (-not $cert) {
        return [pscustomobject]@{
            Code       = $CertStatus.NotFound
            Status     = Get-CertStatusName $CertStatus.NotFound
            Subject    = $Subject
            Thumbprint = $null
            NotAfter   = $null
            DaysLeft   = $null
        }
    }

    try {
        $summary = Get-CertificateSummary $cert
    }
    finally {
        Close-AppCertificate $cert
    }

    $daysLeft = [int][math]::Floor(($summary.NotAfter - $Now).TotalDays)

    if ($summary.NotAfter -le $Now) {
        $code = $CertStatus.Expired
    }
    elseif ($daysLeft -le $WarningDays) {
        $code = $CertStatus.ExpiringSoon
    }
    else {
        $code = $CertStatus.Ok
    }

    return [pscustomobject]@{
        Code       = $code
        Status     = Get-CertStatusName $code
        Subject    = $Subject
        Thumbprint = $summary.Thumbprint
        NotAfter   = $summary.NotAfter
        DaysLeft   = $daysLeft
    }
}

#--------------------------------------------------------------------------
# INSTALL / REMOVE
#--------------------------------------------------------------------------

# Subject, thumbprint and dates of the end-entity certificate in a PFX.
# Nothing is installed; every certificate read from the PFX is released.
function Get-PfxCertificateInfo {

    param(
        [Parameter(Mandatory = $true)][string]$PfxPath,
        [Parameter(Mandatory = $true)][securestring]$Password
    )

    $pfx = Get-PfxData -FilePath $PfxPath -Password $Password

    try {
        $cert = $pfx.EndEntityCertificates | Select-Object -First 1

        if (-not $cert) {
            return $null
        }

        return Get-CertificateSummary $cert
    }
    finally {
        Close-AppCertificate @($pfx.EndEntityCertificates)
        Close-AppCertificate @($pfx.OtherCertificates)
    }
}

# Imports a PFX into the store with its key in the given provider.
# certutil is used because Import-PfxCertificate cannot choose the provider.
function Install-PfxWithProvider {

    param(
        [Parameter(Mandatory = $true)][string]$PfxPath,
        [Parameter(Mandatory = $true)][securestring]$Password,
        [Parameter(Mandatory = $true)][string]$StoreLocation,
        [Parameter(Mandatory = $true)][string]$StoreName,
        [Parameter(Mandatory = $true)][string]$KeyStorageProvider,
        [Parameter(Mandatory = $true)][bool]$NonExportable
    )

    $bstr  = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Password)
    $plain = $null

    try {
        $plain = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)

        $certutilArgs  = @("-f", "-p", $plain, "-csp", $KeyStorageProvider)
        $certutilArgs += Get-CertutilStoreArgs $StoreLocation
        $certutilArgs += @("-importpfx", $StoreName, $PfxPath)

        if ($NonExportable) {
            $certutilArgs += "NoExport"
        }

        $result = Invoke-NativeCommand -FilePath $script:CertutilExe -Arguments $certutilArgs

        if ($result.ExitCode -ne 0) {
            throw "certutil import failed (check the password):`n$($result.Output)"
        }
    }
    finally {
        $plain        = $null
        $certutilArgs = $null
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
    }
}

# Whether the certificate's private key is in $ExpectedProvider.
# Read through .NET, so it does not depend on the Windows display language.
# Returns Matches and the provider name found.
function Test-CertKeyProvider {

    param(
        [Parameter(Mandatory = $true)]$Certificate,
        [Parameter(Mandatory = $true)][string]$ExpectedProvider
    )

    $provider = (Get-CngKeyInfo $Certificate).Provider

    return [pscustomobject]@{
        Matches  = ($provider -eq $ExpectedProvider)
        Provider = $provider
    }
}

# Deletes certificates together with their private keys, then releases them
function Remove-AppCertificate {

    param(
        [Parameter(Mandatory = $true)]$Certificates,
        [Parameter(Mandatory = $true)][string]$StoreLocation,
        [Parameter(Mandatory = $true)][string]$StoreName
    )

    foreach ($c in @($Certificates)) {
        $thumb = $c.Thumbprint
        Remove-Item (Join-Path (Get-CertStorePath $StoreLocation $StoreName) $thumb) -DeleteKey
        Close-AppCertificate $c
        Write-Host "Deleted $thumb" -ForegroundColor Green
    }
}

#--------------------------------------------------------------------------
# PRIVATE KEY ACCESS
#--------------------------------------------------------------------------

# Unique (file) name and provider of the certificate's CNG private key.
# Releases the RSA object and the key handle it opens.
function Get-CngKeyInfo {

    param([Parameter(Mandatory = $true)]$Certificate)

    $rsa = [System.Security.Cryptography.X509Certificates.RSACertificateExtensions]::GetRSAPrivateKey($Certificate)

    if (-not $rsa) {
        throw "Certificate $($Certificate.Thumbprint) has no RSA private key."
    }

    $key = $null

    try {
        if (-not ($rsa -is [System.Security.Cryptography.RSACng])) {
            throw "Private key of $($Certificate.Thumbprint) is not a CNG key (legacy CSP?)."
        }

        $key = $rsa.Key

        return [pscustomobject]@{
            UniqueName = $key.UniqueName
            Provider   = $key.Provider.Provider
        }
    }
    finally {
        try {
            if ($key) { $key.Dispose() }
        }
        finally {
            $rsa.Dispose()
        }
    }
}

# File holding the certificate's CNG private key
function Get-CertKeyPath {

    param(
        [Parameter(Mandatory = $true)]$Certificate,
        [Parameter(Mandatory = $true)][string]$KeysFolder
    )

    $uniqueName = (Get-CngKeyInfo $Certificate).UniqueName

    $path = Get-ChildItem -LiteralPath $KeysFolder -Filter $uniqueName -ErrorAction SilentlyContinue |
        Select-Object -First 1 -ExpandProperty FullName

    if (-not $path) {
        throw "Private key file not found for $($Certificate.Thumbprint) (TPM key?)."
    }

    return $path
}

function ConvertTo-SidString {

    param($IdentityReference)

    try {
        return $IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value
    }
    catch {
        return "$IdentityReference"
    }
}

# SIDs allowed on the key that match $ReaderSidPatterns (users/groups,
# not SYSTEM/Administrators)
function Get-CertKeyReaderSids {

    param(
        [Parameter(Mandatory = $true)]$Certificate,
        [Parameter(Mandatory = $true)][string]$KeysFolder,
        [Parameter(Mandatory = $true)][string[]]$ReaderSidPatterns
    )

    return @((Get-Acl (Get-CertKeyPath $Certificate $KeysFolder)).Access |
        Where-Object { $_.AccessControlType -eq "Allow" } |
        ForEach-Object { ConvertTo-SidString $_.IdentityReference } |
        Where-Object {
            $sid = $_
            @($ReaderSidPatterns | Where-Object { $sid -like $_ }).Count -gt 0
        } |
        Select-Object -Unique)
}

function Show-CertKeyAccess {

    param(
        [Parameter(Mandatory = $true)]$Certificates,
        [Parameter(Mandatory = $true)][string]$KeysFolder,
        [Parameter(Mandatory = $true)][string]$DateFormat,
        [Parameter(Mandatory = $true)][string]$UnknownAccountText
    )

    foreach ($c in @($Certificates)) {

        Write-Host "`n$($c.Subject)  $($c.Thumbprint)  expires $($c.NotAfter.ToString($DateFormat))" -ForegroundColor Cyan

        (Get-Acl (Get-CertKeyPath $c $KeysFolder)).Access | ForEach-Object {

            $sid  = ConvertTo-SidString $_.IdentityReference
            $name = try {
                ([Security.Principal.SecurityIdentifier]$sid).Translate([Security.Principal.NTAccount]).Value
            }
            catch {
                $UnknownAccountText
            }

            [pscustomobject]@{
                Name   = $name
                SID    = $sid
                Rights = $_.FileSystemRights
                Type   = $_.AccessControlType
            }
        } | Format-Table -AutoSize | Out-Host
    }
}

function Grant-CertKeyRead {

    param(
        [Parameter(Mandatory = $true)]$Certificates,
        [Parameter(Mandatory = $true)][string[]]$Sids,
        [Parameter(Mandatory = $true)][string]$KeysFolder
    )

    foreach ($c in @($Certificates)) {

        $path = Get-CertKeyPath $c $KeysFolder

        foreach ($sid in $Sids) {

            $result = Invoke-NativeCommand -FilePath $script:IcaclsExe -Arguments @($path, "/grant", "*$($sid):R")

            if ($result.ExitCode -ne 0) {
                throw "icacls grant failed for $sid on $($c.Thumbprint):`n$($result.Output)"
            }

            Write-Host "Granted read : $sid  ->  $($c.Thumbprint)" -ForegroundColor Green
        }
    }
}

function Revoke-CertKeyRead {

    param(
        [Parameter(Mandatory = $true)]$Certificates,
        [Parameter(Mandatory = $true)][string[]]$Sids,
        [Parameter(Mandatory = $true)][string]$KeysFolder,

        # Never removed (SYSTEM, Administrators)
        [Parameter(Mandatory = $true)][string[]]$ProtectedSids
    )

    foreach ($sid in $Sids) {

        if ($ProtectedSids -contains $sid) {
            Write-Warning "Skipping $sid (protected: cannot be removed)."
            continue
        }

        foreach ($c in @($Certificates)) {

            $result = Invoke-NativeCommand -FilePath $script:IcaclsExe -Arguments @((Get-CertKeyPath $c $KeysFolder), "/remove", "*$sid")

            if ($result.ExitCode -ne 0) {
                throw "icacls remove failed for $sid on $($c.Thumbprint):`n$($result.Output)"
            }

            Write-Host "Removed      : $sid  <-  $($c.Thumbprint)" -ForegroundColor Yellow
        }
    }
}

Export-ModuleMember -Variable CertStatus -Function `
    Get-CertStatusName,
    Close-AppCertificate,
    Get-CertificateSummary,
    Get-AppCertificate,
    Get-CertExpiryStatus,
    Get-PfxCertificateInfo,
    Install-PfxWithProvider,
    Test-CertKeyProvider,
    Remove-AppCertificate,
    Get-CertKeyPath,
    Get-CertKeyReaderSids,
    Show-CertKeyAccess,
    Grant-CertKeyRead,
    Revoke-CertKeyRead
