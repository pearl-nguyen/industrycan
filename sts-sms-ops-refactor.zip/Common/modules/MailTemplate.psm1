#--------------------------------------------------------------------------
# MailTemplate.psm1
#   {{Placeholder}} templates for email subjects and HTML bodies.
#--------------------------------------------------------------------------

# Module functions do not inherit the calling script's preference:
# make every cmdlet error terminating so the callers' catch blocks see it.
$ErrorActionPreference = "Stop"

# Template syntax
$script:PlaceholderOpen  = "{{"
$script:PlaceholderClose = "}}"
$script:CommentPattern   = '(?s)<!--.*?-->'                # template notes, removed
$script:LeftoverPattern  = '\{\{(\w+)\}\}'              # placeholders nobody filled

# Reads a template file and drops <!-- comments --> (template notes)
function Read-MailTemplate {

    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    $text = Get-Content -LiteralPath $Path -Raw -Encoding UTF8

    # -Raw returns $null for an empty file
    if ([string]::IsNullOrWhiteSpace($text)) {
        throw "Template is empty: $Path"
    }

    return [regex]::Replace($text, $script:CommentPattern, '')
}

# "Name" -> "{{Name}}"
function Format-Placeholder {

    param([string]$Name)

    return $script:PlaceholderOpen + $Name + $script:PlaceholderClose
}

# Replaces {{Name}} with $Values[Name]. With -Html, values are HTML-encoded
# and $RawHtml values are inserted as-is; without -Html (e.g. a subject
# line) $RawHtml placeholders become empty.
# Warns about any placeholder left (usually a typo in the template).
function Expand-Template {

    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyString()]
        [string]$Text,

        [System.Collections.IDictionary]$Values = @{},

        [System.Collections.IDictionary]$RawHtml = @{},

        [switch]$Html
    )

    foreach ($k in @($Values.Keys)) {

        $v = [string]$Values[$k]

        if ($Html) {
            $v = [System.Net.WebUtility]::HtmlEncode($v)
        }

        $Text = $Text.Replace((Format-Placeholder $k), $v)
    }

    foreach ($k in @($RawHtml.Keys)) {

        if ($Html) {
            $Text = $Text.Replace((Format-Placeholder $k), [string]$RawHtml[$k])
        }
        else {
            $Text = $Text.Replace((Format-Placeholder $k), "")
        }
    }

    $left = [regex]::Matches($Text, $script:LeftoverPattern) |
        ForEach-Object { $_.Groups[1].Value } |
        Select-Object -Unique

    if ($left) {
        Write-Warning "Unknown placeholder(s) in template: $($left -join ', ')"
    }

    return $Text
}

Export-ModuleMember -Function Read-MailTemplate, Expand-Template
