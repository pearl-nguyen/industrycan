#--------------------------------------------------------------------------
# SpPublish.psm1
#   Building blocks for "upload to staging, validate, then publish":
#     - unique staging names
#     - local file fingerprint (size + the hash the validation needs)
#     - validation of the uploaded copy against the local file
#     - removal of a run's own staging copy
#   Requires JobLogging.psm1, HttpHelpers.psm1, FileValidation.psm1 and
#   SpGraph.psm1 to be imported by the calling script. All timings come
#   from the caller.
#
#   Test-SpRemoteCopy throws System.TimeoutException when SharePoint has
#   not computed the hash yet: the copy may well be fine, so the caller
#   can check the same copy again instead of uploading it again.
#--------------------------------------------------------------------------

# Module functions do not inherit the calling script's preference:
# make every cmdlet error terminating so the callers' catch blocks see it.
$ErrorActionPreference = "Stop"

# Hash used per kind of file (names only, for logs)
$script:OfficeHashName = "SHA256"
$script:OtherHashName  = "QuickXor"

# Unique name so concurrent jobs never collide in the staging folder:
#   <timestamp>_<random>_<file name>
function New-SpStagingName {

    param(
        [Parameter(Mandatory = $true)][string]$FileName,
        [Parameter(Mandatory = $true)][string]$TimestampFormat,
        [Parameter(Mandatory = $true)][ValidateRange(1, 32)][int]$RandomLength
    )

    $random = [guid]::NewGuid().ToString("N").Substring(0, $RandomLength)

    return "{0}_{1}_{2}" -f (Get-Date -Format $TimestampFormat), $random, $FileName
}

# Office files are later compared part by part (SHA256 kept for the log);
# everything else by SharePoint's QuickXorHash, computed here once.
function Get-LocalFileFingerprint {

    param(
        [Parameter(Mandatory = $true)][string]$Path
    )

    $item = Get-Item -LiteralPath $Path

    if ($item.PSIsContainer) {
        throw "Not a file: $Path"
    }

    $isOffice = Test-IsOfficeFile $item.FullName

    if ($isOffice) {
        $hashName = $script:OfficeHashName
        $hash     = Get-FileSHA256 $item.FullName
    }
    else {
        $hashName = $script:OtherHashName
        $hash     = Get-FileQuickXorHash $item.FullName
    }

    return [pscustomobject]@{
        Path      = $item.FullName
        Name      = $item.Name
        Extension = $item.Extension.ToLower()
        Size      = $item.Length
        IsOffice  = $isOffice
        HashName  = $hashName
        Hash      = $hash
    }
}

# Office: download the copy and compare content parts (SharePoint's
# metadata ignored). The download is always deleted unless the check
# failed and -KeepFailedDownload is set (kept for inspection).
function Test-SpOfficeCopy {

    param(
        [string]$DriveId,
        [string]$ItemId,
        $Local,
        [string]$TempFolder,
        [string]$TempFilePrefix,
        [int]$SettleSeconds,
        [bool]$KeepFailedDownload
    )

    if (-not (Test-Path -LiteralPath $TempFolder -PathType Container)) {
        New-Item -ItemType Directory -Path $TempFolder -Force | Out-Null
    }

    # Give SharePoint time to finish adding its metadata
    Start-Sleep -Seconds $SettleSeconds

    $tempFile = Join-Path $TempFolder ($TempFilePrefix + [guid]::NewGuid().ToString() + $Local.Extension)
    $failed   = $true

    try {
        Save-SpItemContent -DriveId $DriveId -ItemId $ItemId -OutFile $tempFile

        Write-Log "Remote SHA256 : $(Get-FileSHA256 $tempFile)"

        try {
            $diffs = @(Compare-OfficeContent $Local.Path $tempFile)
        }
        catch {
            throw "Downloaded file is not a valid Office package: $($_.Exception.Message)"
        }

        foreach ($d in $diffs) {
            Write-Log $d "ERROR"
        }

        if ($diffs.Count -gt 0) {
            throw "Content validation failed"
        }

        Write-Log "Content parts identical (SharePoint metadata ignored)"
        $failed = $false
    }
    finally {
        if (Test-Path -LiteralPath $tempFile) {

            if ($failed -and $KeepFailedDownload) {
                Write-Log "Downloaded copy kept for inspection: $tempFile" "WARN"
            }
            else {
                Remove-Item -LiteralPath $tempFile -Force -ErrorAction SilentlyContinue
            }
        }
    }
}

# Other files: size and SharePoint's QuickXorHash, nothing downloaded
function Test-SpHashCopy {

    param(
        [string]$DriveId,
        $RemoteItem,
        $Local,
        [int]$HashWaitSeconds,
        [int]$HashPollSeconds
    )

    if ($RemoteItem.size -ne $Local.Size) {
        throw "Size validation failed (local $($Local.Size), remote $($RemoteItem.size))"
    }

    $remoteHash = Wait-SpQuickXorHash `
        -DriveId $DriveId `
        -ItemId $RemoteItem.id `
        -TimeoutSeconds $HashWaitSeconds `
        -PollSeconds $HashPollSeconds

    if (-not $remoteHash) {
        # Not a mismatch: the hash is just not ready (see module header)
        throw (New-Object System.TimeoutException(
            "SharePoint did not provide a QuickXorHash within $HashWaitSeconds seconds"))
    }

    Write-Log "Remote QuickXor : $remoteHash"

    # Base64 is case-sensitive (PowerShell's -ne is not)
    if ($remoteHash -cne $Local.Hash) {
        throw "QuickXorHash validation failed"
    }

    Write-Log "QuickXorHash identical"
}

# Validates the uploaded copy against the local file. Throws on any
# difference; returns nothing when the copy is good.
function Test-SpRemoteCopy {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [Parameter(Mandatory = $true)][string]$ItemId,

        # From Get-LocalFileFingerprint
        [Parameter(Mandatory = $true)]$Local,

        # Office files only
        [Parameter(Mandatory = $true)][string]$TempFolder,
        [Parameter(Mandatory = $true)][string]$TempFilePrefix,
        [Parameter(Mandatory = $true)][int]$OfficeSettleSeconds,
        [bool]$KeepFailedDownload = $false,

        # Other files only
        [Parameter(Mandatory = $true)][int]$HashWaitSeconds,
        [Parameter(Mandatory = $true)][int]$HashPollSeconds
    )

    $remoteItem = Get-SpItem -DriveId $DriveId -ItemId $ItemId

    if (-not $remoteItem -or -not $remoteItem.id) {
        throw "Remote file not found"
    }

    Write-Log "Remote Size : $($remoteItem.size)"

    if ($Local.IsOffice) {

        Test-SpOfficeCopy `
            -DriveId $DriveId `
            -ItemId $remoteItem.id `
            -Local $Local `
            -TempFolder $TempFolder `
            -TempFilePrefix $TempFilePrefix `
            -SettleSeconds $OfficeSettleSeconds `
            -KeepFailedDownload $KeepFailedDownload
    }
    else {

        Test-SpHashCopy `
            -DriveId $DriveId `
            -RemoteItem $remoteItem `
            -Local $Local `
            -HashWaitSeconds $HashWaitSeconds `
            -HashPollSeconds $HashPollSeconds
    }
}

# Removes a run's own staging copy. Safe: the name is unique to the run,
# and the item is deleted only while it is still in the staging folder.
# A moved item keeps its id, so without that check a failure right after
# a successful move could delete the published file. Never throws.
function Remove-SpStagedItem {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [Parameter(Mandatory = $true)][string]$StagingFolderId,
        $Item
    )

    if (-not $Item -or -not $Item.id) {
        return
    }

    try {
        $current = Get-SpItem -DriveId $DriveId -ItemId $Item.id

        if (-not $current) {
            return
        }

        $parentId = $null
        if ($current.parentReference) {
            $parentId = $current.parentReference.id
        }

        if ($parentId -ne $StagingFolderId) {
            Write-Log "Not removed: '$($current.name)' is no longer in the staging folder" "WARN"
            return
        }

        Remove-SpItem -DriveId $DriveId -ItemId $Item.id
        Write-Log "Staging copy removed: $($current.name)"
    }
    catch {
        # Already gone is fine; anything else is only a warning
        if (Test-IsNotFoundError $_.Exception.Message) {
            return
        }

        Write-Log "Could not remove staging copy: $($Item.name)" "WARN"
        Write-LogException $_.Exception
    }
}

Export-ModuleMember -Function `
    New-SpStagingName,
    Get-LocalFileFingerprint,
    Test-SpRemoteCopy,
    Remove-SpStagedItem
