#--------------------------------------------------------------------------
# JobReport.psm1
#   Builds the job report email (subject + HTML body) from the JobReport
#   section of notification_config.psd1 and a template.
#   Requires AppCertificate.psm1 and MailTemplate.psm1 to be imported by
#   the calling script. Sending is done by Send-GraphMail.
#--------------------------------------------------------------------------

# Module functions do not inherit the calling script's preference:
# make every cmdlet error terminating so the callers' catch blocks see it.
$ErrorActionPreference = "Stop"

# Placeholders this module fills besides the values it lists itself:
# the action paragraph (raw HTML) and its text inside CertActionHtml
$script:ActionPlaceholder     = "CertAction"
$script:ActionTextPlaceholder = "CertActionText"

# Value as text, or the configured "not provided" text when empty
function Get-ValueOrDefault {

    param(
        [AllowNull()][AllowEmptyString()][string]$Value,
        [Parameter(Mandatory = $true)][string]$Default
    )

    if ([string]::IsNullOrEmpty($Value)) {
        return $Default
    }

    return $Value
}

# Certificate status for the report, checked now. Returns Code, DaysLeft
# and ExpiryDate (text, empty when not found).
function Get-JobReportCertInfo {

    param(
        # Certificate section of SecurityConfig.psd1
        [Parameter(Mandatory = $true)][System.Collections.IDictionary]$Certificate,
        [Parameter(Mandatory = $true)][string]$ExpiryDateFormat
    )

    $status = Get-CertExpiryStatus `
        -Subject $Certificate.Subject `
        -WarningDays $Certificate.WarningDays `
        -StoreLocation $Certificate.StoreLocation `
        -StoreName $Certificate.StoreName

    $daysLeft   = ""
    $expiryDate = ""

    if ($null -ne $status.DaysLeft) { $daysLeft   = "$($status.DaysLeft)" }
    if ($status.NotAfter)           { $expiryDate = $status.NotAfter.ToString($ExpiryDateFormat) }

    return [pscustomobject]@{
        Code       = $status.Code
        DaysLeft   = $daysLeft
        ExpiryDate = $expiryDate
    }
}

# Returns Subject and Html for one job run
function New-JobReportMessage {

    param(
        # JobReport section of notification_config.psd1
        [Parameter(Mandatory = $true)][System.Collections.IDictionary]$Report,
        [Parameter(Mandatory = $true)][string]$TemplatePath,
        [Parameter(Mandatory = $true)][string]$CertificateSubject,

        [Parameter(Mandatory = $true)][string]$JobName,
        [Parameter(Mandatory = $true)][string]$Status,
        [string]$Step = "",
        [int]$ExitCode = 0,
        [Parameter(Mandatory = $true)][ValidateRange(0, 3)][int]$CertStatusCode,
        [string]$CertDaysLeft = "",
        [string]$CertExpiryDate = "",
        [Parameter(Mandatory = $true)][datetime]$RunDate,
        [string]$LogPath = "",
        [Parameter(Mandatory = $true)][string]$Machine
    )

    $statusName = Get-CertStatusName $CertStatusCode
    $certStyle  = $Report.CertStatus[$statusName]

    if (-not $certStyle) {
        throw "JobReport.CertStatus.$statusName is missing in the config"
    }

    $statusColor = $Report.StatusColors[$Status]

    if (-not $statusColor) {
        throw "JobReport.StatusColors.$Status is missing in the config"
    }

    $empty = $Report.EmptyValue

    $values = [ordered]@{
        JobName        = $JobName
        RunDate        = $RunDate.ToString($Report.DateFormat)
        Status         = $Status.ToUpper()
        StatusColor    = $statusColor
        Step           = Get-ValueOrDefault $Step $empty
        ExitCode       = "$ExitCode"
        Machine        = $Machine
        LogPath        = Get-ValueOrDefault $LogPath $empty
        CertStatus     = $certStyle.Label
        CertCode       = "$CertStatusCode"
        CertColor      = $certStyle.Color
        CertExpiryDate = Get-ValueOrDefault $CertExpiryDate $empty
        CertDaysLeft   = Get-ValueOrDefault $CertDaysLeft $empty
        CertSubject    = $CertificateSubject
    }

    # Action paragraph: the status's Action text inside CertActionHtml
    # (no paragraph when Action is empty)
    $certAction = ""

    if ($certStyle.Action) {

        $actionValues = [ordered]@{}
        foreach ($k in $values.Keys) { $actionValues[$k] = $values[$k] }

        $actionValues[$script:ActionTextPlaceholder] = Expand-Template -Text $certStyle.Action -Values $values

        $certAction = Expand-Template -Text $Report.CertActionHtml -Values $actionValues -Html
    }

    $rawHtml = @{ $script:ActionPlaceholder = $certAction }   # inserted as-is (already HTML)

    $subject = Expand-Template -Text $Report.Subject -Values $values -RawHtml $rawHtml

    if ($CertStatusCode -ne $CertStatus.Ok -and $Report.CertSubjectSuffix) {
        $subject += Expand-Template -Text $Report.CertSubjectSuffix -Values $values
    }

    $html = Expand-Template `
        -Text (Read-MailTemplate -Path $TemplatePath) `
        -Values $values `
        -RawHtml $rawHtml `
        -Html

    return [pscustomobject]@{
        Subject = $subject
        Html    = $html
    }
}

Export-ModuleMember -Function `
    Get-ValueOrDefault,
    Get-JobReportCertInfo,
    New-JobReportMessage
