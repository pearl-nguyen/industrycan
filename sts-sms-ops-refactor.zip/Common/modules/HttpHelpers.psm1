#--------------------------------------------------------------------------
# HttpHelpers.psm1
#   Generic helpers for calling HTTP / REST APIs:
#   URL path encoding, HTTP error classification, retry with backoff,
#   HttpClient creation (TLS 1.2 on Windows PowerShell 5.1), streamed
#   download of a URL to a file (any size).
#   Not tied to SharePoint; reusable by any script.
#   Requires JobLogging.psm1 (Write-Log, Write-LogException) to be imported
#   by the calling script.
#   Retry timings: callers pass them from config. The defaults below only
#   apply to older steps that do not pass them yet.
#--------------------------------------------------------------------------

# Module functions do not inherit the calling script's preference:
# make every cmdlet error terminating so the callers' catch blocks see it.
$ErrorActionPreference = "Stop"

Add-Type -AssemblyName System.Net.Http

$script:DefaultMaxRetries       = 3
$script:DefaultBaseDelay        = 5
$script:DefaultMaxJitterSeconds = 5

# How HTTP errors show up in exception messages (Graph error codes and
# HTTP status). These describe the protocol, they are not settings.
$script:ConflictPattern = 'nameAlreadyExists|\(409\)|\b409\b|Conflict'
$script:NotFoundPattern = 'itemNotFound|NotFound|\(404\)|\b404\b'

#--------------------------------------------------------------------------
# PATH / ERROR HELPERS
#--------------------------------------------------------------------------

# URL-encodes each segment of a path so spaces, #, %, accents etc. are safe
function ConvertTo-EncodedPath {

    param([string[]]$Parts)

    $segments = @()

    foreach ($part in $Parts) {

        if ([string]::IsNullOrWhiteSpace($part)) {
            continue
        }

        foreach ($seg in ($part -split '[\\/]')) {

            if ($seg -ne '') {
                $segments += [uri]::EscapeDataString($seg)
            }
        }
    }

    return ($segments -join '/')
}

function Test-IsConflictError {

    param([string]$Message)

    return ($Message -match $script:ConflictPattern)
}

function Test-IsNotFoundError {

    param([string]$Message)

    return ($Message -match $script:NotFoundPattern)
}

#--------------------------------------------------------------------------
# RETRY
#--------------------------------------------------------------------------

# Exponential backoff with jitter:
#   BaseDelay * 2^(Attempt-1) + random 1..MaxJitterSeconds (0 = no jitter)
function Get-RetryDelay {

    param(
        [Parameter(Mandatory = $true)][int]$Attempt,
        [int]$BaseDelay        = $script:DefaultBaseDelay,
        [int]$MaxJitterSeconds = $script:DefaultMaxJitterSeconds
    )

    $jitter = 0

    if ($MaxJitterSeconds -ge 1) {
        $jitter = Get-Random -Minimum 1 -Maximum ($MaxJitterSeconds + 1)
    }

    return [int](($BaseDelay * [math]::Pow(2, $Attempt - 1)) + $jitter)
}

# Runs a script block with retries. $ShouldRetry receives the error message
# and returns $false for errors that must not be retried (e.g. conflicts).
function Invoke-WithRetry {

    param(
        [Parameter(Mandatory = $true)][scriptblock]$ScriptBlock,
        [int]$MaxRetries       = $script:DefaultMaxRetries,
        [int]$BaseDelay        = $script:DefaultBaseDelay,
        [int]$MaxJitterSeconds = $script:DefaultMaxJitterSeconds,
        [string]$Activity = "Operation",
        [scriptblock]$ShouldRetry = { param($Message) $true }
    )

    for ($attempt = 1; $attempt -le $MaxRetries; $attempt++) {

        try {
            Write-Log "$Activity - attempt $attempt of $MaxRetries"
            return & $ScriptBlock
        }
        catch {

            $message = $_.Exception.Message

            if ($attempt -ge $MaxRetries -or -not (& $ShouldRetry $message)) {
                throw
            }

            Write-LogException $_.Exception

            $delay = Get-RetryDelay -Attempt $attempt -BaseDelay $BaseDelay -MaxJitterSeconds $MaxJitterSeconds

            Write-Log "Retrying in $delay seconds" "WARN"

            Start-Sleep -Seconds $delay
        }
    }
}

#--------------------------------------------------------------------------
# HTTP CLIENT
#--------------------------------------------------------------------------

# Windows PowerShell 5.1 runs on .NET Framework, whose default protocols
# may not include TLS 1.2 (required by Microsoft 365). Adds it without
# removing anything already enabled.
function Enable-Tls12 {

    $tls12 = [System.Net.SecurityProtocolType]::Tls12

    if (([System.Net.ServicePointManager]::SecurityProtocol -band $tls12) -ne $tls12) {
        [System.Net.ServicePointManager]::SecurityProtocol =
            [System.Net.ServicePointManager]::SecurityProtocol -bor $tls12
    }
}

# New HttpClient with the given timeout. The caller must Dispose() it.
function New-HttpClient {

    param(
        [Parameter(Mandatory = $true)][ValidateRange(1, 1440)][int]$TimeoutMinutes
    )

    Enable-Tls12

    $client = New-Object System.Net.Http.HttpClient

    try {
        $client.Timeout = [TimeSpan]::FromMinutes($TimeoutMinutes)
    }
    catch {
        $client.Dispose()
        throw
    }

    return $client
}

#--------------------------------------------------------------------------
# DOWNLOAD
#--------------------------------------------------------------------------

# Streams a URL to a file without holding it in memory. Returns bytes
# written. Checks the size against Content-Length when the server sends
# it, and deletes the partial file if anything fails.
function Save-UrlToFile {

    param(
        [Parameter(Mandatory = $true)][string]$Url,
        [Parameter(Mandatory = $true)][string]$OutFile,

        # Covers getting the response started, not the whole transfer
        [Parameter(Mandatory = $true)][int]$TimeoutMinutes,

        # Copy buffer; memory use stays at this size whatever the file size
        [Parameter(Mandatory = $true)][ValidateRange(4096, 104857600)][int]$BufferBytes
    )

    $client   = $null
    $response = $null
    $source   = $null
    $target   = $null
    $complete = $false

    try {
        $client = New-HttpClient -TimeoutMinutes $TimeoutMinutes

        # ResponseHeadersRead: return as soon as headers arrive, so the
        # body is read as a stream instead of being buffered
        $response = $client.GetAsync(
            $Url, [System.Net.Http.HttpCompletionOption]::ResponseHeadersRead).GetAwaiter().GetResult()

        if (-not $response.IsSuccessStatusCode) {
            throw "Download failed: HTTP $([int]$response.StatusCode) $($response.ReasonPhrase)"
        }

        $source = $response.Content.ReadAsStreamAsync().GetAwaiter().GetResult()

        $target = New-Object System.IO.FileStream(
            $OutFile, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write,
            [System.IO.FileShare]::None, $BufferBytes)

        $source.CopyTo($target, $BufferBytes)
        $target.Flush()

        $written  = $target.Length
        $expected = $response.Content.Headers.ContentLength

        if ($null -ne $expected -and $written -ne $expected) {
            throw "Download incomplete: $written of $expected bytes"
        }

        $complete = $true

        return $written
    }
    finally {
        # Nested so every object is released even if one Dispose fails
        try {
            if ($target) { $target.Dispose() }
        }
        finally {
            try {
                if ($source) { $source.Dispose() }
            }
            finally {
                try {
                    if ($response) { $response.Dispose() }
                }
                finally {
                    if ($client) { $client.Dispose() }

                    # Only a file this call opened (so wrote to) is deleted; the
                    # stream is closed by now, so the partial file can be removed
                    if (-not $complete -and $target -and (Test-Path -LiteralPath $OutFile)) {
                        Remove-Item -LiteralPath $OutFile -Force -ErrorAction SilentlyContinue
                    }
                }
            }
        }
    }
}

Export-ModuleMember -Function `
    ConvertTo-EncodedPath,
    Test-IsConflictError,
    Test-IsNotFoundError,
    Get-RetryDelay,
    Invoke-WithRetry,
    Enable-Tls12,
    New-HttpClient,
    Save-UrlToFile
