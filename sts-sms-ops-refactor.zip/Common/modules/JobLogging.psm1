#--------------------------------------------------------------------------
# JobLogging.psm1
#   Daily log files: <LogFolder>\<date>.log, one file per job per day,
#   shared by all steps. Each line is tagged with the step name, e.g.
#   2026-10-07 18:37:38 [INFO] [EXTRACT] Upload started
#
#   Formats can be passed to Initialize-Log (from config). When they are
#   not, the defaults below apply, so existing steps keep working.
#   Exit-Job ends a step: runs its cleanup, logs the exit code by name
#   (ExitCodes.psm1) and exits.
#--------------------------------------------------------------------------

# Module functions do not inherit the calling script's preference:
# make every cmdlet error terminating so the callers' catch blocks see it.
$ErrorActionPreference = "Stop"

# Defaults (used when Initialize-Log is called without formats)
$script:DefaultFileNameFormat  = "yyyyMMdd"
$script:DefaultTimestampFormat = "yyyy-MM-dd HH:mm:ss"
$script:DefaultSeparator       = "=" * 52
$script:LogExtension           = ".log"

$script:LogFile         = $null
$script:LogWriteWarned  = $false
$script:Step            = $null
$script:TimestampFormat = $script:DefaultTimestampFormat
$script:Separator       = $script:DefaultSeparator

# Creates the log folder if needed and sets today's log file.
# Returns the full path of the log file.
function Initialize-Log {

    param(
        [Parameter(Mandatory = $true)]
        [string]$LogFolder,

        # EXTRACT, CONVERT, PUBLISH ...
        [string]$Step,

        # Date format of the file name (one file per day by default)
        [string]$FileNameFormat = $script:DefaultFileNameFormat,

        # Date format at the start of each line
        [string]$TimestampFormat = $script:DefaultTimestampFormat,

        # Line written by Write-LogSeparator
        [string]$Separator = $script:DefaultSeparator
    )

    if (-not (Test-Path -LiteralPath $LogFolder -PathType Container)) {
        New-Item -ItemType Directory -Path $LogFolder -Force | Out-Null
    }

    $script:LogFile         = Join-Path $LogFolder ((Get-Date -Format $FileNameFormat) + $script:LogExtension)
    $script:LogWriteWarned  = $false
    $script:Step            = $Step
    $script:TimestampFormat = $TimestampFormat
    $script:Separator       = $Separator

    return $script:LogFile
}

function Write-Log {

    param(
        [Parameter(Position = 0)]
        [string]$Message,

        [Parameter(Position = 1)]
        [ValidateSet("INFO", "WARN", "ERROR")]
        [string]$Level = "INFO"
    )

    $time = Get-Date -Format $script:TimestampFormat

    if ($script:Step) {
        $line = "{0} [{1}] [{2}] {3}" -f $time, $Level, $script:Step, $Message
    }
    else {
        $line = "{0} [{1}] {2}" -f $time, $Level, $Message
    }

    Write-Host $line

    if ($script:LogFile) {
        try {
            Add-Content -LiteralPath $script:LogFile -Value $line -Encoding UTF8
        }
        catch {
            # Logging must never stop the job (the line is still on screen),
            # but say once that the file is not being written
            if (-not $script:LogWriteWarned) {
                $script:LogWriteWarned = $true
                Write-Warning "Could not write to log file $($script:LogFile): $($_.Exception.Message)"
            }
        }
    }
}

function Write-LogSeparator {

    Write-Log $script:Separator
}

function Write-LogException {

    param(
        [Parameter(Position = 0)]
        $Exception
    )

    Write-Log $Exception.Message "ERROR"

    if ($Exception.InnerException) {
        Write-Log $Exception.InnerException.Message "ERROR"
    }
}

# Runs $Cleanup (errors there are logged, never hide the exit code),
# logs the exit code with its name and exits the calling script.
function Exit-Job {

    param(
        [Parameter(Mandatory = $true)]
        [int]$Code,

        [scriptblock]$Cleanup
    )

    if ($Cleanup) {
        try {
            & $Cleanup
        }
        catch {
            Write-Log "Cleanup failed: $($_.Exception.Message)" "WARN"
        }
    }

    $name = "?"

    if (Get-Command Get-ExitCodeName -ErrorAction SilentlyContinue) {
        $name = Get-ExitCodeName $Code
    }

    Write-Log "Finished with exit code $Code ($name)"

    exit $Code
}

Export-ModuleMember -Function `
    Initialize-Log,
    Write-Log,
    Write-LogSeparator,
    Write-LogException,
    Exit-Job
