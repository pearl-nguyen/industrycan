#--------------------------------------------------------------------------
# GraphConnection.psm1
#   App-only sign-in to Microsoft Graph with the Entra app certificate,
#   and sending mail through Graph. Shared by the SharePoint upload and
#   the job report email.
#   Requires AppCertificate.psm1 to be imported by the calling script.
#
#   The certificate used to sign in is kept here for the session and
#   released by Disconnect-AppGraph; callers only get a summary of it.
#--------------------------------------------------------------------------

# Module functions do not inherit the calling script's preference:
# make every cmdlet error terminating so the callers' catch blocks see it.
$ErrorActionPreference = "Stop"

$script:SignInCertificate = $null

# Graph request formats (protocol, not settings)
$script:JsonContentType = "application/json; charset=utf-8"
$script:JsonDepth       = 6

function Connect-AppGraph {

    param(
        [Parameter(Mandatory = $true)][string]$TenantId,
        [Parameter(Mandatory = $true)][string]$ClientId,
        [Parameter(Mandatory = $true)]
        [System.Security.Cryptography.X509Certificates.X509Certificate2]$Certificate
    )

    Import-Module Microsoft.Graph.Authentication -ErrorAction Stop

    Connect-MgGraph `
        -TenantId $TenantId `
        -ClientId $ClientId `
        -Certificate $Certificate `
        -NoWelcome `
        -ErrorAction Stop
}

# Finds the newest app certificate (by subject, from SecurityConfig) and
# signs in with it. Returns Subject, Thumbprint, NotBefore, NotAfter.
function Connect-AppGraphFromConfig {

    param(
        [Parameter(Mandatory = $true)]
        [System.Collections.IDictionary]$SecurityConfig
    )

    $c = $SecurityConfig.Certificate

    $cert = Get-AppCertificate `
        -Subject $c.Subject `
        -StoreLocation $c.StoreLocation `
        -StoreName $c.StoreName

    if (-not $cert) {
        throw "No certificate '$($c.Subject)' with a private key in $($c.StoreLocation)\$($c.StoreName)."
    }

    try {
        if ($cert.NotAfter -le (Get-Date)) {
            throw "Certificate '$($c.Subject)' ($($cert.Thumbprint)) expired on $($cert.NotAfter)."
        }

        Connect-AppGraph `
            -TenantId $SecurityConfig.EntraApp.TenantId `
            -ClientId $SecurityConfig.EntraApp.ClientId `
            -Certificate $cert
    }
    catch {
        Close-AppCertificate $cert
        throw
    }

    # Release any certificate from an earlier sign-in in this session
    Close-AppCertificate $script:SignInCertificate
    $script:SignInCertificate = $cert

    return Get-CertificateSummary $cert
}

# Signs out and releases the sign-in certificate. Safe to call twice or
# when never connected.
function Disconnect-AppGraph {

    try {
        # Only sign out when the Graph module is loaded and a session exists
        if ((Get-Command Get-MgContext -ErrorAction SilentlyContinue) -and (Get-MgContext)) {
            Disconnect-MgGraph -ErrorAction SilentlyContinue | Out-Null
        }
    }
    finally {
        Close-AppCertificate $script:SignInCertificate
        $script:SignInCertificate = $null
    }
}

# Sends an HTML email as $From (the app needs the Mail.Send permission)
function Send-GraphMail {

    param(
        [Parameter(Mandatory = $true)][string]$GraphBaseUrl,
        [Parameter(Mandatory = $true)][string]$From,
        [Parameter(Mandatory = $true)][string[]]$To,
        [Parameter(Mandatory = $true)][string]$Subject,
        [Parameter(Mandatory = $true)][string]$HtmlBody,
        [bool]$SaveToSentItems = $false
    )

    $payload = @{
        message = @{
            subject      = $Subject
            body         = @{ contentType = "HTML"; content = $HtmlBody }
            toRecipients = @($To | ForEach-Object { @{ emailAddress = @{ address = $_ } } })
        }
        saveToSentItems = $SaveToSentItems
    } | ConvertTo-Json -Depth $script:JsonDepth

    $uri = "{0}/users/{1}/sendMail" -f $GraphBaseUrl.TrimEnd('/'), [uri]::EscapeDataString($From)

    Invoke-MgGraphRequest `
        -Method POST `
        -Uri $uri `
        -Body $payload `
        -ContentType $script:JsonContentType | Out-Null
}

Export-ModuleMember -Function `
    Connect-AppGraph,
    Connect-AppGraphFromConfig,
    Disconnect-AppGraph,
    Send-GraphMail
