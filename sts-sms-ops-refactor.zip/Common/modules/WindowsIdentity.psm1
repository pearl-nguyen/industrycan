#--------------------------------------------------------------------------
# WindowsIdentity.psm1
#   Elevation check and conversion of Entra users (UPN / Object ID) to
#   Windows SIDs, for setting ACLs on an Entra-joined device.
#--------------------------------------------------------------------------

# Module functions do not inherit the calling script's preference:
# make every cmdlet error terminating so the callers' catch blocks see it.
$ErrorActionPreference = "Stop"

function Assert-Elevated {

    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()

    try {
        $principal = New-Object Security.Principal.WindowsPrincipal($identity)

        if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
            throw "Run this from an elevated PowerShell (Run with elevated access)."
        }
    }
    finally {
        $identity.Dispose()
    }
}

# Entra Object ID (GUID) -> the S-1-12-1-... SID Windows uses for that user
function ConvertTo-EntraSid {

    param(
        [Parameter(Mandatory = $true)]
        [string]$ObjectId
    )

    $b = ([guid]$ObjectId).ToByteArray()

    return "S-1-12-1-{0}-{1}-{2}-{3}" -f
        [BitConverter]::ToUInt32($b, 0), [BitConverter]::ToUInt32($b, 4),
        [BitConverter]::ToUInt32($b, 8), [BitConverter]::ToUInt32($b, 12)
}

# UPN -> SID. Works only for users who have signed in on this device.
function Resolve-UpnToSid {

    param(
        [Parameter(Mandatory = $true)]
        [string]$Upn,

        # "AzureAD" on Entra-joined devices
        [Parameter(Mandatory = $true)]
        [string]$Authority
    )

    try {
        return ([Security.Principal.NTAccount]"$Authority\$Upn").Translate(
            [Security.Principal.SecurityIdentifier]).Value
    }
    catch {
        throw "Cannot resolve '$Upn'. Use their Entra Object ID, or (to remove) the SID shown by -ListOnly."
    }
}

# Combines SIDs, Object IDs and UPNs into one unique list of SIDs
function Resolve-SidList {

    param(
        [string[]]$Sids      = @(),
        [string[]]$ObjectIds = @(),
        [string[]]$Upns      = @(),

        [Parameter(Mandatory = $true)]
        [string]$UpnAuthority
    )

    $out = @()
    $out += $Sids
    $out += $ObjectIds | ForEach-Object { ConvertTo-EntraSid -ObjectId $_ }
    $out += $Upns      | ForEach-Object { Resolve-UpnToSid -Upn $_ -Authority $UpnAuthority }

    return @($out | Where-Object { $_ } | Select-Object -Unique)
}

# (Add + Inherit) minus Exclude, unique, empty entries dropped
function Merge-SidList {

    param(
        [string[]]$Add     = @(),
        [string[]]$Inherit = @(),
        [string[]]$Exclude = @()
    )

    return @(@($Add) + @($Inherit) |
        Where-Object { $_ -and ($Exclude -notcontains $_) } |
        Select-Object -Unique)
}

Export-ModuleMember -Function `
    Assert-Elevated,
    ConvertTo-EntraSid,
    Resolve-UpnToSid,
    Resolve-SidList,
    Merge-SidList
