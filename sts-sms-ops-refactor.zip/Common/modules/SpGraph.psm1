#--------------------------------------------------------------------------
# SpGraph.psm1
#   Microsoft Graph / SharePoint helpers: site, paths, folders,
#   upload (simple + chunked), download, move, delete, hash.
#   Sign-in is in GraphConnection.psm1.
#   Requires JobLogging.psm1 and HttpHelpers.psm1 to be imported by the
#   calling script (path encoding, error matching and streamed downloads
#   come from HttpHelpers).
#
#   Call Initialize-SpGraph once (values from the config files) before
#   using any other function.
#--------------------------------------------------------------------------

# Module functions do not inherit the calling script's preference:
# make every cmdlet error terminating so the callers' catch blocks see it.
$ErrorActionPreference = "Stop"

Add-Type -AssemblyName System.Net.Http

# Graph limits (documented by Microsoft, not settings)
$script:GraphChunkMultiple    = 320KB     # chunk size must be a multiple of this
$script:GraphMaxChunkBytes    = 60MB      # each request must be under this
$script:GraphMaxSimpleUpload  = 250MB     # PUT /content limit

# Graph request formats and the item fields each call asks for
$script:JsonContentType   = "application/json"
$script:BinaryContentType = "application/octet-stream"
$script:ItemPathFields    = "id,name,size,webUrl,folder,file,parentReference"
$script:ItemFields        = "id,name,size,webUrl,parentReference"
$script:HashFields        = "id,size,file"
$script:VersionFields     = "id,size,file,eTag"

# Pre-authenticated download link of an item (never written to logs)
$script:DownloadUrlField  = "@microsoft.graph.downloadUrl"

# What Graph does when a name already exists (query string / body key)
$script:ConflictBehaviorField = "@microsoft.graph.conflictBehavior"

# Nesting depth for JSON request bodies
$script:JsonDepth = 5

# Upload session: 200/201 = last chunk accepted (body is the item),
# 202 = chunk accepted, more expected, 404 = session gone
$script:StatusLastChunk     = @(200, 201)
$script:StatusSessionGone   = 404

# Set by Initialize-SpGraph
$script:GraphBase           = $null
$script:SimpleUploadLimit   = $null
$script:ChunkSize           = $null
$script:ChunkRetries        = $null
$script:ChunkTimeoutMinutes = $null
$script:RetryBaseDelay      = $null
$script:RetryMaxJitter      = $null
$script:ProgressLogPercent  = $null
$script:DownloadTimeoutMinutes = $null
$script:DownloadBufferSize     = $null

#--------------------------------------------------------------------------
# INITIALIZATION
#--------------------------------------------------------------------------

function Initialize-SpGraph {

    param(
        [Parameter(Mandatory = $true)][string]$GraphBaseUrl,
        [Parameter(Mandatory = $true)][long]$SimpleUploadLimitBytes,
        [Parameter(Mandatory = $true)][int]$ChunkSizeBytes,
        [Parameter(Mandatory = $true)][ValidateRange(0, 100)][int]$ChunkRetries,
        [Parameter(Mandatory = $true)][ValidateRange(1, 1440)][int]$ChunkTimeoutMinutes,
        [Parameter(Mandatory = $true)][ValidateRange(0, 3600)][int]$RetryBaseDelay,
        [Parameter(Mandatory = $true)][ValidateRange(0, 3600)][int]$RetryMaxJitter,

        # Chunked uploads log progress every this many percent
        [Parameter(Mandatory = $true)][ValidateRange(1, 100)][int]$ProgressLogPercent,

        # Downloads stream to disk through this buffer, so file size is
        # not limited by memory. The timeout covers getting the response
        # started, not the whole transfer.
        [Parameter(Mandatory = $true)][ValidateRange(1, 1440)][int]$DownloadTimeoutMinutes,
        [Parameter(Mandatory = $true)][ValidateRange(4096, 104857600)][int]$DownloadBufferBytes
    )

    if ($SimpleUploadLimitBytes -le 0 -or $SimpleUploadLimitBytes -gt $script:GraphMaxSimpleUpload) {
        throw "Simple upload limit must be between 1 byte and $($script:GraphMaxSimpleUpload / 1MB) MB"
    }

    if ($ChunkSizeBytes -le 0 -or ($ChunkSizeBytes % $script:GraphChunkMultiple) -ne 0) {
        throw "Chunk size ($($ChunkSizeBytes / 1KB) KB) must be a multiple of $($script:GraphChunkMultiple / 1KB) KB"
    }

    if ($ChunkSizeBytes -ge $script:GraphMaxChunkBytes) {
        throw "Chunk size ($($ChunkSizeBytes / 1KB) KB) must be under $($script:GraphMaxChunkBytes / 1MB) MB"
    }

    $script:GraphBase           = $GraphBaseUrl.TrimEnd('/')
    $script:SimpleUploadLimit   = $SimpleUploadLimitBytes
    $script:ChunkSize           = $ChunkSizeBytes
    $script:ChunkRetries        = $ChunkRetries
    $script:ChunkTimeoutMinutes = $ChunkTimeoutMinutes
    $script:RetryBaseDelay      = $RetryBaseDelay
    $script:RetryMaxJitter      = $RetryMaxJitter
    $script:ProgressLogPercent  = $ProgressLogPercent
    $script:DownloadTimeoutMinutes = $DownloadTimeoutMinutes
    $script:DownloadBufferSize     = $DownloadBufferBytes
}

function Get-SpBase {

    if (-not $script:GraphBase) {
        throw "SpGraph is not initialized (call Initialize-SpGraph first)"
    }

    return $script:GraphBase
}

#--------------------------------------------------------------------------
# SITE
#--------------------------------------------------------------------------

# Returns the site's default document library. Works regardless of
# language ("Documents", "Documents partagés", ...)
function Get-SpDrive {

    param(
        [Parameter(Mandatory = $true)][string]$SharePointHost,
        [Parameter(Mandatory = $true)][string]$SiteName
    )

    $sitePath = ConvertTo-EncodedPath @($SiteName)

    $site = Invoke-MgGraphRequest `
        -Method GET `
        -Uri "$(Get-SpBase)/sites/${SharePointHost}:/sites/$sitePath"

    if (-not $site -or -not $site.id) {
        throw "Site not found: $SharePointHost/sites/$SiteName"
    }

    $drive = Invoke-MgGraphRequest `
        -Method GET `
        -Uri "$(Get-SpBase)/sites/$($site.id)/drive"

    if (-not $drive -or -not $drive.id) {
        throw "Default document library not found"
    }

    return [pscustomobject]@{
        SiteUrl = $site.webUrl
        Id      = $drive.id
        Name    = $drive.name
    }
}

#--------------------------------------------------------------------------
# ITEMS / FOLDERS
#--------------------------------------------------------------------------

# Returns the item at the given (unencoded) path, or $null if it does not exist
function Get-SpItemByPath {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [string[]]$PathParts = @(),
        [string]$Select = $script:ItemPathFields
    )

    return Get-SpItemByEncodedPath `
        -DriveId $DriveId `
        -EncodedPath (ConvertTo-EncodedPath $PathParts) `
        -Select $Select
}

# Same, for a path that is already URL-encoded ("" = drive root)
function Get-SpItemByEncodedPath {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [AllowEmptyString()][string]$EncodedPath = "",
        [string]$Select = $script:ItemPathFields
    )

    $encoded = $EncodedPath

    if ($encoded) {
        $uri = "$(Get-SpBase)/drives/$DriveId/root:/$encoded"
    }
    else {
        $uri = "$(Get-SpBase)/drives/$DriveId/root"
    }

    $uri += "?`$select=$Select"

    try {
        return Invoke-MgGraphRequest -Method GET -Uri $uri
    }
    catch {
        if (Test-IsNotFoundError $_.Exception.Message) {
            return $null
        }
        throw
    }
}

function Get-SpItem {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [Parameter(Mandatory = $true)][string]$ItemId,
        [string]$Select = $script:ItemFields
    )

    return Invoke-MgGraphRequest `
        -Method GET `
        -Uri "$(Get-SpBase)/drives/$DriveId/items/${ItemId}?`$select=$Select"
}

function New-SpFolder {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [string[]]$ParentParts = @(),
        [Parameter(Mandatory = $true)][string]$Name
    )

    $parent = ConvertTo-EncodedPath $ParentParts

    if ($parent) {
        $uri = "$(Get-SpBase)/drives/$DriveId/root:/${parent}:/children"
    }
    else {
        $uri = "$(Get-SpBase)/drives/$DriveId/root/children"
    }

    $body = @{
        name   = $Name
        folder = @{}
        $script:ConflictBehaviorField = "fail"
    } | ConvertTo-Json -Depth $script:JsonDepth

    try {
        $item = Invoke-MgGraphRequest `
            -Method POST `
            -Uri $uri `
            -Body $body `
            -ContentType $script:JsonContentType

        Write-Log "Folder created: $Name"

        return $item
    }
    catch {
        # Another job created it at the same time
        if (Test-IsConflictError $_.Exception.Message) {
            return Get-SpItemByPath -DriveId $DriveId -PathParts (@($ParentParts) + $Name)
        }
        throw
    }
}

# Returns the folder item for a path like "A/B/C", or $null if missing.
# With -CreateIfMissing, missing levels are created.
function Get-SpFolder {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [Parameter(Mandatory = $true)][string]$Path,
        [switch]$CreateIfMissing
    )

    $segments = @($Path -split '[\\/]' | Where-Object { $_ -ne '' })

    if ($segments.Count -eq 0) {
        throw "Folder path is empty"
    }

    $current = @()
    $item    = $null

    foreach ($seg in $segments) {

        $parentParts = $current
        $current    += $seg

        $item = Get-SpItemByPath -DriveId $DriveId -PathParts $current

        if (-not $item) {

            if (-not $CreateIfMissing) {
                return $null
            }

            $item = New-SpFolder -DriveId $DriveId -ParentParts $parentParts -Name $seg
        }

        if (-not $item.folder) {
            throw "'$($current -join '/')' exists but is not a folder"
        }
    }

    return $item
}

# Moves (and optionally renames) an item. ConflictBehavior applies when
# an item with the same name already exists in the destination.
function Move-SpItem {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [Parameter(Mandatory = $true)][string]$ItemId,
        [Parameter(Mandatory = $true)][string]$DestinationFolderId,
        [Parameter(Mandatory = $true)][string]$NewName,
        [ValidateSet("fail", "replace")]
        [string]$ConflictBehavior = "fail"
    )

    $body = @{
        parentReference = @{ id = $DestinationFolderId }
        name            = $NewName
    } | ConvertTo-Json -Depth $script:JsonDepth

    return Invoke-MgGraphRequest `
        -Method PATCH `
        -Uri "$(Get-SpBase)/drives/$DriveId/items/${ItemId}?$($script:ConflictBehaviorField)=$ConflictBehavior" `
        -Body $body `
        -ContentType $script:JsonContentType
}

function Remove-SpItem {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [Parameter(Mandatory = $true)][string]$ItemId
    )

    Invoke-MgGraphRequest `
        -Method DELETE `
        -Uri "$(Get-SpBase)/drives/$DriveId/items/$ItemId" | Out-Null
}

function Save-SpItemContent {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [Parameter(Mandatory = $true)][string]$ItemId,
        [Parameter(Mandatory = $true)][string]$OutFile
    )

    # Graph returns a short-lived pre-authenticated URL for the content.
    # Streaming from it avoids Invoke-MgGraphRequest, which buffers the
    # whole response in memory (and fails above 2 GB).
    $meta = Invoke-MgGraphRequest `
        -Method GET `
        -Uri "$(Get-SpBase)/drives/$DriveId/items/${ItemId}?`$select=id,$($script:DownloadUrlField)"

    $url = $meta[$script:DownloadUrlField]

    if (-not $url) {
        throw "SharePoint did not return a download URL for item $ItemId"
    }

    return Save-UrlToFile `
        -Url $url `
        -OutFile $OutFile `
        -TimeoutMinutes $script:DownloadTimeoutMinutes `
        -BufferBytes $script:DownloadBufferSize
}

#--------------------------------------------------------------------------
# UPLOAD
#--------------------------------------------------------------------------

# Uploads a file to an encoded item path, choosing simple or chunked upload
function Send-SpFile {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [Parameter(Mandatory = $true)][string]$ItemPath,
        [Parameter(Mandatory = $true)][string]$Path,
        [ValidateSet("fail", "replace")]
        [string]$ConflictBehavior = "replace"
    )

    $size = (Get-Item -LiteralPath $Path).Length

    if ($size -gt $script:SimpleUploadLimit) {

        Write-Log "Method     : Upload session (chunked)"

        return Send-SpLargeUpload `
            -DriveId $DriveId -ItemPath $ItemPath -Path $Path `
            -ConflictBehavior $ConflictBehavior
    }

    Write-Log "Method     : Simple upload"

    return Send-SpSimpleUpload `
        -DriveId $DriveId -ItemPath $ItemPath -Path $Path `
        -ConflictBehavior $ConflictBehavior
}

# Simple upload for files up to the configured limit
function Send-SpSimpleUpload {

    param(
        [string]$DriveId,
        [string]$ItemPath,
        [string]$Path,
        [string]$ConflictBehavior
    )

    $uri = "$(Get-SpBase)/drives/$DriveId/root:/${ItemPath}:/content" +
           "?$($script:ConflictBehaviorField)=$ConflictBehavior"

    return Invoke-MgGraphRequest `
        -Method PUT `
        -Uri $uri `
        -InputFilePath $Path `
        -ContentType $script:BinaryContentType
}

# Chunked upload for files over the configured limit
function Send-SpLargeUpload {

    param(
        [string]$DriveId,
        [string]$ItemPath,
        [string]$Path,
        [string]$ConflictBehavior
    )

    # Version of whatever is at this path now (an earlier attempt's copy),
    # so a completed upload can be told apart from it later
    $before = Get-SpItemByEncodedPath -DriveId $DriveId -EncodedPath $ItemPath -Select $script:VersionFields

    $body = @{
        item = @{
            $script:ConflictBehaviorField = $ConflictBehavior
        }
    } | ConvertTo-Json -Depth $script:JsonDepth

    $session = Invoke-MgGraphRequest `
        -Method POST `
        -Uri "$(Get-SpBase)/drives/$DriveId/root:/${ItemPath}:/createUploadSession" `
        -Body $body `
        -ContentType $script:JsonContentType

    if (-not $session -or -not $session.uploadUrl) {
        throw "SharePoint did not return an upload session URL"
    }

    Write-Log "Upload session created"

    try {
        return Send-SpUploadChunks -UploadUrl $session.uploadUrl -Path $Path
    }
    catch {
        # If the connection dropped just after the LAST chunk was accepted,
        # SharePoint has finished the file but the success response was
        # lost (the session then answers 404). A NEW version (eTag differs
        # from before this upload) of the full size at our unique staging
        # path means this upload completed; the caller's hash validation
        # still confirms the content.
        $uploadError = $_
        $size        = (Get-Item -LiteralPath $Path).Length
        $existing    = $null

        try {
            $existing = Get-SpItemByEncodedPath -DriveId $DriveId -EncodedPath $ItemPath -Select $script:VersionFields
        }
        catch {
            # Lookup failed too: report the original upload error below
            Write-Log "Could not check for a completed upload: $($_.Exception.Message)" "WARN"
        }

        $isNewVersion = $existing -and (-not $before -or $existing.eTag -ne $before.eTag)

        if ($isNewVersion -and $existing.file -and $existing.size -eq $size) {
            Write-Log "Upload had completed on SharePoint (final response was lost); continuing" "WARN"
            return $existing
        }

        throw $uploadError
    }
}

# Cancels an upload session so SharePoint discards the partial upload
function Stop-SpUploadSession {

    param(
        $Client,
        [string]$UploadUrl
    )

    $response = $null

    try {
        $response = $Client.DeleteAsync($UploadUrl).GetAwaiter().GetResult()
        Write-Log "Upload session cancelled" "WARN"
    }
    catch {
        Write-Log "Could not cancel upload session (it expires on its own)" "WARN"
    }
    finally {
        if ($response) { $response.Dispose() }
    }
}

# Asks the upload session where to continue. Returns the next byte offset
# SharePoint expects, or $null if the session cannot be queried.
function Get-SpUploadSessionOffset {

    param(
        $Client,
        [string]$UploadUrl
    )

    $response = $null

    try {
        $response = $Client.GetAsync($UploadUrl).GetAwaiter().GetResult()

        if (-not $response.IsSuccessStatusCode) {
            return $null
        }

        $json  = $response.Content.ReadAsStringAsync().GetAwaiter().GetResult() | ConvertFrom-Json
        $range = @($json.nextExpectedRanges) | Select-Object -First 1

        if (-not $range) {
            return $null
        }

        # "26214400-" or "26214400-52428799"
        return [long](([string]$range -split '-')[0])
    }
    catch {
        return $null
    }
    finally {
        if ($response) { $response.Dispose() }
    }
}

# Sends the file in chunks to an upload session URL.
# The upload URL is pre-authenticated, so no Graph token is sent with it.
# A failed chunk is retried and the upload resumes from the byte SharePoint
# expects next, instead of restarting the whole file.
function Send-SpUploadChunks {

    param(
        [string]$UploadUrl,
        [string]$Path
    )

    $client = $null
    $fs     = $null
    $item   = $null

    try {

        $client = New-HttpClient -TimeoutMinutes $script:ChunkTimeoutMinutes

        $fs = [System.IO.File]::OpenRead($Path)

        [long]$total   = $fs.Length
        [long]$offset  = 0
        [long]$nextLog = 0
        $failures = 0
        $buffer   = New-Object byte[] $script:ChunkSize

        try {

            while ($offset -lt $total) {

                # Read the chunk at the current offset (a resume may move it)
                $count = [int][math]::Min([long]$script:ChunkSize, $total - $offset)
                $fs.Position = $offset

                $read = 0
                while ($read -lt $count) {
                    $n = $fs.Read($buffer, $read, $count - $read)
                    if ($n -le 0) {
                        throw "Unexpected end of file at byte $($offset + $read)"
                    }
                    $read += $n
                }

                $content   = $null
                $response  = $null
                $status    = 0
                $text      = ""
                $sendError = $null

                try {
                    try {
                        $content = New-Object System.Net.Http.ByteArrayContent($buffer, 0, $read)

                        $content.Headers.ContentRange =
                            New-Object System.Net.Http.Headers.ContentRangeHeaderValue(
                                $offset, ($offset + $read - 1), $total)

                        $response = $client.PutAsync($UploadUrl, $content).GetAwaiter().GetResult()
                        $status   = [int]$response.StatusCode
                        $text     = $response.Content.ReadAsStringAsync().GetAwaiter().GetResult()
                    }
                    catch {
                        # Network error or timeout: retried below
                        $sendError = $_.Exception.Message
                    }
                }
                finally {
                    try {
                        if ($content) { $content.Dispose() }
                    }
                    finally {
                        if ($response) { $response.Dispose() }
                    }
                }

                if (-not $sendError -and $status -ge 200 -and $status -lt 300) {

                    $offset  += $read
                    $failures = 0

                    # Last chunk accepted: the response body is the driveItem
                    if ($script:StatusLastChunk -contains $status) {
                        $item = $text | ConvertFrom-Json
                    }

                    if ($offset -ge $nextLog -or $offset -ge $total) {
                        Write-Log ("Uploaded {0:N0} / {1:N0} bytes ({2:N0}%)" -f `
                            $offset, $total, (100.0 * $offset / [math]::Max(1, $total)))
                        $nextLog = $offset + [math]::Max([long]$script:ChunkSize, [long]($total * $script:ProgressLogPercent / 100))
                    }

                    continue
                }

                if ($sendError) {
                    $reason = $sendError
                }
                else {
                    $reason = "HTTP $status $text"
                }

                # 404: the session expired or was lost; the caller restarts
                if ($status -eq $script:StatusSessionGone) {
                    throw "Upload session no longer exists: $reason"
                }

                $failures++

                if ($failures -gt $script:ChunkRetries) {
                    throw "Chunk at byte $offset failed $failures times: $reason"
                }

                $delay = Get-RetryDelay `
                    -Attempt $failures `
                    -BaseDelay $script:RetryBaseDelay `
                    -MaxJitterSeconds $script:RetryMaxJitter

                Write-Log "Chunk at byte $offset failed ($reason); retry $failures of $($script:ChunkRetries) in $delay seconds" "WARN"

                Start-Sleep -Seconds $delay

                $resumeAt = Get-SpUploadSessionOffset -Client $client -UploadUrl $UploadUrl

                if ($null -ne $resumeAt -and $resumeAt -ne $offset) {
                    Write-Log "Resuming at byte $resumeAt (SharePoint already has the data before it)"
                    $offset = $resumeAt
                }
            }
        }
        catch {
            # Gave up: cancel the session so no partial upload is left behind
            Stop-SpUploadSession -Client $client -UploadUrl $UploadUrl
            throw
        }
    }
    finally {
        try {
            if ($fs) { $fs.Dispose() }
        }
        finally {
            if ($client) { $client.Dispose() }
        }
    }

    if (-not $item) {
        throw "Upload session ended without returning the uploaded item"
    }

    return $item
}

#--------------------------------------------------------------------------
# HASH
#--------------------------------------------------------------------------

# Waits until SharePoint has computed the item's QuickXorHash (usually
# immediate, sometimes a little later for large files). Returns the base64
# hash, or $null if it is still not available after $TimeoutSeconds.
function Wait-SpQuickXorHash {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [Parameter(Mandatory = $true)][string]$ItemId,
        [Parameter(Mandatory = $true)][int]$TimeoutSeconds,
        [Parameter(Mandatory = $true)][int]$PollSeconds
    )

    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)

    while ($true) {

        $item = Get-SpItem -DriveId $DriveId -ItemId $ItemId -Select $script:HashFields

        $hash = $null
        if ($item.file -and $item.file.hashes) {
            $hash = $item.file.hashes.quickXorHash
        }

        if ($hash) {
            return [string]$hash
        }

        if ((Get-Date) -gt $deadline) {
            return $null
        }

        Write-Log "SharePoint hash not available yet; checking again in $PollSeconds seconds"
        Start-Sleep -Seconds $PollSeconds
    }
}

Export-ModuleMember -Function `
    Initialize-SpGraph,
    Get-SpDrive,
    Get-SpItemByPath,
    Get-SpItem,
    New-SpFolder,
    Get-SpFolder,
    Move-SpItem,
    Remove-SpItem,
    Save-SpItemContent,
    Send-SpFile,
    Wait-SpQuickXorHash
