#--------------------------------------------------------------------------
# ConfigHelpers.psm1
#   Loading .psd1 config files, checking required settings (nested keys
#   with dots, e.g. "EntraApp.TenantId") and resolving paths written
#   relative to the config file.
#--------------------------------------------------------------------------

# Module functions do not inherit the calling script's preference:
# make every cmdlet error terminating so the callers' catch blocks see it.
$ErrorActionPreference = "Stop"

# Returns the value at a dotted key ("Section.Name"), or $null if missing
function Get-ConfigValue {

    param(
        [Parameter(Mandatory = $true)]
        [System.Collections.IDictionary]$Config,

        [Parameter(Mandatory = $true)]
        [string]$Key
    )

    $node = $Config

    foreach ($part in ($Key -split '\.')) {

        if ($node -isnot [System.Collections.IDictionary] -or -not $node.Contains($part)) {
            return $null
        }

        $node = $node[$part]
    }

    return $node
}

# Loads a .psd1 and throws one message listing every required key that is
# missing or empty
function Import-ConfigFile {

    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,

        [string[]]$Required = @()
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "Config file not found: $Path"
    }

    $fullPath = (Resolve-Path -LiteralPath $Path).Path
    $config   = Import-PowerShellDataFile -LiteralPath $fullPath

    $missing = @()

    foreach ($key in $Required) {

        $value = Get-ConfigValue -Config $config -Key $key

        if ($null -eq $value -or
            ($value -is [string] -and [string]::IsNullOrWhiteSpace($value)) -or
            (@($value).Count -eq 0)) {
            $missing += $key
        }
    }

    if ($missing.Count -gt 0) {
        throw "Missing setting(s) in ${fullPath}: $($missing -join ', ')"
    }

    return $config
}

# Folder of a config file, used to resolve the relative paths it contains
function Get-ConfigFolder {

    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    return Split-Path (Resolve-Path -LiteralPath $Path).Path -Parent
}

# Absolute path as-is; relative path resolved against $RelativeTo.
# %VARIABLES% are expanded first.
function Resolve-ConfigPath {

    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,

        [Parameter(Mandatory = $true)]
        [string]$RelativeTo
    )

    $expanded = [Environment]::ExpandEnvironmentVariables($Path)

    if ([System.IO.Path]::IsPathRooted($expanded)) {
        return [System.IO.Path]::GetFullPath($expanded)
    }

    return [System.IO.Path]::GetFullPath((Join-Path $RelativeTo $expanded))
}

Export-ModuleMember -Function `
    Get-ConfigValue,
    Import-ConfigFile,
    Get-ConfigFolder,
    Resolve-ConfigPath
