#--------------------------------------------------------------------------
# SecurityConfig.psd1
#   The Entra app and how it signs in: app registration, certificate,
#   private-key access and the Graph endpoint.
#   Shared by every area that calls Graph:
#     SharePoint\sharepoint_upload.ps1, Notification\Send-JobReport.ps1,
#     Security\Test-CertExpiry.ps1, Security\InstallStsSmsOpsCert.ps1
#
#   Paths below are absolute, or relative to THIS file.
#   %VARIABLES% (e.g. %ProgramData%) are expanded.
#--------------------------------------------------------------------------
@{
    #======================================================================
    # SECRETS (DpapiSecret.psm1)
    #   Kept as top-level keys: DpapiSecret.psm1 reads them by these names.
    #======================================================================

    # Where encrypted secrets are stored
    SecretsFolder = "secrets"

    # Extra DPAPI salt. NEVER change after secrets are saved - they could
    # no longer be decrypted.
    Entropy       = "STS-SMS-Ops-DPAPI-v1"

    #======================================================================
    # ENTRA APP REGISTRATION
    #======================================================================
    EntraApp = @{
        TenantId = "b72ac62f-06d5-4cd5-824e-ee92319a4676"
        ClientId = "452f66fa-4eea-4ba8-885b-ad65f3bd1e2c"
    }

    #======================================================================
    # APP CERTIFICATE
    #   Found by subject, newest first, so a renewed certificate is picked
    #   up automatically - no thumbprint to update anywhere.
    #======================================================================
    Certificate = @{
        Subject            = "CN=STS - SMS Operations"
        StoreLocation      = "LocalMachine"
        StoreName          = "My"

        # "Expiring soon" when this many days or fewer are left
        WarningDays        = 30

        # Secret name holding the PFX password (saved with Save-Secret.ps1)
        PfxSecretName      = "StsSmsOpsCertPfx"

        # Key provider the private key must live in (not the TPM)
        KeyStorageProvider = "Microsoft Software Key Storage Provider"

        # Mark the private key non-exportable when installing a PFX
        NonExportable      = $true

        # How expiry dates are shown in logs and on screen
        DateFormat         = "yyyy-MM-dd"
    }

    #======================================================================
    # PRIVATE KEY ACCESS (InstallStsSmsOpsCert.ps1)
    #======================================================================
    KeyAccess = @{
        # Where CNG machine keys are stored
        KeysFolder        = "%ProgramData%\Microsoft\Crypto\Keys"

        # Never removed from the key: SYSTEM, Administrators
        ProtectedSids     = @("S-1-5-18", "S-1-5-32-544")

        # Readers carried over to a renewed key: Entra users, domain users
        ReaderSidPatterns = @("S-1-12-1-*", "S-1-5-21-*")

        # Account prefix used to resolve a UPN on an Entra-joined device
        UpnAuthority      = "AzureAD"

        # Shown by -ListOnly for a SID with no account on this device
        UnknownAccountText = "(unknown - left or never signed in here)"
    }

    #======================================================================
    # MICROSOFT GRAPH (SharePoint, Notification)
    #======================================================================
    Graph = @{
        BaseUrl = "https://graph.microsoft.com/v1.0"
    }
}
