<#
  InstallStsSmsOpsCert.ps1
  Installs the Entra app certificate from a PFX and manages who can read its private key.
  Run from an elevated PowerShell.

  Modes:
    -ListOnly                  show who can read the key of each installed certificate
    -PfxPath <file>            install a new certificate; readers of the old one are carried over
                               (add -RemoveOld to delete older certificates with the same subject)
    -Reader* / -Remove*        grant / remove read access on the installed certificate(s)

  Defaults come from SecurityConfig.psd1 (Certificate and KeyAccess sections);
  -Subject and -PfxSecretName override them.
  Helpers live in Common\modules (AppCertificate, WindowsIdentity, ConfigHelpers, DpapiSecret).
  Every certificate opened here is released before the script ends.
#>
param(
  [string]  $PfxPath,

  # Defaults: Certificate.Subject / Certificate.PfxSecretName in SecurityConfig.psd1
  [string]  $Subject       = "",
  [string]  $PfxSecretName = "",

  [string[]]$ReaderUpns       = @(),
  [string[]]$ReaderObjectIds  = @(),
  [string[]]$ReaderSids       = @(),

  [string[]]$RemoveUpns       = @(),
  [string[]]$RemoveObjectIds  = @(),
  [string[]]$RemoveSids       = @(),

  [switch]  $RemoveOld,
  [switch]  $ListOnly,
  [string]  $ConfigPath   = (Join-Path $PSScriptRoot "SecurityConfig.psd1"),
  [string]  $ModuleFolder = (Join-Path $PSScriptRoot "..\Common\modules")
)

$ErrorActionPreference = "Stop"

try {
  foreach ($module in "ConfigHelpers", "WindowsIdentity", "AppCertificate", "DpapiSecret") {
    Import-Module (Join-Path $ModuleFolder "$module.psm1") -Force
  }

  $cfg = Import-ConfigFile -Path $ConfigPath -Required @(
    "Certificate.Subject", "Certificate.StoreLocation", "Certificate.StoreName",
    "Certificate.PfxSecretName", "Certificate.KeyStorageProvider", "Certificate.NonExportable",
    "Certificate.DateFormat",
    "KeyAccess.KeysFolder", "KeyAccess.ProtectedSids", "KeyAccess.ReaderSidPatterns",
    "KeyAccess.UpnAuthority", "KeyAccess.UnknownAccountText")
}
catch {
  Write-Host "Setup failed: $($_.Exception.Message)"
  exit 1
}

$certCfg = $cfg.Certificate
$keyCfg  = $cfg.KeyAccess

if (-not $Subject)       { $Subject       = $certCfg.Subject }
if (-not $PfxSecretName) { $PfxSecretName = $certCfg.PfxSecretName }

$keysFolder = Resolve-ConfigPath -Path $keyCfg.KeysFolder -RelativeTo (Get-ConfigFolder $ConfigPath)
$store      = @{ StoreLocation = $certCfg.StoreLocation; StoreName = $certCfg.StoreName }
$access     = @{ KeysFolder = $keysFolder; DateFormat = $certCfg.DateFormat; UnknownAccountText = $keyCfg.UnknownAccountText }

# ======================= start =======================
Assert-Elevated

$addSids    = Resolve-SidList -Sids $ReaderSids -ObjectIds $ReaderObjectIds -Upns $ReaderUpns -UpnAuthority $keyCfg.UpnAuthority
$removeSids = Resolve-SidList -Sids $RemoveSids -ObjectIds $RemoveObjectIds -Upns $RemoveUpns -UpnAuthority $keyCfg.UpnAuthority

$certs    = @()     # every live certificate opened below, released in finally
$securePw = $null

try {

  # ---------- list only ----------
  if ($ListOnly) {
    $certs = @(Get-AppCertificate -Subject $Subject @store -All)
    if (-not $certs) { throw "No certificate with subject '$Subject' and a private key is installed." }
    Show-CertKeyAccess -Certificates $certs @access
    return
  }

  # ---------- install a new certificate from a PFX ----------
  if ($PfxPath) {
    if (-not (Test-Path -LiteralPath $PfxPath)) { throw "PFX not found: $PfxPath" }

    $securePw = Get-DpapiSecret -ConfigPath $ConfigPath -Name $PfxSecretName   # stops with a clear message if not saved yet
    Write-Host "Using PFX password from secret '$PfxSecretName'."

    $pfx = Get-PfxCertificateInfo -PfxPath $PfxPath -Password $securePw
    if (-not $pfx) { throw "No certificate found in the PFX (or wrong password)." }
    if ($pfx.Subject -ne $Subject) {
      throw "PFX subject is '$($pfx.Subject)', expected '$Subject'. Wrong file? Nothing was changed."
    }
    $newThumb = $pfx.Thumbprint
    Write-Host "PFX OK: $Subject  thumbprint $newThumb  valid until $($pfx.NotAfter.ToString($certCfg.DateFormat))" -ForegroundColor Cyan

    if (Test-Path "Cert:\$($certCfg.StoreLocation)\$($certCfg.StoreName)\$newThumb") {
      Write-Host "This certificate is already installed - skipping import." -ForegroundColor Yellow
    }
    else {
      Install-PfxWithProvider -PfxPath $PfxPath -Password $securePw @store `
        -KeyStorageProvider $certCfg.KeyStorageProvider -NonExportable ([bool]$certCfg.NonExportable)
      Write-Host "Imported." -ForegroundColor Green
    }

    $certs    = @(Get-AppCertificate -Subject $Subject @store -All)
    $newCert  = $certs | Where-Object { $_.Thumbprint -eq $newThumb } | Select-Object -First 1
    $oldCerts = @($certs | Where-Object { $_.Thumbprint -ne $newThumb })

    if (-not $newCert) { throw "Imported certificate has no private key." }

    $check = Test-CertKeyProvider -Certificate $newCert -ExpectedProvider $certCfg.KeyStorageProvider
    if (-not $check.Matches) {
      throw "Key is not in '$($certCfg.KeyStorageProvider)' ($($check.Provider)). It may have gone to the TPM."
    }

    # Carry over everyone who can read the old certificate(s), minus anyone being removed
    $inherit = @($oldCerts | ForEach-Object {
                 Get-CertKeyReaderSids -Certificate $_ -KeysFolder $keysFolder -ReaderSidPatterns $keyCfg.ReaderSidPatterns })
    $toGrant = Merge-SidList -Add $addSids -Inherit $inherit -Exclude $removeSids

    if ($toGrant) { Grant-CertKeyRead -Certificates @($newCert) -Sids $toGrant -KeysFolder $keysFolder }
    else { Write-Warning "No readers given or carried over - only administrators can use the new key." }

    if ($removeSids) {
      Revoke-CertKeyRead -Certificates $certs -Sids $removeSids -KeysFolder $keysFolder -ProtectedSids $keyCfg.ProtectedSids
    }

    Show-CertKeyAccess -Certificates @($newCert) @access

    if ($oldCerts) {
      Write-Host "`nOlder certificates with the same subject:" -ForegroundColor Yellow
      $oldCerts | Format-Table Thumbprint, NotAfter -AutoSize | Out-Host
      if ($RemoveOld) {
        $answer = Read-Host "Delete these $($oldCerts.Count) old certificate(s)? Type YES to confirm"
        if ($answer -eq "YES") { Remove-AppCertificate -Certificates $oldCerts @store }
        else { Write-Host "Skipped deletion." }
      }
      else {
        Write-Host "Kept. Re-run with -RemoveOld after the new key is in the Entra app and an upload has worked."
      }
    }

    Write-Host "`nDone. Active (newest) thumbprint: $newThumb" -ForegroundColor Cyan
    return
  }

  # ---------- certificate already installed: add / remove readers ----------
  if (-not $addSids -and -not $removeSids) {
    if ($RemoveOld) { throw "-RemoveOld is only used together with -PfxPath." }
    throw "Nothing to do. Use -ReaderUpns/-ReaderObjectIds/-ReaderSids, -RemoveUpns/-RemoveObjectIds/-RemoveSids, -PfxPath or -ListOnly."
  }

  $certs = @(Get-AppCertificate -Subject $Subject @store -All)
  if (-not $certs) { throw "No certificate with subject '$Subject' and a private key is installed. Use -PfxPath to install one." }

  if ($addSids)    { Grant-CertKeyRead  -Certificates $certs -Sids $addSids -KeysFolder $keysFolder }
  if ($removeSids) { Revoke-CertKeyRead -Certificates $certs -Sids $removeSids -KeysFolder $keysFolder -ProtectedSids $keyCfg.ProtectedSids }
  Show-CertKeyAccess -Certificates $certs @access
  Write-Host "Done." -ForegroundColor Cyan
}
finally {
  Close-AppCertificate $certs
  if ($securePw) { $securePw.Dispose() }
}

exit 0
