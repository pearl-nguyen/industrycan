<#
  Test-CertExpiry.ps1
  Checks the Entra app certificate (Certificate section of SecurityConfig.psd1).
  Thin wrapper over Get-CertExpiryStatus in Common\modules\AppCertificate.psm1.

  Output: object with Code, Status, Subject, Thumbprint, NotAfter, DaysLeft
  Exit code: 0 OK, 1 expiring soon, 2 expired, 3 not found (also 3 if the check cannot run)

  Notification\Send-JobReport.ps1 now does this check itself when -CertStatusCode is omitted,
  so calling this first is only needed if the job uses the result for something else.
#>
param(
  [string]$ConfigPath   = (Join-Path $PSScriptRoot "SecurityConfig.psd1"),
  [string]$ModuleFolder = (Join-Path $PSScriptRoot "..\Common\modules")
)

$ErrorActionPreference = "Stop"

try {
  Import-Module (Join-Path $ModuleFolder "ConfigHelpers.psm1")  -Force
  Import-Module (Join-Path $ModuleFolder "AppCertificate.psm1") -Force

  $cfg = Import-ConfigFile -Path $ConfigPath -Required @(
    "Certificate.Subject", "Certificate.StoreLocation", "Certificate.StoreName", "Certificate.WarningDays",
    "Certificate.DateFormat")
}
catch {
  Write-Host "Certificate check could not run: $($_.Exception.Message)" -ForegroundColor Red
  exit 3
}

$c = $cfg.Certificate

try {
  $result = Get-CertExpiryStatus -Subject $c.Subject -WarningDays $c.WarningDays `
                                 -StoreLocation $c.StoreLocation -StoreName $c.StoreName
}
catch {
  # Never let a crash surface as exit 1 ("expiring soon")
  Write-Host "Certificate check could not run: $($_.Exception.Message)" -ForegroundColor Red
  exit 3
}

if ($result.NotAfter) {
  Write-Host "$($result.Subject): $($result.Status), expires $($result.NotAfter.ToString($c.DateFormat)) ($($result.DaysLeft) days left)"
}
else {
  Write-Host "$($result.Subject): $($result.Status) in $($c.StoreLocation)\$($c.StoreName)"
}

$result
exit $result.Code
