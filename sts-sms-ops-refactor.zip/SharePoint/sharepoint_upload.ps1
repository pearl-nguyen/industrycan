<#
.SYNOPSIS
    Uploads a file to SharePoint Online through a staging folder.

.DESCRIPTION
    1. Uploads the file to the staging folder under a unique name
       (large files in chunks - size limits in sharepoint_config.psd1;
       a failed chunk is retried and the upload resumes where it stopped)
    2. Validates the uploaded copy:
         - Office files: downloaded back and compared part by part,
           ignoring the metadata SharePoint adds
         - all other files (CSV, dump, ...): SharePoint's QuickXorHash is
           compared with the local file's, so nothing is downloaded
    3. Moves the validated file into the target folder with its real name

    The target folder only ever receives a fully validated file. The only
    item this script ever deletes is its own uniquely named staging copy.

    Signs in as the Entra app with the newest certificate whose subject
    is in SecurityConfig.psd1, so a renewed certificate needs no change.

    This script only orchestrates the steps and maps failures to exit
    codes; the work is done by functions in Common\modules. Every value
    comes from sharepoint_config.psd1 or SecurityConfig.psd1.

.EXAMPLE
    powershell.exe -ExecutionPolicy Bypass -File C:\Development\SharePoint\sharepoint_upload.ps1 `
        -LocalFile "C:\Development\data\test.xlsx" `
        -SiteName "smsfc" `
        -TargetFolder "Mass Cancellation" `
        -LogFolder "C:\Development\logs\MassCancellation"

    Add -NoOverwrite to fail (exit TargetExists) instead of replacing a
    file of the same name in the target folder.

.NOTES
    Layout:
        SharePoint\sharepoint_upload.ps1
        SharePoint\sharepoint_config.psd1     upload settings
        Security\SecurityConfig.psd1          Entra app, certificate, Graph
        Common\modules\ExitCodes.psm1
        Common\modules\JobLogging.psm1
        Common\modules\ConfigHelpers.psm1
        Common\modules\HttpHelpers.psm1
        Common\modules\FileValidation.psm1
        Common\modules\AppCertificate.psm1
        Common\modules\GraphConnection.psm1
        Common\modules\SpGraph.psm1
        Common\modules\SpPublish.psm1

    Exit codes ($ExitCode in ExitCodes.psm1):
        Success, InputNotFound (local file), SetupFailed, Unexpected,
        GraphAuthFailed, SiteNotFound, TargetExists, FolderNotFound,
        MoveFailed, UploadFailed
#>

param(
    [Parameter(Mandatory = $true)]
    [string]$LocalFile,

    [Parameter(Mandatory = $true)]
    [string]$SiteName,

    [Parameter(Mandatory = $true)]
    [string]$TargetFolder,

    # <rootfolder>\logs\<jobname>, passed by the calling job
    [Parameter(Mandatory = $true)]
    [string]$LogFolder,

    # Default: Staging.Folder in sharepoint_config.psd1
    [string]$StagingFolder = "",

    # Fail instead of replacing an existing file of the same name.
    # A switch (not a [bool]) so it works with powershell.exe -File.
    [switch]$NoOverwrite,

    [string]$ConfigPath   = (Join-Path $PSScriptRoot "sharepoint_config.psd1"),
    [string]$ModuleFolder = (Join-Path $PSScriptRoot "..\Common\modules")
)

$ErrorActionPreference = "Stop"

$Overwrite = -not $NoOverwrite

#--------------------------------------------------------------------------
# SETUP
#--------------------------------------------------------------------------

try {
    # Loaded first so even setup failures use the named codes
    Import-Module (Join-Path $ModuleFolder "ExitCodes.psm1") -Force
}
catch {
    Write-Host "Setup failed: $($_.Exception.Message)"
    exit 3   # SetupFailed: the table that names this code could not be loaded
}

try {
    foreach ($module in "JobLogging", "ConfigHelpers", "HttpHelpers", "FileValidation",
                        "AppCertificate", "GraphConnection", "SpGraph", "SpPublish") {
        Import-Module (Join-Path $ModuleFolder "$module.psm1") -Force
    }

    $Config = Import-ConfigFile -Path $ConfigPath -Required @(
        "SecurityConfig",
        "Logging.Step", "Logging.FileNameFormat", "Logging.TimestampFormat", "Logging.Separator",
        "SharePoint.Host",
        "Staging.Folder", "Staging.TimestampFormat", "Staging.RandomLength",
        "Upload.SimpleUploadLimitMB", "Upload.ChunkSizeKB", "Upload.ChunkRetries",
        "Upload.ChunkTimeoutMinutes", "Upload.ProgressLogPercent",
        "Download.TimeoutMinutes", "Download.BufferKB",
        "Retry.MaxRetries", "Retry.BaseDelaySeconds", "Retry.MaxJitterSeconds",
        "Validation.HashWaitSeconds", "Validation.HashPollSeconds",
        "Validation.OfficeSettleSeconds", "Validation.TempFolder", "Validation.TempFilePrefix",
        "Validation.KeepLastFailedDownload")

    $Logging = $Config.Logging

    $logPath = Initialize-Log `
        -LogFolder $LogFolder `
        -Step $Logging.Step `
        -FileNameFormat $Logging.FileNameFormat `
        -TimestampFormat $Logging.TimestampFormat `
        -Separator $Logging.Separator

    $configFolder = Get-ConfigFolder $ConfigPath

    $Security = Import-ConfigFile `
        -Path (Resolve-ConfigPath -Path $Config.SecurityConfig -RelativeTo $configFolder) `
        -Required @(
            "EntraApp.TenantId", "EntraApp.ClientId",
            "Certificate.Subject", "Certificate.StoreLocation", "Certificate.StoreName",
            "Certificate.DateFormat",
            "Graph.BaseUrl")

    $Retry      = $Config.Retry
    $Validation = $Config.Validation
    $Staging    = $Config.Staging
    $TempFolder = Resolve-ConfigPath -Path $Validation.TempFolder -RelativeTo $configFolder

    if (-not $StagingFolder) {
        $StagingFolder = $Staging.Folder
    }

    Initialize-SpGraph `
        -GraphBaseUrl $Security.Graph.BaseUrl `
        -SimpleUploadLimitBytes ([long]$Config.Upload.SimpleUploadLimitMB * 1MB) `
        -ChunkSizeBytes ([int]$Config.Upload.ChunkSizeKB * 1KB) `
        -ChunkRetries $Config.Upload.ChunkRetries `
        -ChunkTimeoutMinutes $Config.Upload.ChunkTimeoutMinutes `
        -RetryBaseDelay $Retry.BaseDelaySeconds `
        -RetryMaxJitter $Retry.MaxJitterSeconds `
        -ProgressLogPercent $Config.Upload.ProgressLogPercent `
        -DownloadTimeoutMinutes $Config.Download.TimeoutMinutes `
        -DownloadBufferBytes ([int]$Config.Download.BufferKB * 1KB)
}
catch {
    # Write-Log exists once JobLogging is loaded; logs to file once Initialize-Log ran
    if (Get-Command Write-Log -ErrorAction SilentlyContinue) {
        Write-Log "Setup failed: $($_.Exception.Message)" "ERROR"
    }
    else {
        Write-Host "Setup failed: $($_.Exception.Message)"
    }
    exit $ExitCode.SetupFailed
}

# Run on every exit: sign out of Graph and release the certificate
$Cleanup = { Disconnect-AppGraph }

# Safety net: any unexpected terminating error outside a try/catch still
# gets logged, disconnects from Graph and returns a non-zero exit code
trap {
    Write-LogException $_.Exception
    Exit-Job -Code $ExitCode.Unexpected -Cleanup $Cleanup
}

#--------------------------------------------------------------------------
# START
#--------------------------------------------------------------------------

Write-LogSeparator
Write-Log "Upload started"
Write-Log "Log file   : $logPath"

if (-not (Test-Path -LiteralPath $LocalFile -PathType Leaf)) {
    Write-Log "Local file not found: $LocalFile" "ERROR"
    Exit-Job -Code $ExitCode.InputNotFound -Cleanup $Cleanup
}

# Size and hash, computed once before uploading
$local = Get-LocalFileFingerprint -Path $LocalFile

$stagingName = New-SpStagingName `
    -FileName $local.Name `
    -TimestampFormat $Staging.TimestampFormat `
    -RandomLength $Staging.RandomLength

$stagingPath = ConvertTo-EncodedPath @($StagingFolder, $stagingName)

Write-Log "File       : $($local.Name)"
Write-Log "Size       : $($local.Size)"
Write-Log ("{0,-11}: {1}" -f $local.HashName, $local.Hash)
Write-Log "Staging    : /$($StagingFolder.Trim('/\'))/$stagingName"
Write-Log "Target     : /$($TargetFolder.Trim('/\'))/$($local.Name)"
Write-Log "Overwrite  : $Overwrite"

if ($local.IsOffice) {
    Write-Log "Validation : Office content comparison (SharePoint metadata ignored)"
}
else {
    Write-Log "Validation : Size and QuickXorHash (no download)"
}

#--------------------------------------------------------------------------
# AUTHENTICATION
#--------------------------------------------------------------------------

try {
    $cert = Connect-AppGraphFromConfig -SecurityConfig $Security

    Write-Log ("Certificate : {0} {1} (expires {2})" -f
        $cert.Subject, $cert.Thumbprint, $cert.NotAfter.ToString($Security.Certificate.DateFormat))
    Write-Log "Graph authentication successful"
}
catch {
    Write-LogException $_.Exception
    Exit-Job -Code $ExitCode.GraphAuthFailed -Cleanup $Cleanup
}

#--------------------------------------------------------------------------
# LOCATE SITE AND DEFAULT DOCUMENT LIBRARY
#--------------------------------------------------------------------------

try {
    $drive = Get-SpDrive -SharePointHost $Config.SharePoint.Host -SiteName $SiteName

    Write-Log "Site       : $($drive.SiteUrl)"
    Write-Log "Library    : $($drive.Name)"
}
catch {
    Write-LogException $_.Exception
    Exit-Job -Code $ExitCode.SiteNotFound -Cleanup $Cleanup
}

#--------------------------------------------------------------------------
# FOLDERS
#--------------------------------------------------------------------------

try {
    $targetFolderItem = Get-SpFolder -DriveId $drive.Id -Path $TargetFolder

    if (-not $targetFolderItem) {
        throw "Target folder not found: $TargetFolder"
    }

    $stagingFolderItem = Get-SpFolder -DriveId $drive.Id -Path $StagingFolder -CreateIfMissing

    Write-Log "Folders ready (target and staging)"
}
catch {
    Write-LogException $_.Exception
    Exit-Job -Code $ExitCode.FolderNotFound -Cleanup $Cleanup
}

#--------------------------------------------------------------------------
# OVERWRITE PRE-CHECK (fail fast, before uploading anything)
#--------------------------------------------------------------------------

try {
    $existing = Get-SpItemByPath -DriveId $drive.Id -PathParts @($TargetFolder, $local.Name)
}
catch {
    Write-LogException $_.Exception
    Exit-Job -Code $ExitCode.UploadFailed -Cleanup $Cleanup
}

if ($existing) {

    if (-not $Overwrite) {
        Write-Log "File already exists and Overwrite is false; nothing uploaded" "ERROR"
        Exit-Job -Code $ExitCode.TargetExists -Cleanup $Cleanup
    }

    Write-Log "Target file exists and will be replaced"
}

#--------------------------------------------------------------------------
# UPLOAD TO STAGING + VALIDATE (with retries)
#--------------------------------------------------------------------------

$stagedItem    = $null
$validated     = $false

# Set when validation timed out waiting for SharePoint's hash: the copy is
# probably fine, so the next attempt checks it again instead of uploading
# the whole file again (matters for multi-GB files)
$recheckStaged = $false

for ($attempt = 1; $attempt -le $Retry.MaxRetries; $attempt++) {

    $phase = "upload"

    try {
        Write-Log "Upload attempt $attempt of $($Retry.MaxRetries)"

        if ($recheckStaged) {
            Write-Log "Checking the copy already in staging again (no new upload)"
        }
        else {
            # Staging name is ours alone, so replace is always safe here
            $stagedItem = Send-SpFile `
                -DriveId $drive.Id `
                -ItemPath $stagingPath `
                -Path $local.Path `
                -ConflictBehavior "replace"

            # Log only safe fields (the full result contains a pre-authenticated
            # download URL that must not be written to logs)
            Write-Log "Upload Name : $($stagedItem.name)"
            Write-Log "Upload Id   : $($stagedItem.id)"
            Write-Log "Upload Size : $($stagedItem.size)"
            Write-Log "Upload to staging completed"
        }

        $phase         = "validate"
        $recheckStaged = $false

        Write-Log "Remote file validation starts"

        Test-SpRemoteCopy `
            -DriveId $drive.Id `
            -ItemId $stagedItem.id `
            -Local $local `
            -TempFolder $TempFolder `
            -TempFilePrefix $Validation.TempFilePrefix `
            -OfficeSettleSeconds $Validation.OfficeSettleSeconds `
            -KeepFailedDownload ([bool]$Validation.KeepLastFailedDownload -and $attempt -eq $Retry.MaxRetries) `
            -HashWaitSeconds $Validation.HashWaitSeconds `
            -HashPollSeconds $Validation.HashPollSeconds

        Write-Log "Remote file validation successful"

        $validated = $true
        break
    }
    catch [System.TimeoutException] {
        Write-LogException $_.Exception

        # Only a timeout while validating means "hash not ready yet"
        $recheckStaged = ($phase -eq "validate" -and $stagedItem -and $stagedItem.id)
    }
    catch {
        Write-LogException $_.Exception
        $recheckStaged = $false
    }

    if ($attempt -lt $Retry.MaxRetries) {

        $delay = Get-RetryDelay `
            -Attempt $attempt `
            -BaseDelay $Retry.BaseDelaySeconds `
            -MaxJitterSeconds $Retry.MaxJitterSeconds

        Write-Log "Retrying in $delay seconds" "WARN"

        Start-Sleep -Seconds $delay
    }
}

if (-not $validated) {

    Write-Log "Upload failed after $($Retry.MaxRetries) attempts" "ERROR"

    # The invalid copy is only in staging; the target was never touched
    Remove-SpStagedItem -DriveId $drive.Id -StagingFolderId $stagingFolderItem.id -Item $stagedItem

    Exit-Job -Code $ExitCode.UploadFailed -Cleanup $Cleanup
}

#--------------------------------------------------------------------------
# MOVE FROM STAGING TO TARGET
#--------------------------------------------------------------------------

$behavior = if ($Overwrite) { "replace" } else { "fail" }

try {
    $moved = Invoke-WithRetry `
        -Activity "Move to target" `
        -MaxRetries $Retry.MaxRetries `
        -BaseDelay $Retry.BaseDelaySeconds `
        -MaxJitterSeconds $Retry.MaxJitterSeconds `
        -ShouldRetry { param($m) -not (Test-IsConflictError $m) } `
        -ScriptBlock {
            Move-SpItem `
                -DriveId $drive.Id `
                -ItemId $stagedItem.id `
                -DestinationFolderId $targetFolderItem.id `
                -NewName $local.Name `
                -ConflictBehavior $behavior
        }
}
catch {
    $message = $_.Exception.Message

    Write-LogException $_.Exception

    # Deletes only if the copy is still in staging (never the published file)
    Remove-SpStagedItem -DriveId $drive.Id -StagingFolderId $stagingFolderItem.id -Item $stagedItem

    # Someone created the target file between the pre-check and the move
    if ((Test-IsConflictError $message) -and (-not $Overwrite)) {
        Write-Log "File already exists and Overwrite is false" "ERROR"
        Exit-Job -Code $ExitCode.TargetExists -Cleanup $Cleanup
    }

    Write-Log "Move from staging to target failed" "ERROR"
    Exit-Job -Code $ExitCode.MoveFailed -Cleanup $Cleanup
}

# The file is published. Reading back its details is for the log only:
# a failure here must not fail (or undo) the upload.
$finalId = $stagedItem.id
if ($moved -and $moved.id) {
    $finalId = $moved.id
}

try {
    $finalItem = Get-SpItem -DriveId $drive.Id -ItemId $finalId

    Write-Log "Final Name  : $($finalItem.name)"
    Write-Log "Final Id    : $($finalItem.id)"
    Write-Log "Final Url   : $($finalItem.webUrl)"
}
catch {
    Write-Log "Published, but its details could not be read back: $($_.Exception.Message)" "WARN"
}

Write-Log "Upload complete"

Exit-Job -Code $ExitCode.Success -Cleanup $Cleanup
