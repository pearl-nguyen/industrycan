#--------------------------------------------------------------------------
# sharepoint_config.psd1 - settings for sharepoint_upload.ps1
#   Entra app, certificate and Graph endpoint live in SecurityConfig.psd1
#   (shared with Notification and Security). Paths are relative to THIS
#   file; %VARIABLES% such as %TEMP% are expanded.
#--------------------------------------------------------------------------
@{
    #======================================================================
    # SHARED CONFIG
    #======================================================================
    SecurityConfig = "..\Security\SecurityConfig.psd1"

    #======================================================================
    # LOGGING  (<LogFolder>\<FileNameFormat>.log)
    #======================================================================
    Logging = @{
        Step            = "PUBLISH"
        FileNameFormat  = "yyyyMMdd"
        TimestampFormat = "yyyy-MM-dd HH:mm:ss"
        Separator       = "===================================================="
    }

    #======================================================================
    # SHAREPOINT
    #======================================================================
    SharePoint = @{
        Host = "033gc.sharepoint.com"
    }

    #======================================================================
    # STAGING
    #   Uploads land in Folder as <timestamp>_<random>_<file name>, are
    #   validated, then moved to the target folder (-StagingFolder
    #   overrides Folder).
    #======================================================================
    Staging = @{
        Folder          = "_staging"
        TimestampFormat = "yyyyMMddHHmmss"
        RandomLength    = 8
    }

    #======================================================================
    # UPLOAD
    #======================================================================
    Upload = @{
        # Files above this size go through an upload session in chunks.
        # Graph allows simple upload (PUT /content) up to 250 MB.
        SimpleUploadLimitMB = 250

        # Chunk size for upload sessions. Graph requires a multiple of
        # 320 KB and less than 60 MB per request. 10240 KB = 10 MB.
        ChunkSizeKB         = 10240

        # Retries per chunk before the whole upload is abandoned
        ChunkRetries        = 5

        # Timeout for sending one chunk
        ChunkTimeoutMinutes = 10

        # Chunked uploads log progress every this many percent
        ProgressLogPercent  = 10
    }

    #======================================================================
    # DOWNLOAD (Office validation downloads the uploaded copy back)
    #   Streamed to disk, so memory use stays at BufferKB whatever the
    #   file size. The timeout covers getting the response started.
    #======================================================================
    Download = @{
        TimeoutMinutes = 10
        BufferKB       = 4096
    }

    #======================================================================
    # RETRY (whole upload attempts, the move to target, and chunk retries)
    #   Delay = BaseDelaySeconds * 2^(attempt-1) + random 1..MaxJitterSeconds
    #======================================================================
    Retry = @{
        MaxRetries       = 3
        BaseDelaySeconds = 5
        MaxJitterSeconds = 5
    }

    #======================================================================
    # VALIDATION
    #======================================================================
    Validation = @{
        # Non-Office files: how long to wait for SharePoint to compute the
        # QuickXorHash after upload, and how often to check
        HashWaitSeconds        = 300
        HashPollSeconds        = 15

        # Office files: pause before downloading the copy back, so
        # SharePoint has finished adding its metadata
        OfficeSettleSeconds    = 5

        # Office files: where the downloaded copy goes, and its name prefix
        TempFolder             = "%TEMP%"
        TempFilePrefix         = "sp_"

        # Keep the download from the last failed attempt for inspection
        KeepLastFailedDownload = $true
    }
}
