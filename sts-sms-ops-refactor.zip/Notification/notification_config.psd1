#--------------------------------------------------------------------------
# notification_config.psd1 - settings for Send-JobReport.ps1
#   Entra app, certificate and Graph endpoint live in SecurityConfig.psd1.
#   Paths are relative to THIS file.
#   {{Placeholders}} are the ones listed in templates\JobReport.html
#--------------------------------------------------------------------------
@{
    #======================================================================
    # SHARED CONFIG
    #======================================================================
    SecurityConfig = "..\Security\SecurityConfig.psd1"

    #======================================================================
    # JOB REPORT EMAIL
    #======================================================================
    JobReport = @{
        # Mailbox the app sends as (needs Mail.Send)
        From             = "sts-operations@ised-isde.gc.ca"
        To               = @("team.member1@ised-isde.gc.ca", "team.member2@ised-isde.gc.ca")
        SaveToSentItems  = $false

        # Subject line (no HTML). The suffix is added when the
        # certificate is not OK.
        Subject           = "[{{Status}}] {{JobName}} - {{RunDate}}"
        CertSubjectSuffix = " | CERTIFICATE {{CertStatus}}"

        # Email body template
        Template         = "templates\JobReport.html"

        DateFormat       = "yyyy-MM-dd HH:mm"
        ExpiryDateFormat = "yyyy-MM-dd"

        # Shown for values that were not provided
        EmptyValue       = "-"

        StatusColors = @{
            Succeeded = "#1a7f37"
            Failed    = "#cf222e"
        }

        # Wrapper for the action paragraph ({{CertAction}} in the template).
        # {{CertActionText}} is the Action text of the status below.
        CertActionHtml = "<p style='color:{{CertColor}}'><b>Action:</b> {{CertActionText}}</p>"

        # One entry per certificate status. Action empty = no paragraph.
        CertStatus = @{
            Ok = @{
                Label  = "OK"
                Color  = "#1a7f37"
                Action = ""
            }
            ExpiringSoon = @{
                Label  = "EXPIRING SOON"
                Color  = "#9a6700"
                Action = "the certificate expires in {{CertDaysLeft}} days. Request a new certificate from the IT Service Desk."
            }
            Expired = @{
                Label  = "EXPIRED"
                Color  = "#cf222e"
                Action = "the certificate has EXPIRED. Request a new certificate from the IT Service Desk immediately."
            }
            NotFound = @{
                Label  = "NOT FOUND"
                Color  = "#cf222e"
                Action = "the certificate was not found on {{Machine}}. Check LocalMachine\My."
            }
        }
    }
}
