<#
  Send-JobReport.ps1
  Emails the result of a job run using an HTML template, including the certificate expiry status.
  Sends through Microsoft Graph as JobReport.From, using the Entra app certificate (Mail.Send).

  Parameters:
    -JobName         job name shown in the email (required)
    -Status          Succeeded or Failed (required)
    -Step            step that failed (or last step run); optional
    -ExitCode        exit code of that step (default 0)
    -CertStatusCode  0 OK, 1 expiring soon, 2 expired, 3 not found.
                     Optional: when omitted, the certificate is checked here.
    -CertDaysLeft / -CertExpiryDate   optional (filled in when the certificate is checked here)
    -RunDate         optional, default = now
    -LogPath         optional
    -TemplatePath    optional, overrides JobReport.Template from the config

  Settings:
    notification_config.psd1         JobReport: recipients, subject, colours, labels,
                                     action messages, date formats, template
    ..\Security\SecurityConfig.psd1  EntraApp, Certificate, Graph (sign-in)
  Building the message is in Common\modules\JobReport.psm1; sending in GraphConnection.psm1.

  Exit code: 0 = email sent, 1 = email not sent (kept for existing callers).
  NOTE: if the certificate is EXPIRED or NOT FOUND, Graph sign-in fails and no email can be sent.

  Examples:
      & "$notify\Send-JobReport.ps1" -JobName "6GHz SP AP upload" -Status Failed -Step "Upload" -ExitCode 15 -LogPath $logFile

      # Still works with a status from Test-CertExpiry.ps1:
      $cert = & "$sec\Test-CertExpiry.ps1"; $certCode = $LASTEXITCODE
      & "$notify\Send-JobReport.ps1" -JobName "6GHz SP AP upload" -Status Failed -Step "Upload" -ExitCode 15 `
          -CertStatusCode $certCode -CertDaysLeft $cert.DaysLeft -CertExpiryDate $cert.NotAfter -LogPath $logFile
#>
param(
  [Parameter(Mandatory)] [string]$JobName,
  [Parameter(Mandatory)] [ValidateSet("Succeeded","Failed")] [string]$Status,
  [string]  $Step = "",
  [int]     $ExitCode = 0,
  # -1 = not given: check the certificate here
  [ValidateRange(-1, 3)] [int]$CertStatusCode = -1,
  [string]  $CertDaysLeft   = "",
  [string]  $CertExpiryDate = "",
  [datetime]$RunDate        = (Get-Date),
  [string]  $LogPath        = "",
  [string]  $TemplatePath   = "",
  [string]  $ConfigPath     = (Join-Path $PSScriptRoot "notification_config.psd1"),
  [string]  $ModuleFolder   = (Join-Path $PSScriptRoot "..\Common\modules")
)

$ErrorActionPreference = "Stop"

# Contract with existing callers
$Sent    = 0
$NotSent = 1

# ---------- setup ----------
try {
  foreach ($module in "ConfigHelpers", "AppCertificate", "GraphConnection", "MailTemplate", "JobReport") {
    Import-Module (Join-Path $ModuleFolder "$module.psm1") -Force
  }

  $notifyCfg = Import-ConfigFile -Path $ConfigPath -Required @(
    "SecurityConfig",
    "JobReport.From", "JobReport.To", "JobReport.Subject", "JobReport.Template",
    "JobReport.DateFormat", "JobReport.ExpiryDateFormat", "JobReport.EmptyValue",
    "JobReport.StatusColors", "JobReport.CertActionHtml", "JobReport.CertStatus")

  $configFolder = Get-ConfigFolder $ConfigPath

  $cfg = Import-ConfigFile `
    -Path (Resolve-ConfigPath -Path $notifyCfg.SecurityConfig -RelativeTo $configFolder) `
    -Required @(
      "EntraApp.TenantId", "EntraApp.ClientId",
      "Certificate.Subject", "Certificate.StoreLocation", "Certificate.StoreName", "Certificate.WarningDays",
      "Graph.BaseUrl")

  $report = $notifyCfg.JobReport

  if (-not $TemplatePath) { $TemplatePath = $report.Template }
  $TemplatePath = Resolve-ConfigPath -Path $TemplatePath -RelativeTo $configFolder
  if (-not (Test-Path -LiteralPath $TemplatePath -PathType Leaf)) { throw "Template not found: $TemplatePath" }

  # Certificate status: from the caller, or checked now
  if ($CertStatusCode -lt 0) {
    $certInfo = Get-JobReportCertInfo -Certificate $cfg.Certificate -ExpiryDateFormat $report.ExpiryDateFormat
    $CertStatusCode = $certInfo.Code
    if ($CertDaysLeft -eq "") { $CertDaysLeft   = $certInfo.DaysLeft }
    if (-not $CertExpiryDate) { $CertExpiryDate = $certInfo.ExpiryDate }
  }

  $message = New-JobReportMessage `
    -Report $report `
    -TemplatePath $TemplatePath `
    -CertificateSubject $cfg.Certificate.Subject `
    -JobName $JobName `
    -Status $Status `
    -Step $Step `
    -ExitCode $ExitCode `
    -CertStatusCode $CertStatusCode `
    -CertDaysLeft $CertDaysLeft `
    -CertExpiryDate $CertExpiryDate `
    -RunDate $RunDate `
    -LogPath $LogPath `
    -Machine ([Environment]::MachineName)
}
catch {
  Write-Host "Setup failed: $($_.Exception.Message)" -ForegroundColor Red
  exit $NotSent
}

# ---------- send through Graph ----------
$result = $NotSent
try {
  $null = Connect-AppGraphFromConfig -SecurityConfig $cfg

  Send-GraphMail `
    -GraphBaseUrl $cfg.Graph.BaseUrl `
    -From $report.From `
    -To @($report.To) `
    -Subject $message.Subject `
    -HtmlBody $message.Html `
    -SaveToSentItems ([bool]$report.SaveToSentItems)

  Write-Host "Report sent to $(@($report.To) -join ', '): $($message.Subject)" -ForegroundColor Green
  $result = $Sent
}
catch {
  Write-Host "Could not send the job report email: $($_.Exception.Message)" -ForegroundColor Red
  Write-Host "Subject would have been: $($message.Subject)"
}
finally {
  # Signs out and releases the certificate
  Disconnect-AppGraph
}

exit $result
