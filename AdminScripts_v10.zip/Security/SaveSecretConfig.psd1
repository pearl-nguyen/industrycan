#--------------------------------------------------------------------------
# SaveSecretConfig.psd1
#   Settings for Security\SaveSecret.ps1. Paths are relative to this file.
#--------------------------------------------------------------------------

@{
    # Config holding the secret store (Secrets.Folder, Secrets.Entropy) and
    # the SIDs that always keep access (AccessControl.ProtectedSids)
    SecretsConfig = "..\Common\config\EntraApp.psd1"

    #----------------------------------------------------------------------
    # Exit codes.
    # A failure before this file is loaded (modules, this config itself)
    # exits with 99: the script hardcodes it since these codes aren't known yet.
    #----------------------------------------------------------------------
    ExitCodes = @{
        Success    = 0    # done
        Error      = 1    # see the log/console; for a save, the secret is admin-only or unchanged
        Unexpected = 99   # setup failed (module or config could not be loaded)
    }
}
