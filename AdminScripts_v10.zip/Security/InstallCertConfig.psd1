#--------------------------------------------------------------------------
# InstallCertConfig.psd1
#   Settings for Security\InstallCert.ps1. Paths are relative to this file.
#--------------------------------------------------------------------------

@{
    # Where -CertConfig <name> is looked up (<name>.psd1), and the default
    # certificate config when -CertConfig is not given
    ConfigFolder      = "..\Common\config"
    DefaultCertConfig = "EntraApp"

    # Config holding the secret store (PFX passwords) and the SIDs that
    # always keep access (AccessControl.ProtectedSids)
    SecretsConfig     = "..\Common\config\EntraApp.psd1"

    #----------------------------------------------------------------------
    # Certificate store and private keys
    #----------------------------------------------------------------------

    # Store the certificates are installed in: LocalMachine (shared by the
    # service account and the team) or CurrentUser
    StoreLocation = "LocalMachine"
    StoreName     = "My"

    # Key storage provider a new key must end up in (software, so the key
    # file permissions can be managed; not the TPM)
    KeyProvider   = "Microsoft Software Key Storage Provider"

    # Folders holding machine private key files, searched in order:
    # CNG (key storage providers), then legacy CryptoAPI
    KeyFolders    = @(
        "%ProgramData%\Microsoft\Crypto\Keys",
        "%ProgramData%\Microsoft\Crypto\RSA\MachineKeys"
    )

    # Accounts that count as readers of a key, carried over to a new
    # certificate: Entra users/groups (S-1-12-1-) and domain/local accounts
    # (S-1-5-21-). Built-in accounts are left out.
    ReaderSidPrefixes = @("S-1-12-1-", "S-1-5-21-")

    # Word to type to confirm deleting old certificates (-RemoveOld)
    ConfirmWord   = "YES"

    #----------------------------------------------------------------------
    # Exit codes.
    # A failure before this file is loaded (modules, this config itself)
    # exits with 99: the script hardcodes it since these codes aren't known yet.
    #----------------------------------------------------------------------
    ExitCodes = @{
        Success    = 0    # done
        Error      = 1    # see the log/console; nothing after the error was changed
        Unexpected = 99   # setup failed (module or config could not be loaded)
    }
}
