<#
    InstallCert.ps1

    Manages an app certificate in the store set in InstallCertConfig.psd1
    (StoreLocation\StoreName, LocalMachine\My): installs a new certificate
    from a PFX, and controls who can read its private key.

    Which certificate: -CertConfig, the Certificate section of a config file
        default     : DefaultCertConfig (EntraApp -> Common\config\EntraApp.psd1,
                      STS - SMS Operations)
        other cert  : -CertConfig OtherApp   -> <ConfigFolder>\OtherApp.psd1
                      -CertConfig "D:\conf\x.psd1"  (a full path)
    A certificate config needs:
        @{
            Thumbprint  = "..."     # optional: warns when a new cert differs
            Certificate = @{
                Subject       = "CN=..."     # exact subject of the certificate
                PfxSecretName = "..."        # DPAPI secret with the PFX password
            }
        }
    -Subject / -PfxSecretName override the config values.
    PFX passwords are always read from the machine's secret store
    (SecretsConfig in InstallCertConfig.psd1; save with SaveSecret.ps1).

    Run from an ELEVATED PowerShell ("Run with elevated access"):
        powershell -ExecutionPolicy Bypass -File .\InstallCert.ps1 <options>

  SEE WHO HAS ACCESS
    .\InstallCert.ps1 -ListOnly
    .\InstallCert.ps1 -ListOnly -CertConfig OtherApp

  ADD people (certificate already installed)
    .\InstallCert.ps1 -ReaderUpns "jane.doe@ised-isde.gc.ca"
    .\InstallCert.ps1 -ReaderObjectIds "<entra-user-or-group-object-id>"
    .\InstallCert.ps1 -ReaderSids "S-1-12-1-..."

  REMOVE people (left the team / department)
    .\InstallCert.ps1 -RemoveUpns "jane.doe@ised-isde.gc.ca"
    .\InstallCert.ps1 -RemoveSids "S-1-12-1-..."      # use the SID shown by -ListOnly
    (Adding and removing can be combined in one run.)

  NEW CERTIFICATE FROM IT
    1. Save the PFX password (admins-only by default):
         .\SaveSecret.ps1 -Name StsSmsOpsCertPfx
    2. Install: the password is read from DPAPI; current readers are carried over:
         .\InstallCert.ps1 -PfxPath "C:\Ops\Certs\sts.pfx"
    3. Add the new key to the Entra app, put the new thumbprint in the
       certificate config (Thumbprint), and check that the app works.
    4. Remove the old certificate:
         .\InstallCert.ps1 -PfxPath "C:\Ops\Certs\sts.pfx" -RemoveOld

  LOGGING
    -LogFolder / -LogFileName: optional; not given, lines go to the console.
    Use a log folder to keep a record of who was granted or removed.

  EXIT CODES
    From ExitCodes in InstallCertConfig.psd1 (Success, Error); 99 when the
    setup fails (module or config could not be loaded).

  NOTES
    - -ReaderUpns / -RemoveUpns only work for people who have signed in to
      this machine. Otherwise use their Entra Object ID, or for removal the
      SID shown by -ListOnly. A deleted account shows only as a SID in
      -ListOnly: remove it with -RemoveSids.
    - Changes apply to EVERY installed certificate with this Subject (old and new).
    - SYSTEM and Administrators can never be removed (prevents lock-out).
    - -RemoveOld only deletes certificates with EXACTLY this Subject that
      expire before the new one, never the one the certificate config still
      uses (Thumbprint), and only after typing the ConfirmWord (YES).
    - -ListOnly only reads; it can't be combined with changes.

    Layout (<root> = parent of this script's folder):
        <root>\Security\InstallCert.ps1
        <root>\Security\InstallCertConfig.psd1
        <root>\Common\config\EntraApp.psd1   (+ other certificate configs)
        <root>\Common\modules\Logging, ScriptHelpers, ConfigHelpers,
                              WinSecurity, DpapiSecret, CertStore (.psm1)
#>

# Parameter sets (PowerShell refuses a wrong mix before the script starts):
#   List    : -ListOnly                       (no changes allowed with it)
#   Install : -PfxPath [-RemoveOld] [readers]
#   Access  : readers only                    (default)
# One value may hold several UPNs / IDs / SIDs separated by , ; or spaces.
[CmdletBinding(DefaultParameterSetName = "Access")]
param(
    # .pfx or .p12 file
    [Parameter(Mandatory = $true, ParameterSetName = "Install")]
    [ValidatePattern('^[^*?"<>|]+\.(pfx|p12)$')]
    [string]$PfxPath,

    # A config name in ConfigFolder (default: DefaultCertConfig, i.e.
    # EntraApp = STS - SMS Operations), or a full path to a .psd1 with a
    # Certificate section
    [ValidatePattern('^([A-Za-z0-9._-]+|[^*?"<>|]+\.psd1)$')]
    [string]$CertConfig,

    # Default: Certificate.Subject in the certificate config
    [ValidateNotNullOrEmpty()]
    [string]$Subject,

    # Default: Certificate.PfxSecretName in the certificate config
    [Parameter(ParameterSetName = "Install")]
    [ValidatePattern('^[A-Za-z0-9._-]+$')]
    [string]$PfxSecretName,

    [Parameter(ParameterSetName = "Install")]
    [Parameter(ParameterSetName = "Access")]
    [ValidatePattern('^\s*[^@\s,;]+@[^@\s,;]+\.[^@\s,;]+(\s*[,;\s]\s*[^@\s,;]+@[^@\s,;]+\.[^@\s,;]+)*\s*$')]
    [string[]]$ReaderUpns      = @(),

    [Parameter(ParameterSetName = "Install")]
    [Parameter(ParameterSetName = "Access")]
    [ValidatePattern('^\s*[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}(\s*[,;\s]\s*[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12})*\s*$')]
    [string[]]$ReaderObjectIds = @(),

    [Parameter(ParameterSetName = "Install")]
    [Parameter(ParameterSetName = "Access")]
    [ValidatePattern('^\s*S-1(-\d+)+(\s*[,;\s]\s*S-1(-\d+)+)*\s*$')]
    [string[]]$ReaderSids      = @(),

    [Parameter(ParameterSetName = "Install")]
    [Parameter(ParameterSetName = "Access")]
    [ValidatePattern('^\s*[^@\s,;]+@[^@\s,;]+\.[^@\s,;]+(\s*[,;\s]\s*[^@\s,;]+@[^@\s,;]+\.[^@\s,;]+)*\s*$')]
    [string[]]$RemoveUpns      = @(),

    [Parameter(ParameterSetName = "Install")]
    [Parameter(ParameterSetName = "Access")]
    [ValidatePattern('^\s*[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}(\s*[,;\s]\s*[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12})*\s*$')]
    [string[]]$RemoveObjectIds = @(),

    [Parameter(ParameterSetName = "Install")]
    [Parameter(ParameterSetName = "Access")]
    [ValidatePattern('^\s*S-1(-\d+)+(\s*[,;\s]\s*S-1(-\d+)+)*\s*$')]
    [string[]]$RemoveSids      = @(),

    # Only with -PfxPath
    [Parameter(ParameterSetName = "Install")]
    [switch]$RemoveOld,

    [Parameter(Mandatory = $true, ParameterSetName = "List")]
    [switch]$ListOnly,

    # Not given: no log file, all lines go to the console (standard output)
    [ValidatePattern('^[^*?"<>|]*$')]
    [string]$LogFolder,

    # Plain file name (no folder), without .log
    [ValidatePattern('^[^\\/:*?"<>|]*$')]
    [string]$LogFileName
)

$ErrorActionPreference = "Stop"

# Used until the config (and its ExitCodes) is loaded
$UnexpectedExitCode = 99

$RootFolder   = Split-Path $PSScriptRoot -Parent
$ModuleFolder = Join-Path $RootFolder "Common\modules"
$ConfigFile   = Join-Path $PSScriptRoot "InstallCertConfig.psd1"

$ConfigRequired = @(
    "ConfigFolder", "DefaultCertConfig", "SecretsConfig",
    "StoreLocation", "StoreName", "KeyProvider", "KeyFolders", "ReaderSidPrefixes", "ConfirmWord",
    "ExitCodes.Success", "ExitCodes.Error", "ExitCodes.Unexpected"
)

#--------------------------------------------------------------------------
# BOOTSTRAP 1: LOGGING (nothing to log to yet -> console, exit 99)
#--------------------------------------------------------------------------

try {
    foreach ($module in @("Logging", "ScriptHelpers")) {
        Import-Module (Join-Path $ModuleFolder "$module.psm1") -Force -ErrorAction Stop
    }

    # No -LogFolder: console only ($logPath is $null)
    $logPath = Initialize-Log -LogFolder $LogFolder -LogFileName $LogFileName
}
catch {
    [Console]::Out.WriteLine("Bootstrap failed (logging): $($_.Exception.Message)")
    exit $UnexpectedExitCode
}

Write-ScriptStart -Title "InstallCert started" -LogPath $logPath -LogFileName $LogFileName

#--------------------------------------------------------------------------
# BOOTSTRAP 2: MODULES AND CONFIG (exit 99)
#--------------------------------------------------------------------------

try {
    foreach ($module in @("ConfigHelpers", "WinSecurity", "DpapiSecret", "CertStore")) {
        Import-Module (Join-Path $ModuleFolder "$module.psm1") -Force -ErrorAction Stop
    }

    $Config = Import-ConfigFile -Path $ConfigFile -Required $ConfigRequired

    Set-ScriptExit -ExitCodes $Config.ExitCodes

    $ConfigFolder  = Resolve-ConfigPath -ConfigFile $ConfigFile -Path $Config.ConfigFolder
    $SecretsConfig = Resolve-ConfigPath -ConfigFile $ConfigFile -Path $Config.SecretsConfig

    # The machine's secret store (PFX passwords) and the SIDs that always
    # keep access, whatever the certificate
    $secretsCfg = Import-ConfigFile -Path $SecretsConfig -Required "AccessControl.ProtectedSids"

    Set-ProtectedSids -Sids $secretsCfg.AccessControl.ProtectedSids

    Set-CertStorePolicy `
        -StoreLocation $Config.StoreLocation `
        -StoreName $Config.StoreName `
        -KeyProvider $Config.KeyProvider `
        -KeyFolders $Config.KeyFolders `
        -ReaderSidPrefixes $Config.ReaderSidPrefixes

    if ([string]::IsNullOrWhiteSpace($CertConfig)) {
        $CertConfig = $Config.DefaultCertConfig
    }

    # A plain name means a file in ConfigFolder
    if ([IO.Path]::IsPathRooted($CertConfig) -or $CertConfig -match '[\\/]') {
        $certConfigPath = $CertConfig
    }
    else {
        $name           = if ($CertConfig -like "*.psd1") { $CertConfig } else { "$CertConfig.psd1" }
        $certConfigPath = Join-Path $ConfigFolder $name
    }

    # Settings given as parameters are not required in the config
    $required = @()

    if ([string]::IsNullOrWhiteSpace($Subject))       { $required += "Certificate.Subject" }
    # The PFX password secret is only needed to install from a PFX
    if ($PSCmdlet.ParameterSetName -eq "Install" -and [string]::IsNullOrWhiteSpace($PfxSecretName)) {
        $required += "Certificate.PfxSecretName"
    }

    $certCfg = Import-ConfigFile -Path $certConfigPath -Required $required

    if ([string]::IsNullOrWhiteSpace($Subject))       { $Subject       = $certCfg.Certificate.Subject }
    if ([string]::IsNullOrWhiteSpace($PfxSecretName)) { $PfxSecretName = $certCfg.Certificate.PfxSecretName }

    # The config's Thumbprint describes its own certificate only
    $configThumb = $null

    # (cleaned: a pasted value may carry spaces or an invisible character,
    # which would make the "still in use" check miss it)
    if ($certCfg.Thumbprint -and (Get-ConfigValue -Config $certCfg -Key "Certificate.Subject") -eq $Subject) {
        $configThumb = ConvertTo-CleanThumbprint $certCfg.Thumbprint
    }

    if ($PfxPath) {
        Import-ConfigFile -Path $SecretsConfig -Required "Secrets.Folder", "Secrets.Entropy" | Out-Null
    }

    Write-Log "Config     : $ConfigFile"
    Write-Log "Cert config: $certConfigPath"
    Write-Log "Store      : $($Config.StoreLocation)\$($Config.StoreName)"
    Write-Log "Subject    : $Subject"
    Write-Log "User       : $(Get-CurrentUserName)"
}
catch {
    Write-LogException $_ "Bootstrap failed"
    Exit-Script "Unexpected" -Code $UnexpectedExitCode
}

#--------------------------------------------------------------------------
# ACTION
#--------------------------------------------------------------------------

try {
    Assert-Elevated

    $addSids    = @(Resolve-SidList -Sids $ReaderSids -ObjectIds $ReaderObjectIds -Upns $ReaderUpns)
    $removeSids = @(Resolve-SidList -Sids $RemoveSids -ObjectIds $RemoveObjectIds -Upns $RemoveUpns)

    if ($PSCmdlet.ParameterSetName -eq "List") {

        $certs = @(Get-StoreCert -Subject $Subject)

        if ($certs.Count -eq 0) {
            throw "No certificate with subject '$Subject' and a private key is installed."
        }

        Write-CertKeyAccess $certs
    }
    elseif ($PSCmdlet.ParameterSetName -eq "Install") {

        #------------------------------------------------------------------
        # INSTALL A NEW CERTIFICATE FROM A PFX
        #------------------------------------------------------------------

        # Stops with a clear message if the password was not saved yet
        $securePw = Get-DpapiSecret -ConfigPath $SecretsConfig -Name $PfxSecretName

        Write-Log "Using PFX password from secret '$PfxSecretName'"

        $pfxCert = Read-PfxCertificate -PfxPath $PfxPath -Password $securePw

        if ($pfxCert.Subject -ne $Subject) {
            throw "PFX subject is '$($pfxCert.Subject)', expected '$Subject'. Wrong file? Nothing was changed."
        }

        $newThumb = $pfxCert.Thumbprint

        Write-Log "PFX OK     : $Subject  thumbprint $newThumb  valid until $($pfxCert.NotAfter.ToString('yyyy-MM-dd'))"

        $newCert = Import-PfxToStore -PfxPath $PfxPath -Password $securePw -Thumbprint $newThumb

        # Other certificates with this subject: their readers are carried over
        $otherCerts = @(Get-StoreCert -Subject $Subject | Where-Object { $_.Thumbprint -ne $newThumb })
        $inherit    = @($otherCerts | ForEach-Object { Get-CertKeyReaderSids $_ })
        $toGrant    = @(@($addSids) + @($inherit) |
                        Where-Object { $_ -and ($removeSids -notcontains $_) } |
                        Select-Object -Unique)

        if ($toGrant.Count -gt 0) {
            Grant-CertKeyReader -Certs @($newCert) -Sids $toGrant
        }
        else {
            Write-Log "No readers given or carried over: only administrators can use the new key" "WARN"
        }

        if ($removeSids.Count -gt 0) {
            Revoke-CertKeyReader -Certs @(Get-StoreCert -Subject $Subject) -Sids $removeSids
        }

        Write-CertKeyAccess @($newCert)

        # Only certificates expiring before the new one count as old: a newer
        # one (e.g. an older PFX installed by mistake) is never deleted
        $newerCerts = @($otherCerts | Where-Object { $_.NotAfter -ge $pfxCert.NotAfter })
        $oldCerts   = @($otherCerts | Where-Object { $_.NotAfter -lt $pfxCert.NotAfter })

        foreach ($c in $newerCerts) {
            Write-Log "Kept $($c.Thumbprint) (expires $($c.NotAfter.ToString('yyyy-MM-dd'))): not older than the PFX certificate" "WARN"
        }

        if ($oldCerts.Count -gt 0) {

            Write-Log "Older certificates with the same subject:"
            $oldCerts | Format-Table Thumbprint, NotAfter -AutoSize | Out-String -Width 250 | Write-LogLines

            # The one the config still points to is in use: deleting it would
            # break sign-in until the config is updated
            $inUse     = @($oldCerts | Where-Object { $configThumb -and $_.Thumbprint -eq $configThumb })
            $deletable = @($oldCerts | Where-Object { $inUse -notcontains $_ })

            if ($RemoveOld) {

                foreach ($c in $inUse) {
                    Write-Log "Not deleting $($c.Thumbprint): $certConfigPath still uses it (Thumbprint). Update the config first, then re-run with -RemoveOld." "WARN"
                }

                if ($deletable.Count -gt 0) {

                    $answer = Read-Host "Delete these $($deletable.Count) old certificate(s): $(($deletable | ForEach-Object { $_.Thumbprint }) -join ', ')? Type $($Config.ConfirmWord) to confirm"

                    if ($answer -ceq $Config.ConfirmWord) {
                        foreach ($old in $deletable) {
                            Remove-StoreCert -Thumbprint $old.Thumbprint
                        }
                    }
                    else {
                        Write-Log "Deletion of old certificates skipped (not confirmed)"
                    }
                }
            }
            else {
                Write-Log "Old certificates kept. Re-run with -RemoveOld once the new key is in the app and works."
            }
        }

        Write-Log "Active (newest) thumbprint: $newThumb"

        if ($configThumb -and $configThumb -ne $newThumb) {
            Write-Log "$certConfigPath still has Thumbprint $configThumb. Update it to $newThumb once the new key is in the app." "WARN"
        }
    }
    else {

        #------------------------------------------------------------------
        # CERTIFICATE ALREADY INSTALLED: ADD / REMOVE READERS
        #------------------------------------------------------------------

        if ($addSids.Count -eq 0 -and $removeSids.Count -eq 0) {
            throw "Nothing to do. Use -ReaderUpns/-ReaderObjectIds/-ReaderSids, -RemoveUpns/-RemoveObjectIds/-RemoveSids, -PfxPath or -ListOnly."
        }

        $certs = @(Get-StoreCert -Subject $Subject)

        if ($certs.Count -eq 0) {
            throw "No certificate with subject '$Subject' and a private key is installed. Use -PfxPath to install one."
        }

        if ($addSids.Count -gt 0) {
            Grant-CertKeyReader -Certs $certs -Sids $addSids
        }

        if ($removeSids.Count -gt 0) {
            Revoke-CertKeyReader -Certs $certs -Sids $removeSids
        }

        Write-CertKeyAccess $certs
    }
}
catch {
    Write-LogException $_
    Exit-Script "Error"
}

Exit-Script "Success"
