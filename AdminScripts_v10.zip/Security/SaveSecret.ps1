<#
    SaveSecret.ps1

    Save, list or remove DPAPI-protected passwords on this machine
    (Common\modules\DpapiSecret.psm1). Settings: Secrets section of
    Common\config\EntraApp.psd1.
    Run from an ELEVATED PowerShell ("Run with elevated access").

  SAVE (you are prompted twice for the value)
    .\SaveSecret.ps1 -Name StsSmsOpsCertPfx
    .\SaveSecret.ps1 -Name OracleExport -ReaderObjectIds "<svc-account-object-id>","<team-group-object-id>"
    Saving again with the same name replaces the value (and resets its readers).

  LIST all secrets and who can read them
    .\SaveSecret.ps1 -List

  REMOVE
    .\SaveSecret.ps1 -Remove OracleExport

  LOGGING
    -LogFolder / -LogFileName: optional; not given, lines go to the console.

  EXIT CODES
    From ExitCodes in SaveSecretConfig.psd1 (Success, Error); 99 when the
    setup fails (module or config could not be loaded).

  NOTES
    Layout (<root> = parent of this script's folder):
        <root>\Security\SaveSecret.ps1
        <root>\Security\SaveSecretConfig.psd1
        <root>\Security\secrets\            (default Secrets.Folder)
        <root>\Common\config\EntraApp.psd1
        <root>\Common\modules\Logging, ScriptHelpers, ConfigHelpers,
                              WinSecurity, DpapiSecret (.psm1)
#>

# Parameter sets: one action per run (Save, List or Remove); PowerShell
# refuses a mix before the script starts. No parameter: Save (asks -Name).
# One value may hold several SIDs / IDs separated by , ; or spaces.
[CmdletBinding(DefaultParameterSetName = "Save")]
param(
    # Letters, digits, dot, dash, underscore
    [Parameter(Mandatory = $true, ParameterSetName = "Save")]
    [ValidatePattern('^[A-Za-z0-9._-]+$')]
    [string]$Name,

    [Parameter(ParameterSetName = "Save")]
    [ValidatePattern('^\s*S-1(-\d+)+(\s*[,;\s]\s*S-1(-\d+)+)*\s*$')]
    [string[]]$ReaderSids = @(),

    [Parameter(ParameterSetName = "Save")]
    [ValidatePattern('^\s*[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}(\s*[,;\s]\s*[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12})*\s*$')]
    [string[]]$ReaderObjectIds = @(),

    [Parameter(Mandatory = $true, ParameterSetName = "List")]
    [switch]$List,

    [Parameter(Mandatory = $true, ParameterSetName = "Remove")]
    [ValidatePattern('^[A-Za-z0-9._-]+$')]
    [string]$Remove,

    # Not given: no log file, all lines go to the console (standard output)
    [ValidatePattern('^[^*?"<>|]*$')]
    [string]$LogFolder,

    # Plain file name (no folder), without .log
    [ValidatePattern('^[^\\/:*?"<>|]*$')]
    [string]$LogFileName
)

$ErrorActionPreference = "Stop"

# Used until the config (and its ExitCodes) is loaded
$UnexpectedExitCode = 99

$RootFolder   = Split-Path $PSScriptRoot -Parent
$ModuleFolder = Join-Path $RootFolder "Common\modules"
$ConfigFile   = Join-Path $PSScriptRoot "SaveSecretConfig.psd1"

$ConfigRequired = @("SecretsConfig", "ExitCodes.Success", "ExitCodes.Error", "ExitCodes.Unexpected")

#--------------------------------------------------------------------------
# BOOTSTRAP 1: LOGGING (nothing to log to yet -> console, exit 99)
#--------------------------------------------------------------------------

try {
    foreach ($module in @("Logging", "ScriptHelpers")) {
        Import-Module (Join-Path $ModuleFolder "$module.psm1") -Force -ErrorAction Stop
    }

    # No -LogFolder: console only ($logPath is $null)
    $logPath = Initialize-Log -LogFolder $LogFolder -LogFileName $LogFileName
}
catch {
    [Console]::Out.WriteLine("Bootstrap failed (logging): $($_.Exception.Message)")
    exit $UnexpectedExitCode
}

Write-ScriptStart -Title "SaveSecret started" -LogPath $logPath -LogFileName $LogFileName

#--------------------------------------------------------------------------
# BOOTSTRAP 2: MODULES AND CONFIG (exit 99)
#--------------------------------------------------------------------------

try {
    foreach ($module in @("ConfigHelpers", "WinSecurity", "DpapiSecret")) {
        Import-Module (Join-Path $ModuleFolder "$module.psm1") -Force -ErrorAction Stop
    }

    $Config = Import-ConfigFile -Path $ConfigFile -Required $ConfigRequired

    Set-ScriptExit -ExitCodes $Config.ExitCodes

    # Secret store + SIDs that always keep access
    $SecretsConfig = Resolve-ConfigPath -ConfigFile $ConfigFile -Path $Config.SecretsConfig
    $secretsCfg    = Import-ConfigFile -Path $SecretsConfig -Required "Secrets.Folder", "Secrets.Entropy", "AccessControl.ProtectedSids"

    Set-ProtectedSids -Sids $secretsCfg.AccessControl.ProtectedSids

    Write-Log "Config     : $ConfigFile"
    Write-Log "Secrets    : $SecretsConfig"
    Write-Log "User       : $(Get-CurrentUserName)"
}
catch {
    Write-LogException $_ "Bootstrap failed"
    Exit-Script "Unexpected" -Code $UnexpectedExitCode
}

#--------------------------------------------------------------------------
# ACTION
#--------------------------------------------------------------------------

try {
    if ($PSCmdlet.ParameterSetName -eq "List") {

        $secrets = @(Get-DpapiSecretList -ConfigPath $SecretsConfig)

        if ($secrets.Count -eq 0) {
            Write-Log "No secrets saved"
        }
        else {
            $secrets | Format-Table -AutoSize -Wrap | Out-String -Width 250 | Write-LogLines
        }
    }
    elseif ($PSCmdlet.ParameterSetName -eq "Remove") {
        Remove-DpapiSecret -ConfigPath $SecretsConfig -Name $Remove
    }
    else {
        Save-DpapiSecret `
            -ConfigPath $SecretsConfig `
            -Name $Name `
            -ReaderSids $ReaderSids `
            -ReaderObjectIds $ReaderObjectIds
    }
}
catch {
    Write-LogException $_
    Exit-Script "Error"
}

Exit-Script "Success"
