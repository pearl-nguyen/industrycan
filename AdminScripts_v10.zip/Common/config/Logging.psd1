#--------------------------------------------------------------------------
# Logging.psd1
#   Log line format for every script (read by Common\modules\Logging.psm1
#   when it loads). If this file is missing or a value is absent, the
#   values shown here are used.
#--------------------------------------------------------------------------

@{
    # Date and time at the start of each line (.NET format)
    TimestampFormat    = "yyyy-MM-dd HH:mm:ss"

    # Default log file name when -LogFileName is not given (.NET format)
    FileNameFormat     = "yyyyMMdd_HHmmss"

    LogExtension       = ".log"

    # Separator line between sections of a run
    SeparatorChar      = "="
    SeparatorLength    = 52
}
