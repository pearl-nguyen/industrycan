#--------------------------------------------------------------------------
# ScriptHelpers.psm1
#   Start and end of every job script, so they all log and exit the same way:
#     Write-ScriptStart  : separator, title, where the log goes
#     Set-ScriptExit     : registers the exit-code table and clean-up step
#     Exit-Script        : clean-up, "Finished with exit code X (Reason)",
#                          separator, exit
#     Test-PlainFileName : checks a file name has no folder part
#   Requires Logging.psm1 to be imported by the calling script.
#--------------------------------------------------------------------------

# Fallback when a reason has no exit code (and no "Unexpected" entry either)
$script:UnexpectedExitCode = 99

# Set once per script by Set-ScriptExit
$script:ExitCodes  = $null
$script:BeforeExit = $null

# Logs the start of a run. $LogPath is what Initialize-Log returned
# ($null = console only).
function Write-ScriptStart {

    param(
        [Parameter(Mandatory = $true)][string]$Title,
        [string]$LogPath,
        [string]$LogFileName
    )

    Write-LogSeparator
    Write-Log $Title

    if ($LogPath) {
        Write-Log "Log file   : $LogPath"
        return
    }

    Write-Log "Log file   : none (console only; pass -LogFolder to write a log file)"

    if (-not [string]::IsNullOrWhiteSpace($LogFileName)) {
        Write-Log "-LogFileName ignored without -LogFolder" "WARN"
    }
}

# Registers the script's exit-code table (e.g. $Config.ExitCodes) and an
# optional clean-up step run before every exit (e.g. { Disconnect-AppGraph }),
# so each exit is just: Exit-Script "FileExists"
function Set-ScriptExit {

    param(
        [System.Collections.IDictionary]$ExitCodes,
        [scriptblock]$BeforeExit
    )

    $script:ExitCodes  = $ExitCodes
    $script:BeforeExit = $BeforeExit
}

# Ends the script: runs the clean-up step (errors are only logged), logs
# "Finished with exit code X (Reason)" and exits.
#
#   Exit-Script FileExists           code from the registered table; an
#                                    unknown reason (or no table yet) falls
#                                    back to Unexpected, or 99
#   Exit-Script Unexpected -Code 99  explicit code (before the config is
#                                    loaded, or scripts without a table)
#
# 'exit' here ends the whole script, not just this function.
function Exit-Script {

    param(
        [Parameter(Position = 0)]
        [string]$Reason,

        [Nullable[int]]$Code,

        # Default: the table registered with Set-ScriptExit
        [System.Collections.IDictionary]$ExitCodes,

        # Default: the step registered with Set-ScriptExit
        [scriptblock]$BeforeExit
    )

    if ($null -eq $ExitCodes)  { $ExitCodes  = $script:ExitCodes }
    if ($null -eq $BeforeExit) { $BeforeExit = $script:BeforeExit }

    if ($null -eq $Code) {

        $value = $null

        if ($ExitCodes -and $Reason) {
            $value = $ExitCodes[$Reason]
        }

        if ($null -eq $value) {

            if ($Reason -and $Reason -ne "Unexpected") {
                Write-Log "Unknown exit reason '$Reason'" "WARN"
            }

            $Reason = "Unexpected"

            if ($ExitCodes) {
                $value = $ExitCodes["Unexpected"]
            }

            if ($null -eq $value) {
                $value = $script:UnexpectedExitCode
            }
        }

        $Code = [int]$value
    }

    if ($BeforeExit) {
        try {
            & $BeforeExit
        }
        catch {
            Write-Log "Clean-up before exit failed: $($_.Exception.Message)" "WARN"
        }
    }

    if ($Reason) {
        Write-Log "Finished with exit code $Code ($Reason)"
    }
    else {
        Write-Log "Finished with exit code $Code"
    }

    Write-LogSeparator

    exit $Code
}

# A plain file name only: no folder part, no "..", no invalid characters,
# so a file can't land outside its folder. Returns the reason it is not
# allowed, or $null if it is fine.
function Test-PlainFileName {

    param([Parameter(Mandatory = $true)][AllowEmptyString()][string]$Name)

    if ([string]::IsNullOrWhiteSpace($Name)) {
        return "is empty"
    }

    if ($Name -match '[\\/]') {
        return "contains a folder part (\ or /)"
    }

    if ($Name.IndexOfAny([System.IO.Path]::GetInvalidFileNameChars()) -ge 0) {
        return "contains a character not allowed in file names"
    }

    if ($Name.Trim('.', ' ') -eq '') {
        return "is only dots or spaces"
    }

    return $null
}

Export-ModuleMember -Function `
    Write-ScriptStart,
    Set-ScriptExit,
    Exit-Script,
    Test-PlainFileName
