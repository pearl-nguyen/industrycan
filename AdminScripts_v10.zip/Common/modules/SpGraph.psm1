#--------------------------------------------------------------------------
# SpGraph.psm1
#   SharePoint Online helpers over Microsoft Graph: site and library,
#   items, folders, upload (simple + chunked), download, move, delete.
#   Authentication is in GraphAuth.psm1 (call Connect-AppGraph first).
#   Requires GraphAuth.psm1 for the Graph endpoint.
#   Requires Logging.psm1 and HttpHelpers.psm1 to be imported by the
#   calling script (path encoding and error matching come from HttpHelpers).
#--------------------------------------------------------------------------

Add-Type -AssemblyName System.Net.Http -ErrorAction Stop

# Graph endpoint: Get-GraphBaseUrl (GraphAuth.psm1, from the Entra config).
# Upload sizes and timeouts are parameters, from the script's config.

# Fields returned for items; "file" carries file.hashes.quickXorHash
$script:ItemSelect = "id,name,size,webUrl,folder,file,parentReference,lastModifiedDateTime"

#--------------------------------------------------------------------------
# SITE
#--------------------------------------------------------------------------

# Returns the site's default document library. Works regardless of
# language ("Documents", "Documents partagés", ...)
function Get-SpDrive {

    param(
        [Parameter(Mandatory = $true)][string]$SharePointHost,
        [Parameter(Mandatory = $true)][string]$SiteName
    )

    $sitePath = ConvertTo-EncodedPath @($SiteName)

    $site = Invoke-MgGraphRequest `
        -Method GET `
        -Uri "$(Get-GraphBaseUrl)/sites/${SharePointHost}:/sites/$sitePath" `
        -ErrorAction Stop

    $drive = Invoke-MgGraphRequest `
        -Method GET `
        -Uri "$(Get-GraphBaseUrl)/sites/$($site.id)/drive" `
        -ErrorAction Stop

    if (-not $drive -or -not $drive.id) {
        throw "Default document library not found"
    }

    return [pscustomobject]@{
        SiteUrl = $site.webUrl
        Id      = $drive.id
        Name    = $drive.name     # display name, e.g. "Documents"
        WebUrl  = $drive.webUrl   # e.g. .../sites/x/Shared%20Documents
    }
}

#--------------------------------------------------------------------------
# ITEMS / FOLDERS
#--------------------------------------------------------------------------

# Returns the item at the given (unencoded) path, or $null if it does not exist
function Get-SpItemByPath {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [string[]]$PathParts = @(),
        [string]$Select = $script:ItemSelect
    )

    $encoded = ConvertTo-EncodedPath $PathParts

    if ($encoded) {
        $uri = "$(Get-GraphBaseUrl)/drives/$DriveId/root:/$encoded"
    }
    else {
        $uri = "$(Get-GraphBaseUrl)/drives/$DriveId/root"
    }

    $uri += "?`$select=$Select"

    try {
        return Invoke-MgGraphRequest -Method GET -Uri $uri -ErrorAction Stop
    }
    catch {
        if (Test-IsNotFoundError $_.Exception.Message) {
            return $null
        }
        throw
    }
}

function Get-SpItem {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [Parameter(Mandatory = $true)][string]$ItemId,
        [string]$Select = $script:ItemSelect
    )

    return Invoke-MgGraphRequest `
        -Method GET `
        -Uri "$(Get-GraphBaseUrl)/drives/$DriveId/items/${ItemId}?`$select=$Select" `
        -ErrorAction Stop
}

# Returns the item's QuickXorHash (base64), or $null if SharePoint has not
# computed it yet. SharePoint Online does not provide SHA1/SHA256.
function Get-SpItemQuickXorHash {

    param($Item)

    if ($Item -and $Item.file -and $Item.file.hashes) {
        return $Item.file.hashes.quickXorHash
    }

    return $null
}

# Converts a Graph date (string or DateTime) to UTC DateTime, or $null
function ConvertTo-SpDateUtc {

    param($Value)

    if ($null -eq $Value) {
        return $null
    }

    if ($Value -is [datetime]) {
        return $Value.ToUniversalTime()
    }

    if ($Value -is [datetimeoffset]) {
        return $Value.UtcDateTime
    }

    $parsed = [datetimeoffset]::MinValue

    if ([datetimeoffset]::TryParse([string]$Value,
            [System.Globalization.CultureInfo]::InvariantCulture,
            [System.Globalization.DateTimeStyles]::AssumeUniversal,
            [ref]$parsed)) {
        return $parsed.UtcDateTime
    }

    return $null
}

# Reads an item with all its properties, including the short-lived
# pre-authenticated '@microsoft.graph.downloadUrl'. That URL grants access
# without a token: never write it to a log.
function Get-SpItemForDownload {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [Parameter(Mandatory = $true)][string]$ItemId
    )

    return Invoke-MgGraphRequest `
        -Method GET `
        -Uri "$(Get-GraphBaseUrl)/drives/$DriveId/items/$ItemId" `
        -ErrorAction Stop
}

# Streams a pre-authenticated download URL to a file with our own
# HttpClient, so a large file is not cut off by the Graph SDK's default
# HTTP timeout. Throttling errors carry "(429)"/"(503)" and Retry-After in
# the message so the retry helpers recognize them. The URL is not logged.
function Save-SpDownloadUrl {

    param(
        [Parameter(Mandatory = $true)][string]$Url,
        [Parameter(Mandatory = $true)][string]$OutFile,
        [Parameter(Mandatory = $true)][int]$TimeoutMinutes
    )

    $client   = $null
    $response = $null
    $stream   = $null
    $fs       = $null

    try {
        $client = New-Object System.Net.Http.HttpClient
        $client.Timeout = [TimeSpan]::FromMinutes($TimeoutMinutes)

        # ResponseHeadersRead: stream the body instead of buffering it in memory
        $response = $client.GetAsync($Url,
            [System.Net.Http.HttpCompletionOption]::ResponseHeadersRead).GetAwaiter().GetResult()

        $status = [int]$response.StatusCode

        if (-not $response.IsSuccessStatusCode) {

            $message = "Download failed ($status) $($response.ReasonPhrase)"

            if ($response.Headers.RetryAfter -and $response.Headers.RetryAfter.Delta) {
                $message += ". Retry-After: " +
                    [int][math]::Ceiling($response.Headers.RetryAfter.Delta.TotalSeconds)
            }

            throw $message
        }

        $stream = $response.Content.ReadAsStreamAsync().GetAwaiter().GetResult()

        # Creates the file even when the content is empty (0-byte files)
        $fs = [System.IO.File]::Create($OutFile)

        $stream.CopyTo($fs)
    }
    finally {
        if ($fs)       { $fs.Dispose() }
        if ($stream)   { $stream.Dispose() }
        if ($response) { $response.Dispose() }
        if ($client)   { $client.Dispose() }
    }
}

# Returns every child item of a folder (all pages)
function Get-SpChildren {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [Parameter(Mandatory = $true)][string]$FolderId,
        [string]$Select = $script:ItemSelect
    )

    $items = @()
    $uri   = "$(Get-GraphBaseUrl)/drives/$DriveId/items/$FolderId/children?`$select=$Select&`$top=999"

    while ($uri) {

        $page = Invoke-MgGraphRequest -Method GET -Uri $uri -ErrorAction Stop

        $items += @($page.value)
        $uri    = $page.'@odata.nextLink'
    }

    return $items
}

# SharePoint Online rejects some file names; retrying them is pointless.
# Returns the reason a name is not allowed, or $null if it is fine.
function Test-SpFileName {

    param([Parameter(Mandatory = $true)][string]$Name)

    if ($Name -match '["*:<>?/\\|]') {
        return 'contains a character SharePoint does not allow (" * : < > ? / \ |)'
    }

    if ($Name -ne $Name.Trim()) {
        return "starts or ends with a space"
    }

    if ($Name.EndsWith('.')) {
        return "ends with a period"
    }

    if ($Name.StartsWith('~$')) {
        return 'starts with ~$ (Office lock file)'
    }

    if ($Name -match '_vti_') {
        return "contains _vti_"
    }

    if ($Name -ieq '.lock' -or $Name -ieq 'desktop.ini') {
        return "is a reserved name"
    }

    $base = [System.IO.Path]::GetFileNameWithoutExtension($Name)

    if ($base -match '^(?i)(CON|PRN|AUX|NUL|COM[0-9]|LPT[0-9])$') {
        return "is a reserved device name"
    }

    if ($Name.Length -gt 255) {
        return "is longer than 255 characters"
    }

    return $null
}

function New-SpFolder {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [string[]]$ParentParts = @(),
        [Parameter(Mandatory = $true)][string]$Name
    )

    $parent = ConvertTo-EncodedPath $ParentParts

    if ($parent) {
        $uri = "$(Get-GraphBaseUrl)/drives/$DriveId/root:/${parent}:/children"
    }
    else {
        $uri = "$(Get-GraphBaseUrl)/drives/$DriveId/root/children"
    }

    $body = @{
        name   = $Name
        folder = @{}
        "@microsoft.graph.conflictBehavior" = "fail"
    } | ConvertTo-Json

    try {
        $item = Invoke-MgGraphRequest `
            -Method POST `
            -Uri $uri `
            -Body $body `
            -ContentType "application/json" `
            -ErrorAction Stop

        Write-Log "Folder created: $Name"

        return $item
    }
    catch {
        # Another job created it at the same time
        if (Test-IsConflictError $_.Exception.Message) {
            return Get-SpItemByPath -DriveId $DriveId -PathParts (@($ParentParts) + $Name)
        }
        throw
    }
}

# Returns the folder item for a path like "A/B/C", or $null if missing.
# With -CreateIfMissing, missing levels are created.
function Get-SpFolder {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [Parameter(Mandatory = $true)][string]$Path,
        [switch]$CreateIfMissing
    )

    $segments = @($Path -split '[\\/]' | Where-Object { $_ -ne '' })

    if ($segments.Count -eq 0) {
        throw "Folder path is empty"
    }

    $current = @()
    $item    = $null

    foreach ($seg in $segments) {

        $parentParts = $current
        $current    += $seg

        $item = Get-SpItemByPath -DriveId $DriveId -PathParts $current

        if (-not $item) {

            if (-not $CreateIfMissing) {
                return $null
            }

            $item = New-SpFolder -DriveId $DriveId -ParentParts $parentParts -Name $seg
        }

        if (-not $item.folder) {
            throw "'$($current -join '/')' exists but is not a folder"
        }
    }

    return $item
}

# Moves (and optionally renames) an item. ConflictBehavior applies when
# an item with the same name already exists in the destination.
function Move-SpItem {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [Parameter(Mandatory = $true)][string]$ItemId,
        [Parameter(Mandatory = $true)][string]$DestinationFolderId,
        [Parameter(Mandatory = $true)][string]$NewName,
        [ValidateSet("fail", "replace")]
        [string]$ConflictBehavior = "fail"
    )

    $body = @{
        parentReference = @{ id = $DestinationFolderId }
        name            = $NewName
    } | ConvertTo-Json -Depth 3

    return Invoke-MgGraphRequest `
        -Method PATCH `
        -Uri "$(Get-GraphBaseUrl)/drives/$DriveId/items/${ItemId}?@microsoft.graph.conflictBehavior=$ConflictBehavior" `
        -Body $body `
        -ContentType "application/json" `
        -ErrorAction Stop
}

function Remove-SpItem {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [Parameter(Mandatory = $true)][string]$ItemId
    )

    Invoke-MgGraphRequest `
        -Method DELETE `
        -Uri "$(Get-GraphBaseUrl)/drives/$DriveId/items/$ItemId" `
        -ErrorAction Stop | Out-Null
}

function Save-SpItemContent {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [Parameter(Mandatory = $true)][string]$ItemId,
        [Parameter(Mandatory = $true)][string]$OutFile
    )

    Invoke-MgGraphRequest `
        -Method GET `
        -Uri "$(Get-GraphBaseUrl)/drives/$DriveId/items/$ItemId/content" `
        -OutputFilePath $OutFile `
        -ErrorAction Stop
}

#--------------------------------------------------------------------------
# UPLOAD
#--------------------------------------------------------------------------

# Uploads a file to an encoded item path, choosing simple or chunked upload.
# MaxRetries/BaseDelay apply to individual chunks of a chunked upload.
function Send-SpFile {

    param(
        [Parameter(Mandatory = $true)][string]$DriveId,
        [Parameter(Mandatory = $true)][string]$ItemPath,
        [Parameter(Mandatory = $true)][string]$Path,
        [ValidateSet("fail", "replace")]
        [string]$ConflictBehavior = "replace",
        [int]$MaxRetries = 3,
        [int]$BaseDelay = 5,

        # Larger files go through an upload session in chunks
        [Parameter(Mandatory = $true)][long]$SimpleUploadLimit,

        # Chunk size in bytes: Graph requires a multiple of 320 KiB
        [Parameter(Mandatory = $true)][int]$ChunkSize,

        # Longest a single chunk request may take
        [Parameter(Mandatory = $true)][int]$ChunkTimeoutMinutes
    )

    if ($ChunkSize -le 0 -or ($ChunkSize % 320KB) -ne 0) {
        throw "Upload chunk size $ChunkSize is not a multiple of 320 KiB (327,680 bytes)."
    }

    $size = (Get-Item -LiteralPath $Path -ErrorAction Stop).Length

    if ($size -gt $SimpleUploadLimit) {

        Write-Log "Method     : Upload session (chunked)"

        return Send-SpLargeUpload `
            -DriveId $DriveId -ItemPath $ItemPath -Path $Path `
            -ConflictBehavior $ConflictBehavior `
            -MaxRetries $MaxRetries -BaseDelay $BaseDelay `
            -ChunkSize $ChunkSize -ChunkTimeoutMinutes $ChunkTimeoutMinutes
    }

    Write-Log "Method     : Simple upload"

    return Send-SpSimpleUpload `
        -DriveId $DriveId -ItemPath $ItemPath -Path $Path `
        -ConflictBehavior $ConflictBehavior
}

# Simple upload (single PUT) for files up to the simple upload limit
function Send-SpSimpleUpload {

    param(
        [string]$DriveId,
        [string]$ItemPath,
        [string]$Path,
        [string]$ConflictBehavior
    )

    $uri = "$(Get-GraphBaseUrl)/drives/$DriveId/root:/${ItemPath}:/content" +
           "?@microsoft.graph.conflictBehavior=$ConflictBehavior"

    return Invoke-MgGraphRequest `
        -Method PUT `
        -Uri $uri `
        -InputFilePath $Path `
        -ContentType "application/octet-stream" `
        -ErrorAction Stop
}

# Chunked upload for files over the simple upload limit
function Send-SpLargeUpload {

    param(
        [string]$DriveId,
        [string]$ItemPath,
        [string]$Path,
        [string]$ConflictBehavior,
        [int]$MaxRetries = 3,
        [int]$BaseDelay = 5,
        [int]$ChunkSize,
        [int]$ChunkTimeoutMinutes
    )

    $body = @{
        item = @{
            "@microsoft.graph.conflictBehavior" = $ConflictBehavior
        }
    } | ConvertTo-Json -Depth 3

    $session = Invoke-MgGraphRequest `
        -Method POST `
        -Uri "$(Get-GraphBaseUrl)/drives/$DriveId/root:/${ItemPath}:/createUploadSession" `
        -Body $body `
        -ContentType "application/json" `
        -ErrorAction Stop

    Write-Log "Upload session created"

    return Send-SpUploadChunks `
        -UploadUrl $session.uploadUrl -Path $Path `
        -MaxRetries $MaxRetries -BaseDelay $BaseDelay `
        -ChunkSize $ChunkSize -TimeoutMinutes $ChunkTimeoutMinutes
}

# Cancels an upload session so SharePoint discards the partial upload
function Stop-SpUploadSession {

    param(
        $Client,
        [string]$UploadUrl
    )

    $response = $null

    try {
        $response = $Client.DeleteAsync($UploadUrl).GetAwaiter().GetResult()
        Write-Log "Upload session cancelled" "WARN"
    }
    catch {
        Write-Log "Could not cancel upload session (it expires on its own)" "WARN"
    }
    finally {
        if ($response) { $response.Dispose() }
    }
}

# Asks the upload session where to resume (first byte of nextExpectedRanges).
# Returns $null if the session can't tell.
function Get-SpUploadSessionOffset {

    param(
        $Client,
        [string]$UploadUrl
    )

    $response = $null

    try {
        $response = $Client.GetAsync($UploadUrl).GetAwaiter().GetResult()

        if (-not $response.IsSuccessStatusCode) {
            return $null
        }

        $json  = $response.Content.ReadAsStringAsync().GetAwaiter().GetResult() |
                 ConvertFrom-Json -ErrorAction Stop
        $first = @($json.nextExpectedRanges)[0]

        if ($first -match '^(\d+)-') {
            return [long]$Matches[1]
        }

        return $null
    }
    catch {
        return $null
    }
    finally {
        if ($response) { $response.Dispose() }
    }
}

# Sends the file in chunks to an upload session URL.
# The upload URL is pre-authenticated, so no Graph token is sent with it.
# A failed chunk is retried (honoring Retry-After when throttled) and the
# upload resumes from the offset SharePoint reports, not from the start.
# The session is cancelled only when a chunk fails MaxRetries times.
function Send-SpUploadChunks {

    param(
        [string]$UploadUrl,
        [string]$Path,
        [int]$MaxRetries = 3,
        [int]$BaseDelay = 5,
        [Parameter(Mandatory = $true)][int]$ChunkSize,
        [Parameter(Mandatory = $true)][int]$TimeoutMinutes
    )

    $client = $null
    $fs     = $null
    $item   = $null

    try {

        $client = New-Object System.Net.Http.HttpClient
        $client.Timeout = [TimeSpan]::FromMinutes($TimeoutMinutes)

        $fs = [System.IO.File]::OpenRead($Path)

        [long]$total    = $fs.Length
        [long]$offset   = 0
        [int]$failures  = 0
        $buffer = New-Object byte[] $ChunkSize

        try {

            while ($offset -lt $total -and -not $item) {

                $fs.Position = $offset

                # Read() may return fewer bytes than asked (network shares);
                # every chunk except the last must be a multiple of 320 KiB
                $read = 0
                while ($read -lt $ChunkSize) {
                    $n = $fs.Read($buffer, $read, $ChunkSize - $read)
                    if ($n -le 0) { break }
                    $read += $n
                }

                if ($read -le 0) {
                    throw "Unexpected end of file at byte $offset"
                }

                $content    = $null
                $response   = $null
                $status     = 0
                $text       = $null
                $retryAfter = $null
                $errorText  = $null

                try {

                    $content = New-Object System.Net.Http.ByteArrayContent($buffer, 0, $read)

                    $content.Headers.ContentRange =
                        New-Object System.Net.Http.Headers.ContentRangeHeaderValue(
                            $offset, ($offset + $read - 1), $total)

                    $response = $client.PutAsync($UploadUrl, $content).GetAwaiter().GetResult()
                    $status   = [int]$response.StatusCode
                    $text     = $response.Content.ReadAsStringAsync().GetAwaiter().GetResult()

                    if (-not $response.IsSuccessStatusCode) {

                        $errorText = "Chunk upload failed at byte $offset ($status): $text"

                        if ($response.Headers.RetryAfter -and $response.Headers.RetryAfter.Delta) {
                            $retryAfter = [int][math]::Ceiling($response.Headers.RetryAfter.Delta.TotalSeconds)
                        }
                    }
                }
                catch {
                    # Network error / timeout
                    $errorText = "Chunk upload error at byte ${offset}: $($_.Exception.Message)"
                }
                finally {
                    if ($content)  { $content.Dispose() }
                    if ($response) { $response.Dispose() }
                }

                if (-not $errorText) {

                    $failures = 0
                    $offset  += $read

                    Write-Log ("Uploaded {0:N0} / {1:N0} bytes" -f $offset, $total)

                    # 200/201 = final chunk accepted, response body is the driveItem
                    if ($status -eq 200 -or $status -eq 201) {
                        $item = $text | ConvertFrom-Json -ErrorAction Stop
                    }

                    continue
                }

                $failures++

                Write-Log $errorText "WARN"

                if ($failures -gt $MaxRetries) {
                    throw "Chunk failed after $MaxRetries retries: $errorText"
                }

                if (Test-IsThrottleStatus $status) {

                    $delay = Register-Throttle -RetryAfter $retryAfter -Attempt $failures -BaseDelay $BaseDelay

                    if ($delay -lt 0 -or (Test-ThrottleLimitReached)) {
                        throw "Upload stopped: SharePoint throttling limit reached ($errorText)"
                    }
                }
                else {
                    $delay = Get-RetryDelay -Attempt $failures -BaseDelay $BaseDelay
                    Write-Log "Retrying chunk in $delay seconds" "WARN"
                }

                Start-Sleep -Seconds $delay

                # Resume where SharePoint says it is, in case part of the
                # chunk was received
                $resume = Get-SpUploadSessionOffset -Client $client -UploadUrl $UploadUrl

                if ($null -ne $resume -and $resume -ne $offset) {
                    Write-Log "Resuming at byte $resume (reported by SharePoint)"
                    $offset = $resume
                }
            }
        }
        catch {
            # Retries exhausted or unrecoverable error:
            # cancel the session so no partial upload is left behind
            Stop-SpUploadSession -Client $client -UploadUrl $UploadUrl
            throw
        }
    }
    finally {
        if ($fs)     { $fs.Dispose() }
        if ($client) { $client.Dispose() }
    }

    if (-not $item) {
        throw "Upload session ended without returning the uploaded item"
    }

    return $item
}

Export-ModuleMember -Function `
    Get-SpDrive,
    Get-SpItemByPath,
    Get-SpItem,
    Get-SpItemQuickXorHash,
    ConvertTo-SpDateUtc,
    Get-SpItemForDownload,
    Save-SpDownloadUrl,
    Get-SpChildren,
    Test-SpFileName,
    New-SpFolder,
    Get-SpFolder,
    Move-SpItem,
    Remove-SpItem,
    Save-SpItemContent,
    Send-SpFile
