#--------------------------------------------------------------------------
# ExcelExport.psm1
#   CSV -> Excel (.xlsx) without Excel installed, and reading an .xlsx back
#   to check it.
#     New-XlsxFormat       Excel limits and format names, from the config
#     ConvertTo-XlsxFile   writes the .xlsx from a CSV; returns what it wrote
#                          (rows, columns, a hash of every cell value)
#     Read-XlsxFile        opens an .xlsx like Excel would (package, parts,
#                          sheet XML) and returns the same figures
#     Get-XlsxSheetName    a valid sheet name from any text
#
#   Every cell is written as text, exactly as in the CSV (leading zeros,
#   long numbers and dates are kept as they are). With a header, the first
#   row is bold and frozen. Excel limits (rows, columns, characters per
#   cell) and the .xlsx format names come from the script's config.
#
#   The work is done in C# (compiled once per session): PowerShell loops
#   would be far too slow for large files.
#   No dependencies on other modules.
#--------------------------------------------------------------------------

if (-not ('ExcelExport.XlsxConverter' -as [type])) {

    # Windows PowerShell 5.1 (.NET Framework) and PowerShell 7 (.NET) name
    # the assemblies differently
    Add-Type -AssemblyName System.IO.Compression -ErrorAction Stop

    if ($PSVersionTable.PSEdition -eq "Core") {
        $references = @("System.IO.Compression", "System.Xml.ReaderWriter", "System.Xml.XmlDocument",
                        "System.Collections", "System.Runtime", "System.Text.Encoding.Extensions",
                        "System.Security.Cryptography", "System.Security.Cryptography.Algorithms",
                        "System.Security.Cryptography.Primitives", "System.Console")
    }
    else {
        $references = @("System.IO.Compression", "System.Xml")
    }

    Add-Type -ReferencedAssemblies $references -ErrorAction Stop -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Security.Cryptography;
using System.Text;
using System.Xml;

namespace ExcelExport
{
    public class CsvFormatException : Exception
    {
        public CsvFormatException(string message) : base(message) { }
    }

    public class XlsxLimitException : Exception
    {
        public XlsxLimitException(string message) : base(message) { }
    }

    // Excel limits and .xlsx format names: from the script's config
    public class XlsxFormat
    {
        public long MaxRows;
        public int MaxColumns;
        public int MaxCellChars;
        public string MainNamespace;
        public string RelationshipNamespace;
        public string PackageRelationshipNamespace;
        public string ContentTypesNamespace;
        public string RelationshipsContentType;
        public string WorkbookContentType;
        public string WorksheetContentType;
        public string StylesContentType;
        public string OfficeDocumentRelationship;
        public string WorksheetRelationship;
        public string StylesRelationship;
        public int TextNumberFormatId;
        public string FontName;
        public int FontSize;
        public int MinColumnWidth;
        public int MaxColumnWidth;
        public int WidthSampleRows;
        public int SheetNameMaxLength;
        public string SheetNameInvalidChars;
        public string DefaultSheetName;

        public void Validate()
        {
            if (MaxRows <= 0 || MaxColumns <= 0 || MaxCellChars <= 0) { throw new ArgumentException("Excel limits must be positive."); }
            if (MinColumnWidth <= 0 || MaxColumnWidth < MinColumnWidth) { throw new ArgumentException("Column widths: need 0 < MinColumnWidth <= MaxColumnWidth."); }
            if (WidthSampleRows < 1) { throw new ArgumentException("WidthSampleRows must be at least 1."); }
            if (SheetNameMaxLength < 1 || string.IsNullOrEmpty(DefaultSheetName)) { throw new ArgumentException("Sheet name settings are missing."); }
            string[] names = new string[] { MainNamespace, RelationshipNamespace, PackageRelationshipNamespace,
                ContentTypesNamespace, RelationshipsContentType, WorkbookContentType, WorksheetContentType,
                StylesContentType, OfficeDocumentRelationship, WorksheetRelationship, StylesRelationship, FontName };
            foreach (string n in names) { if (string.IsNullOrEmpty(n)) { throw new ArgumentException("An .xlsx format name is empty."); } }
        }
    }

    // What was written to, or read from, an .xlsx
    public class XlsxStats
    {
        public long Rows;
        public int MaxColumns;
        public int MinColumns;
        public long Cells;
        public long RaggedRows;      // rows whose field count differs from the first row
        public long RemovedChars;    // characters not allowed in Excel/XML (control characters)
        public long TrailingBlankLines;  // blank lines at the end of the CSV, not written
        public string Hash;          // SHA256 of every cell value, row by row
    }

    // RFC 4180 CSV reader: quoted fields, doubled quotes, delimiters and
    // line breaks inside quotes. A quote in the middle of an unquoted field
    // is kept as text. Text after a closing quote, or a quote never closed,
    // is an error.
    public class CsvRecordReader
    {
        private readonly TextReader reader;
        private readonly char delimiter;
        private long line = 1;

        public CsvRecordReader(TextReader reader, char delimiter)
        {
            this.reader = reader;
            this.delimiter = delimiter;
        }

        // Next record, or null at the end of the file
        public List<string> ReadRecord()
        {
            int c = reader.Read();

            if (c == -1)
            {
                return null;
            }

            List<string> fields = new List<string>();
            StringBuilder sb = new StringBuilder();
            bool inQuotes = false;
            bool wasQuoted = false;
            long startLine = line;

            while (true)
            {
                if (c == -1)
                {
                    if (inQuotes)
                    {
                        throw new CsvFormatException("Quote opened on line " + startLine + " is never closed.");
                    }

                    fields.Add(sb.ToString());
                    return fields;
                }

                char ch = (char)c;

                if (inQuotes)
                {
                    if (ch == '"')
                    {
                        if (reader.Peek() == '"')
                        {
                            reader.Read();
                            sb.Append('"');
                        }
                        else
                        {
                            inQuotes = false;
                        }
                    }
                    else
                    {
                        if (ch == '\n') { line++; }
                        sb.Append(ch);
                    }
                }
                else if (ch == delimiter)
                {
                    fields.Add(sb.ToString());
                    sb.Length = 0;
                    wasQuoted = false;
                }
                else if (ch == '\r' || ch == '\n')
                {
                    if (ch == '\r' && reader.Peek() == '\n') { reader.Read(); }
                    line++;
                    fields.Add(sb.ToString());
                    return fields;
                }
                else if (wasQuoted)
                {
                    throw new CsvFormatException("Text after a closing quote on line " + line + ".");
                }
                else if (ch == '"' && sb.Length == 0)
                {
                    inQuotes = true;
                    wasQuoted = true;
                }
                else
                {
                    sb.Append(ch);
                }

                c = reader.Read();
            }
        }
    }

    // Blank lines at the END of a CSV (e.g. a SQL*Plus spool) are dropped;
    // blank lines before more data are kept as rows (they may be data: a
    // one-column CSV with an empty value)
    public class TrailingBlankFilter
    {
        private readonly CsvRecordReader csv;
        private int pending = 0;
        private List<string> held = null;

        public long Skipped = 0;

        public TrailingBlankFilter(CsvRecordReader csv)
        {
            this.csv = csv;
        }

        private static bool IsBlank(List<string> record)
        {
            return record.Count == 1 && record[0].Length == 0;
        }

        // Next record to write, or null at the end
        public List<string> Next()
        {
            if (pending > 0)
            {
                pending--;
                List<string> blank = new List<string>();
                blank.Add("");
                return blank;
            }

            if (held != null)
            {
                List<string> h = held;
                held = null;
                return h;
            }

            while (true)
            {
                List<string> record = csv.ReadRecord();

                if (record == null)
                {
                    Skipped += pending;
                    pending = 0;
                    return null;
                }

                if (IsBlank(record))
                {
                    pending++;
                    continue;
                }

                if (pending > 0)
                {
                    // Blank lines followed by data: write them, then the data
                    held = record;
                    return Next();
                }

                return record;
            }
        }
    }

    public static class XlsxConverter
    {
        // Package layout written and read by this class
        private const string SheetPart = "xl/worksheets/sheet1.xml";

        private static readonly string[] RequiredParts = new string[] {
            "[Content_Types].xml", "_rels/.rels", "xl/workbook.xml",
            "xl/_rels/workbook.xml.rels", "xl/styles.xml", SheetPart
        };

        //------------------------------------------------------------------
        // WRITE
        //------------------------------------------------------------------

        public static XlsxStats Convert(string csvPath, string xlsxPath, char delimiter,
                                        string encodingName, string sheetName, bool header,
                                        XlsxFormat format)
        {
            format.Validate();

            string MainNs = format.MainNamespace;
            int widthSampleRows = format.WidthSampleRows;

            XlsxStats stats = new XlsxStats();
            stats.MinColumns = int.MaxValue;

            Encoding encoding = GetEncoding(encodingName);
            int firstRowColumns = -1;

            using (SHA256 sha = SHA256.Create())
            using (StreamReader sr = new StreamReader(csvPath, encoding, true))
            using (FileStream fs = new FileStream(xlsxPath, FileMode.CreateNew, FileAccess.Write))
            using (ZipArchive zip = new ZipArchive(fs, ZipArchiveMode.Create))
            {
                TrailingBlankFilter csv = new TrailingBlankFilter(new CsvRecordReader(sr, delimiter));

                WriteStaticParts(zip, sheetName, format);

                // First rows are held back to size the columns
                List<List<string>> sample = new List<List<string>>();
                List<string> record;

                while (sample.Count < widthSampleRows && (record = csv.Next()) != null)
                {
                    sample.Add(Sanitize(record, stats));
                }

                ZipArchiveEntry entry = zip.CreateEntry(SheetPart, CompressionLevel.Optimal);

                using (Stream es = entry.Open())
                using (XmlWriter xw = XmlWriter.Create(es, WriterSettings()))
                {
                    xw.WriteStartDocument(true);
                    xw.WriteStartElement("worksheet", MainNs);

                    if (header && sample.Count > 0)
                    {
                        // Freeze the header row
                        xw.WriteStartElement("sheetViews", MainNs);
                        xw.WriteStartElement("sheetView", MainNs);
                        xw.WriteAttributeString("workbookViewId", "0");
                        xw.WriteStartElement("pane", MainNs);
                        xw.WriteAttributeString("ySplit", "1");
                        xw.WriteAttributeString("topLeftCell", "A2");
                        xw.WriteAttributeString("activePane", "bottomLeft");
                        xw.WriteAttributeString("state", "frozen");
                        xw.WriteEndElement();
                        xw.WriteStartElement("selection", MainNs);
                        xw.WriteAttributeString("pane", "bottomLeft");
                        xw.WriteAttributeString("activeCell", "A2");
                        xw.WriteAttributeString("sqref", "A2");
                        xw.WriteEndElement();
                        xw.WriteEndElement();
                        xw.WriteEndElement();
                    }

                    WriteColumnWidths(xw, sample, format);

                    xw.WriteStartElement("sheetData", MainNs);

                    foreach (List<string> row in sample)
                    {
                        WriteRow(xw, row, stats, sha, header, ref firstRowColumns, format);
                    }

                    sample = null;

                    while ((record = csv.Next()) != null)
                    {
                        WriteRow(xw, Sanitize(record, stats), stats, sha, header, ref firstRowColumns, format);
                    }

                    xw.WriteEndElement();   // sheetData
                    xw.WriteEndElement();   // worksheet
                    xw.WriteEndDocument();
                }

                sha.TransformFinalBlock(new byte[0], 0, 0);
                stats.Hash = ToHex(sha.Hash);
                stats.TrailingBlankLines = csv.Skipped;
            }

            if (stats.Rows == 0)
            {
                stats.MinColumns = 0;
            }

            return stats;
        }

        private static void WriteRow(XmlWriter xw, List<string> row, XlsxStats stats, SHA256 sha,
                                     bool header, ref int firstRowColumns, XlsxFormat format)
        {
            string MainNs = format.MainNamespace;

            stats.Rows++;

            if (stats.Rows > format.MaxRows)
            {
                throw new XlsxLimitException("More than " + format.MaxRows + " rows: Excel can't hold this file in one sheet.");
            }

            if (row.Count > format.MaxColumns)
            {
                throw new XlsxLimitException("Row " + stats.Rows + " has " + row.Count + " fields; Excel allows " + format.MaxColumns + " columns.");
            }

            if (firstRowColumns < 0) { firstRowColumns = row.Count; }
            else if (row.Count != firstRowColumns) { stats.RaggedRows++; }

            if (row.Count > stats.MaxColumns) { stats.MaxColumns = row.Count; }
            if (row.Count < stats.MinColumns) { stats.MinColumns = row.Count; }

            // Style 1 = bold header, style 2 = text
            string style = (header && stats.Rows == 1) ? "1" : "2";
            string rowNumber = stats.Rows.ToString();

            xw.WriteStartElement("row", MainNs);
            xw.WriteAttributeString("r", rowNumber);

            for (int i = 0; i < row.Count; i++)
            {
                string value = row[i];

                if (value.Length > format.MaxCellChars)
                {
                    throw new XlsxLimitException("Row " + stats.Rows + ", column " + (i + 1) + " has " + value.Length +
                                                 " characters; Excel allows " + format.MaxCellChars + " per cell.");
                }

                xw.WriteStartElement("c", MainNs);
                xw.WriteAttributeString("r", ColumnName(i + 1) + rowNumber);
                xw.WriteAttributeString("s", style);
                xw.WriteAttributeString("t", "inlineStr");
                xw.WriteStartElement("is", MainNs);
                xw.WriteStartElement("t", MainNs);
                xw.WriteAttributeString("xml", "space", "http://www.w3.org/XML/1998/namespace", "preserve");
                xw.WriteString(value);
                xw.WriteEndElement();
                xw.WriteEndElement();
                xw.WriteEndElement();

                stats.Cells++;
            }

            xw.WriteEndElement();

            HashRow(sha, row);
        }

        private static void WriteColumnWidths(XmlWriter xw, List<List<string>> sample, XlsxFormat format)
        {
            string MainNs = format.MainNamespace;

            int columns = 0;
            foreach (List<string> row in sample) { if (row.Count > columns) { columns = row.Count; } }

            if (columns == 0) { return; }

            int[] widest = new int[columns];

            foreach (List<string> row in sample)
            {
                for (int i = 0; i < row.Count; i++)
                {
                    int len = 0;
                    foreach (string part in row[i].Split('\n'))
                    {
                        if (part.Length > len) { len = part.Length; }
                    }
                    if (len > widest[i]) { widest[i] = len; }
                }
            }

            xw.WriteStartElement("cols", MainNs);

            for (int i = 0; i < columns; i++)
            {
                double width = Math.Min(format.MaxColumnWidth, Math.Max(format.MinColumnWidth, widest[i] + 2));

                xw.WriteStartElement("col", MainNs);
                xw.WriteAttributeString("min", (i + 1).ToString());
                xw.WriteAttributeString("max", (i + 1).ToString());
                xw.WriteAttributeString("width", width.ToString(System.Globalization.CultureInfo.InvariantCulture));
                xw.WriteAttributeString("customWidth", "1");
                xw.WriteEndElement();
            }

            xw.WriteEndElement();
        }

        private static void WriteStaticParts(ZipArchive zip, string sheetName, XlsxFormat f)
        {
            const string Decl = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>";

            WritePart(zip, "[Content_Types].xml", Decl +
                "<Types xmlns=\"" + f.ContentTypesNamespace + "\">" +
                "<Default Extension=\"rels\" ContentType=\"" + f.RelationshipsContentType + "\"/>" +
                "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                "<Override PartName=\"/xl/workbook.xml\" ContentType=\"" + f.WorkbookContentType + "\"/>" +
                "<Override PartName=\"/" + SheetPart + "\" ContentType=\"" + f.WorksheetContentType + "\"/>" +
                "<Override PartName=\"/xl/styles.xml\" ContentType=\"" + f.StylesContentType + "\"/>" +
                "</Types>");

            WritePart(zip, "_rels/.rels", Decl +
                "<Relationships xmlns=\"" + f.PackageRelationshipNamespace + "\">" +
                "<Relationship Id=\"rId1\" Type=\"" + f.OfficeDocumentRelationship + "\" Target=\"xl/workbook.xml\"/>" +
                "</Relationships>");

            WritePart(zip, "xl/workbook.xml", Decl +
                "<workbook xmlns=\"" + f.MainNamespace + "\" xmlns:r=\"" + f.RelationshipNamespace + "\">" +
                "<sheets><sheet name=\"" + EscapeXml(sheetName) + "\" sheetId=\"1\" r:id=\"rId1\"/></sheets>" +
                "</workbook>");

            WritePart(zip, "xl/_rels/workbook.xml.rels", Decl +
                "<Relationships xmlns=\"" + f.PackageRelationshipNamespace + "\">" +
                "<Relationship Id=\"rId1\" Type=\"" + f.WorksheetRelationship + "\" Target=\"worksheets/sheet1.xml\"/>" +
                "<Relationship Id=\"rId2\" Type=\"" + f.StylesRelationship + "\" Target=\"styles.xml\"/>" +
                "</Relationships>");

            string font = "<sz val=\"" + f.FontSize + "\"/><name val=\"" + EscapeXml(f.FontName) + "\"/>";
            string textFmt = f.TextNumberFormatId.ToString();

            // Styles: 0 = default, 1 = bold header, 2 = text (data); both as text format
            WritePart(zip, "xl/styles.xml", Decl +
                "<styleSheet xmlns=\"" + f.MainNamespace + "\">" +
                "<fonts count=\"2\"><font>" + font + "</font><font><b/>" + font + "</font></fonts>" +
                "<fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill></fills>" +
                "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>" +
                "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
                "<cellXfs count=\"3\">" +
                "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>" +
                "<xf numFmtId=\"" + textFmt + "\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyNumberFormat=\"1\"/>" +
                "<xf numFmtId=\"" + textFmt + "\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\"/>" +
                "</cellXfs>" +
                "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles>" +
                "</styleSheet>");
        }

        private static void WritePart(ZipArchive zip, string name, string content)
        {
            ZipArchiveEntry entry = zip.CreateEntry(name, CompressionLevel.Optimal);

            using (Stream s = entry.Open())
            {
                byte[] bytes = new UTF8Encoding(false).GetBytes(content);
                s.Write(bytes, 0, bytes.Length);
            }
        }

        private static XmlWriterSettings WriterSettings()
        {
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Encoding = new UTF8Encoding(false);
            // \r is written as &#xD; so a value with \r\n reads back unchanged
            settings.NewLineHandling = NewLineHandling.Entitize;
            settings.CloseOutput = false;
            return settings;
        }

        //------------------------------------------------------------------
        // READ BACK
        //------------------------------------------------------------------

        // Opens the .xlsx like Excel would: the package, every required
        // part, well-formed XML, then every cell of the sheet
        public static XlsxStats Read(string xlsxPath, XlsxFormat format)
        {
            format.Validate();

            XlsxStats stats = new XlsxStats();
            stats.MinColumns = int.MaxValue;

            using (SHA256 sha = SHA256.Create())
            using (FileStream fs = new FileStream(xlsxPath, FileMode.Open, FileAccess.Read, FileShare.Read))
            using (ZipArchive zip = new ZipArchive(fs, ZipArchiveMode.Read))
            {
                foreach (string part in RequiredParts)
                {
                    ZipArchiveEntry e = zip.GetEntry(part);

                    if (e == null)
                    {
                        throw new InvalidDataException("Part missing from the workbook: " + part);
                    }

                    if (part != SheetPart)
                    {
                        using (Stream ps = e.Open())
                        {
                            XmlDocument doc = new XmlDocument();
                            doc.XmlResolver = null;
                            doc.Load(ps);
                        }
                    }
                }

                XmlReaderSettings settings = new XmlReaderSettings();
                settings.DtdProcessing = DtdProcessing.Prohibit;
                settings.XmlResolver = null;

                using (Stream ss = zip.GetEntry(SheetPart).Open())
                using (XmlReader xr = XmlReader.Create(ss, settings))
                {
                    List<string> row = null;

                    while (xr.Read())
                    {
                        if (xr.NodeType == XmlNodeType.Element && xr.LocalName == "row")
                        {
                            row = new List<string>();

                            if (xr.IsEmptyElement)
                            {
                                FinishRow(row, stats, sha);
                                row = null;
                            }
                        }
                        else if (xr.NodeType == XmlNodeType.Element && xr.LocalName == "c" && row != null)
                        {
                            int index = ColumnIndex(xr.GetAttribute("r"), row.Count + 1);
                            string value = ReadCellText(xr);

                            while (row.Count < index - 1) { row.Add(""); }

                            if (row.Count >= index) { row[index - 1] = value; } else { row.Add(value); }
                        }
                        else if (xr.NodeType == XmlNodeType.EndElement && xr.LocalName == "row" && row != null)
                        {
                            FinishRow(row, stats, sha);
                            row = null;
                        }
                    }
                }

                sha.TransformFinalBlock(new byte[0], 0, 0);
                stats.Hash = ToHex(sha.Hash);
            }

            if (stats.Rows == 0)
            {
                stats.MinColumns = 0;
            }

            return stats;
        }

        private static string ReadCellText(XmlReader xr)
        {
            if (xr.IsEmptyElement)
            {
                return "";
            }

            StringBuilder sb = new StringBuilder();

            using (XmlReader sub = xr.ReadSubtree())
            {
                sub.Read();

                while (!sub.EOF)
                {
                    if (sub.NodeType == XmlNodeType.Element && (sub.LocalName == "t" || sub.LocalName == "v"))
                    {
                        sb.Append(sub.ReadElementContentAsString());
                    }
                    else
                    {
                        sub.Read();
                    }
                }
            }

            return sb.ToString();
        }

        private static void FinishRow(List<string> row, XlsxStats stats, SHA256 sha)
        {
            stats.Rows++;
            stats.Cells += row.Count;

            if (row.Count > stats.MaxColumns) { stats.MaxColumns = row.Count; }
            if (row.Count < stats.MinColumns) { stats.MinColumns = row.Count; }

            HashRow(sha, row);
        }

        //------------------------------------------------------------------
        // SHARED
        //------------------------------------------------------------------

        // Same hashing on both sides: value + 0x1F per cell, 0x1E per row
        private static void HashRow(SHA256 sha, List<string> row)
        {
            StringBuilder sb = new StringBuilder();

            foreach (string value in row)
            {
                sb.Append(value);
                sb.Append('\u001F');
            }

            sb.Append('\u001E');

            byte[] bytes = Encoding.UTF8.GetBytes(sb.ToString());
            sha.TransformBlock(bytes, 0, bytes.Length, null, 0);
        }

        // Removes characters XML (and so Excel) can't hold: control characters
        // other than tab/CR/LF, unpaired surrogates, U+FFFE/U+FFFF
        private static List<string> Sanitize(List<string> record, XlsxStats stats)
        {
            for (int i = 0; i < record.Count; i++)
            {
                string value = record[i];
                StringBuilder sb = null;

                for (int j = 0; j < value.Length; j++)
                {
                    char ch = value[j];
                    bool ok;

                    if (char.IsHighSurrogate(ch))
                    {
                        ok = j + 1 < value.Length && char.IsLowSurrogate(value[j + 1]);

                        if (ok)
                        {
                            if (sb != null) { sb.Append(ch).Append(value[j + 1]); }
                            j++;
                            continue;
                        }
                    }
                    else if (char.IsLowSurrogate(ch))
                    {
                        ok = false;
                    }
                    else
                    {
                        ok = (ch >= 0x20 && ch != '￾' && ch != '￿') || ch == '\t' || ch == '\n' || ch == '\r';
                    }

                    if (!ok)
                    {
                        if (sb == null) { sb = new StringBuilder(value.Substring(0, j)); }
                        stats.RemovedChars++;
                        continue;
                    }

                    if (sb != null) { sb.Append(ch); }
                }

                if (sb != null) { record[i] = sb.ToString(); }
            }

            return record;
        }

        public static string ColumnName(int index)
        {
            string name = "";

            while (index > 0)
            {
                int m = (index - 1) % 26;
                name = (char)('A' + m) + name;
                index = (index - 1) / 26;
            }

            return name;
        }

        private static int ColumnIndex(string reference, int fallback)
        {
            if (string.IsNullOrEmpty(reference)) { return fallback; }

            int index = 0;

            foreach (char ch in reference)
            {
                if (ch >= 'A' && ch <= 'Z') { index = index * 26 + (ch - 'A' + 1); }
                else { break; }
            }

            return index > 0 ? index : fallback;
        }

        private static Encoding GetEncoding(string name)
        {
            switch ((name ?? "").ToUpperInvariant())
            {
                case "UTF8":        return new UTF8Encoding(false);
                case "WINDOWS1252": return Encoding.GetEncoding(1252);
                case "UNICODE":     return Encoding.Unicode;
                default:            throw new ArgumentException("Unknown encoding '" + name + "'. Use UTF8, Windows1252 or Unicode.");
            }
        }

        private static string EscapeXml(string text)
        {
            return text.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;").Replace("\"", "&quot;");
        }

        private static string ToHex(byte[] bytes)
        {
            StringBuilder sb = new StringBuilder(bytes.Length * 2);
            foreach (byte b in bytes) { sb.Append(b.ToString("X2")); }
            return sb.ToString();
        }
    }
}
'@
}

#--------------------------------------------------------------------------
# FUNCTIONS
#--------------------------------------------------------------------------

# A valid Excel sheet name: invalid characters replaced by _, at most
# SheetNameMaxLength characters, not starting or ending with an apostrophe,
# DefaultSheetName when nothing is left (rules from the config)
function Get-XlsxSheetName {

    param(
        [AllowEmptyString()][string]$Name,
        [Parameter(Mandatory = $true)][ExcelExport.XlsxFormat]$Format
    )

    # Each character escaped on its own: [regex]::Escape leaves ] as is,
    # which would end the character class early
    $chars   = $Format.SheetNameInvalidChars.ToCharArray() | ForEach-Object { '\' + $_ }
    $invalid = '[' + ($chars -join '') + ']'
    $clean   = ($Name -replace $invalid, '_').Trim().Trim("'")

    if ($clean.Length -gt $Format.SheetNameMaxLength) {
        $clean = $clean.Substring(0, $Format.SheetNameMaxLength).Trim().Trim("'")
    }

    if ([string]::IsNullOrWhiteSpace($clean)) {
        $clean = $Format.DefaultSheetName
    }

    return $clean
}

# The XlsxFormat object (Excel limits, .xlsx format names, font, column
# widths) from the Excel section of the script's config
function New-XlsxFormat {

    param([Parameter(Mandatory = $true)][System.Collections.IDictionary]$Settings)

    $format = New-Object ExcelExport.XlsxFormat

    foreach ($field in $format.GetType().GetFields()) {

        if (-not $Settings.Contains($field.Name)) {
            throw "Excel setting '$($field.Name)' is missing."
        }

        $field.SetValue($format, [Convert]::ChangeType($Settings[$field.Name], $field.FieldType))
    }

    $format.Validate()

    return $format
}

# Writes $XlsxPath from $CsvPath ($XlsxPath must not exist yet).
# Returns an ExcelExport.XlsxStats: Rows, MaxColumns, MinColumns, Cells,
# RaggedRows, RemovedChars, Hash.
# Throws ExcelExport.CsvFormatException (bad quoting) or
# ExcelExport.XlsxLimitException (too big for Excel).
function ConvertTo-XlsxFile {

    param(
        [Parameter(Mandatory = $true)][string]$CsvPath,
        [Parameter(Mandatory = $true)][string]$XlsxPath,
        [Parameter(Mandatory = $true)][string]$Delimiter,
        [Parameter(Mandatory = $true)][ValidateSet("UTF8", "Windows1252", "Unicode")][string]$Encoding,
        [Parameter(Mandatory = $true)][AllowEmptyString()][string]$SheetName,
        [Parameter(Mandatory = $true)][ExcelExport.XlsxFormat]$Format,
        [switch]$NoHeader
    )

    if ($Delimiter.Length -ne 1) {
        throw "Delimiter must be one character, got '$Delimiter'."
    }

    # .NET resolves relative paths against the process folder, not PowerShell's
    $csvFull  = (Resolve-Path -LiteralPath $CsvPath -ErrorAction Stop).ProviderPath
    $xlsxFull = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($XlsxPath)

    return [ExcelExport.XlsxConverter]::Convert(
        $csvFull, $xlsxFull, $Delimiter[0], $Encoding, (Get-XlsxSheetName -Name $SheetName -Format $Format),
        (-not $NoHeader), $Format)
}

# Opens an .xlsx and returns the same figures as ConvertTo-XlsxFile.
# Throws when the file is not a readable workbook.
function Read-XlsxFile {

    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][ExcelExport.XlsxFormat]$Format
    )

    $full = (Resolve-Path -LiteralPath $Path -ErrorAction Stop).ProviderPath

    return [ExcelExport.XlsxConverter]::Read($full, $Format)
}

Export-ModuleMember -Function `
    New-XlsxFormat,
    Get-XlsxSheetName,
    ConvertTo-XlsxFile,
    Read-XlsxFile
