#--------------------------------------------------------------------------
# CertStore.psm1
#   Certificates and who can read their private keys.
#
#   Settings come from the calling script's config, set once with
#   Set-CertStorePolicy (store, key provider, key folders, which accounts
#   count as readers). The functions that use them refuse to run until
#   then. The expiry functions only need what they are given.
#
#   Policy
#     Set-CertStorePolicy     store, key provider, key folders, reader SID prefixes
#   Find
#     Get-StoreCert           certificates with an exact subject (newest first)
#     Find-CertByThumbprint   a certificate by thumbprint in a list of stores
#     Get-CertExpiry          days left and level (Ok/Warning/Critical/Expired)
#   Private key
#     Get-CertKeyPath         file holding a certificate's private key
#     Get-CertKeyReaderSids   users/groups allowed to read the key
#     Grant-CertKeyReader     give read access on the key(s)
#     Revoke-CertKeyReader    remove access (protected SIDs skipped)
#     Write-CertKeyAccess     log who can read each certificate's key
#   Install / delete
#     Read-PfxCertificate     the end-entity certificate inside a PFX
#     Import-PfxToStore       install a PFX (configured key provider, not exportable)
#     Remove-StoreCert        delete a certificate and its private key
#
#   Requires Logging.psm1 and WinSecurity.psm1 to be imported by the
#   calling script. Machine store and key changes need an elevated session.
#--------------------------------------------------------------------------

$script:Policy = $null

#--------------------------------------------------------------------------
# POLICY
#--------------------------------------------------------------------------

# StoreLocation : LocalMachine or CurrentUser
# StoreName     : e.g. My
# KeyProvider   : key storage provider a new key must end up in
# KeyFolders    : folders holding private key files ("%ProgramData%" etc.
#                 are expanded), searched in order
# ReaderSidPrefixes : SIDs that count as readers (carried over to a new
#                 certificate), e.g. "S-1-12-1-", "S-1-5-21-"
function Set-CertStorePolicy {

    param(
        [Parameter(Mandatory = $true)][ValidateSet("LocalMachine", "CurrentUser")][string]$StoreLocation,
        [Parameter(Mandatory = $true)][string]$StoreName,
        [Parameter(Mandatory = $true)][string]$KeyProvider,
        [Parameter(Mandatory = $true)][string[]]$KeyFolders,
        [Parameter(Mandatory = $true)][string[]]$ReaderSidPrefixes
    )

    $script:Policy = [pscustomobject]@{
        StoreLocation     = $StoreLocation
        StoreName         = $StoreName
        StorePath         = "Cert:\$StoreLocation\$StoreName"
        KeyProvider       = $KeyProvider
        KeyFolders        = @($KeyFolders | ForEach-Object { [Environment]::ExpandEnvironmentVariables($_) })
        ReaderSidPrefixes = $ReaderSidPrefixes
    }
}

function Get-CertStorePolicy {

    if (-not $script:Policy) {
        throw "Certificate store settings not set: the script must call Set-CertStorePolicy first."
    }

    return $script:Policy
}

#--------------------------------------------------------------------------
# FIND
#--------------------------------------------------------------------------

# Certificates in the configured store whose Subject is exactly $Subject and
# that have a private key, newest expiry first
function Get-StoreCert {

    param([Parameter(Mandatory = $true)][string]$Subject)

    $policy = Get-CertStorePolicy

    return @(Get-ChildItem $policy.StorePath -ErrorAction Stop |
             Where-Object { $_.Subject -eq $Subject -and $_.HasPrivateKey } |
             Sort-Object NotAfter -Descending)
}

# First certificate with this thumbprint in the given stores
# (e.g. "Cert:\LocalMachine\My", "Cert:\CurrentUser\My"), or $null
function Find-CertByThumbprint {

    param(
        [Parameter(Mandatory = $true)][string]$Thumbprint,
        [Parameter(Mandatory = $true)][string[]]$StorePaths
    )

    foreach ($store in $StorePaths) {

        $path = "$($store.TrimEnd('\'))\$Thumbprint"

        if (Test-Path $path) {
            return Get-Item $path -ErrorAction Stop
        }
    }

    return $null
}

# Days left before a certificate expires and its level:
#   Expired  : already expired
#   Critical : CriticalDays or fewer left
#   Warning  : WarningDays or fewer left
#   Ok       : more than WarningDays left
function Get-CertExpiry {

    param(
        [Parameter(Mandatory = $true)]$Cert,
        [Parameter(Mandatory = $true)][int]$WarningDays,
        [Parameter(Mandatory = $true)][int]$CriticalDays,
        [datetime]$Now = (Get-Date)
    )

    $daysLeft = [int][math]::Floor(($Cert.NotAfter - $Now).TotalDays)

    $level = if ($Cert.NotAfter -le $Now)      { "Expired" }
             elseif ($daysLeft -le $CriticalDays) { "Critical" }
             elseif ($daysLeft -le $WarningDays)  { "Warning" }
             else                                 { "Ok" }

    return [pscustomobject]@{
        Thumbprint = $Cert.Thumbprint
        Subject    = $Cert.Subject
        NotAfter   = $Cert.NotAfter
        DaysLeft   = $daysLeft
        Level      = $level
    }
}

#--------------------------------------------------------------------------
# PRIVATE KEY
#--------------------------------------------------------------------------

# Key container name and provider of a certificate's private key, read
# from the key itself (RSA or EC; CNG or legacy CryptoAPI). Not exported.
function Get-CertKeyInfo {

    param([Parameter(Mandatory = $true)]$Cert)

    $key = [System.Security.Cryptography.X509Certificates.RSACertificateExtensions]::GetRSAPrivateKey($Cert)

    if (-not $key) {
        $key = [System.Security.Cryptography.X509Certificates.ECDsaCertificateExtensions]::GetECDsaPrivateKey($Cert)
    }

    if (-not $key) {
        throw "No RSA or ECDSA private key found for $($Cert.Thumbprint)."
    }

    try {
        if ($key.PSObject.Properties['Key'] -and $key.Key) {
            # CNG
            return [pscustomobject]@{
                UniqueName = $key.Key.UniqueName
                Provider   = $key.Key.Provider.Provider
            }
        }

        if ($key.PSObject.Properties['CspKeyContainerInfo']) {
            # Legacy CryptoAPI
            return [pscustomobject]@{
                UniqueName = $key.CspKeyContainerInfo.UniqueKeyContainerName
                Provider   = $key.CspKeyContainerInfo.ProviderName
            }
        }

        throw "Cannot tell where the private key of $($Cert.Thumbprint) is stored."
    }
    finally {
        $key.Dispose()
    }
}

# Full path of the file holding the certificate's private key
function Get-CertKeyPath {

    param([Parameter(Mandatory = $true)]$Cert)

    $info = Get-CertKeyInfo $Cert

    foreach ($folder in (Get-CertStorePolicy).KeyFolders) {

        $path = Join-Path $folder $info.UniqueName

        if (Test-Path -LiteralPath $path -PathType Leaf) {
            return $path
        }
    }

    throw "Private key file not found for $($Cert.Thumbprint) in the key folders (hardware/TPM key?)."
}

function Get-CertKeyReaderSids {

    param([Parameter(Mandatory = $true)]$Cert)

    return Get-PathReaderSids -Path (Get-CertKeyPath $Cert) -Prefixes (Get-CertStorePolicy).ReaderSidPrefixes
}

function Grant-CertKeyReader {

    param(
        [Parameter(Mandatory = $true)]$Certs,
        [Parameter(Mandatory = $true)][string[]]$Sids
    )

    foreach ($c in @($Certs)) {

        $path = Get-CertKeyPath $c

        foreach ($sid in $Sids) {
            Grant-PathRead -Path $path -Sid $sid
            Write-Log "Granted read : $sid  ->  $($c.Thumbprint)"
        }
    }
}

function Revoke-CertKeyReader {

    param(
        [Parameter(Mandatory = $true)]$Certs,
        [Parameter(Mandatory = $true)][string[]]$Sids
    )

    $protected = Get-ProtectedSids

    foreach ($sid in $Sids) {

        if ($protected -contains $sid) {
            Write-Log "Skipping $sid (protected: can't be removed)" "WARN"
            continue
        }

        foreach ($c in @($Certs)) {
            Revoke-PathAccess -Path (Get-CertKeyPath $c) -Sid $sid
            Write-Log "Removed      : $sid  <-  $($c.Thumbprint)"
        }
    }
}

# Logs each certificate and a table of who can use its key
function Write-CertKeyAccess {

    param([Parameter(Mandatory = $true)]$Certs)

    foreach ($c in @($Certs)) {

        Write-Log "$($c.Subject)  $($c.Thumbprint)  expires $($c.NotAfter.ToString('yyyy-MM-dd'))"

        Get-PathAccess (Get-CertKeyPath $c) |
            Format-Table -AutoSize | Out-String -Width 250 | Write-LogLines
    }
}

#--------------------------------------------------------------------------
# INSTALL / DELETE
#--------------------------------------------------------------------------

# The end-entity certificate inside a PFX (fails on a wrong password)
function Read-PfxCertificate {

    param(
        [Parameter(Mandatory = $true)][string]$PfxPath,
        [Parameter(Mandatory = $true)][SecureString]$Password
    )

    if (-not (Test-Path -LiteralPath $PfxPath -PathType Leaf)) {
        throw "PFX not found: $PfxPath"
    }

    $cert = (Get-PfxData -FilePath $PfxPath -Password $Password -ErrorAction Stop).EndEntityCertificates |
            Select-Object -First 1

    if (-not $cert) {
        throw "No certificate found in the PFX (or wrong password)."
    }

    return $cert
}

# Installs a PFX into the configured store with the key in the configured
# key storage provider, not exportable. Skips the import if this certificate
# is already installed. Returns the installed certificate.
function Import-PfxToStore {

    param(
        [Parameter(Mandatory = $true)][string]$PfxPath,
        [Parameter(Mandatory = $true)][SecureString]$Password,
        [Parameter(Mandatory = $true)][string]$Thumbprint
    )

    $policy   = Get-CertStorePolicy
    $certPath = "$($policy.StorePath)\$Thumbprint"

    if (Test-Path $certPath) {
        Write-Log "Certificate $Thumbprint is already installed; import skipped" "WARN"
    }
    else {
        # certutil uses the machine store unless -user is given
        $storeArgs = @()

        if ($policy.StoreLocation -eq "CurrentUser") {
            $storeArgs += "-user"
        }

        $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Password)

        try {
            $plain = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)

            $out = & certutil -f @storeArgs -p $plain -csp $policy.KeyProvider -importpfx $policy.StoreName "$PfxPath" NoExport 2>&1

            if ($LASTEXITCODE -ne 0) {
                throw "certutil import failed (check the password):`n$out"
            }
        }
        finally {
            $plain = $null
            [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
        }

        Write-Log "Imported $Thumbprint into $($policy.StoreLocation)\$($policy.StoreName)"
    }

    $cert = Get-Item $certPath -ErrorAction Stop

    if (-not $cert.HasPrivateKey) {
        throw "Installed certificate $Thumbprint has no private key."
    }

    # Read from the key itself: certutil's text output is translated
    # ("Fournisseur" on French Windows), so it can't be searched reliably
    $provider = (Get-CertKeyInfo $cert).Provider

    if ($provider -ne $policy.KeyProvider) {
        throw "Key of $Thumbprint is in '$provider', not in '$($policy.KeyProvider)'. It may have gone to the TPM."
    }

    Write-Log "Key provider: $provider"

    return $cert
}

# Deletes a certificate from the configured store with its private key
function Remove-StoreCert {

    param([Parameter(Mandatory = $true)][string]$Thumbprint)

    Remove-Item "$((Get-CertStorePolicy).StorePath)\$Thumbprint" -DeleteKey -ErrorAction Stop

    Write-Log "Deleted certificate $Thumbprint"
}

Export-ModuleMember -Function `
    Set-CertStorePolicy,
    Get-StoreCert,
    Find-CertByThumbprint,
    Get-CertExpiry,
    Get-CertKeyPath,
    Get-CertKeyReaderSids,
    Grant-CertKeyReader,
    Revoke-CertKeyReader,
    Write-CertKeyAccess,
    Read-PfxCertificate,
    Import-PfxToStore,
    Remove-StoreCert
