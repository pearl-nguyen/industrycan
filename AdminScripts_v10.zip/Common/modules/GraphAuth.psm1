#--------------------------------------------------------------------------
# GraphAuth.psm1
#   App-only Microsoft Graph authentication with a certificate, driven by
#   the shared Entra config (Common\config\EntraApp.psd1).
#   Used by SharePoint upload/download, email, certificate checks, ...
#   The Graph endpoint (GraphBaseUrl) comes from the same config; other
#   modules get it with Get-GraphBaseUrl after Connect-AppGraph.
#   Requires ConfigHelpers.psm1 to be imported by the calling script.
#--------------------------------------------------------------------------

$script:EntraRequired = @("GraphBaseUrl", "TenantId", "ClientId", "Thumbprint")

# Set by Connect-AppGraph
$script:GraphBaseUrl = $null

# Loads the Entra config and connects to Graph with the certificate.
# Certificate checks (presence, expiry warnings) belong to a separate script.
# Returns safe connection info (no secrets) for logging.
function Connect-AppGraph {

    param(
        [Parameter(Mandatory = $true)]
        [string]$EntraConfigPath
    )

    $entra = Import-ConfigFile -Path $EntraConfigPath -Required $script:EntraRequired

    # Tolerates a thumbprint pasted with spaces or the certificate dialog's
    # invisible character; a wrong length fails here with a clear message
    $thumbprint = ConvertTo-CleanThumbprint $entra.Thumbprint

    $script:GraphBaseUrl = $entra.GraphBaseUrl.TrimEnd('/')

    Import-Module Microsoft.Graph.Authentication -ErrorAction Stop

    Connect-MgGraph `
        -TenantId $entra.TenantId `
        -ClientId $entra.ClientId `
        -CertificateThumbprint $thumbprint `
        -NoWelcome `
        -ErrorAction Stop

    return [pscustomobject]@{
        TenantId = $entra.TenantId
        ClientId = $entra.ClientId
    }
}

# Graph endpoint from the Entra config (e.g. https://graph.microsoft.com/v1.0)
function Get-GraphBaseUrl {

    if (-not $script:GraphBaseUrl) {
        throw "Graph endpoint not set: call Connect-AppGraph first."
    }

    return $script:GraphBaseUrl
}

# Safe to call even if never connected or the Graph module is not loaded
function Disconnect-AppGraph {

    try {
        if (Get-Command Disconnect-MgGraph -ErrorAction SilentlyContinue) {
            Disconnect-MgGraph -ErrorAction SilentlyContinue | Out-Null
        }
    }
    catch {
        # Nothing to clean up
    }
}

Export-ModuleMember -Function `
    Connect-AppGraph,
    Get-GraphBaseUrl,
    Disconnect-AppGraph
