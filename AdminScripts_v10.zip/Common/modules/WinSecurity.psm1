#--------------------------------------------------------------------------
# WinSecurity.psm1
#   Windows identity and file-permission helpers:
#     - elevation check, current user
#     - SIDs from Entra object IDs, UPNs, or a mix (Resolve-SidList)
#     - read / set / grant / revoke permissions on a file or folder (icacls)
#   Used by DpapiSecret.psm1 (secret files) and CertStore.psm1 (private keys).
#   Requires Logging.psm1 to be imported by the calling script.
#--------------------------------------------------------------------------

# SIDs that always keep full control and can never be removed (prevents
# lock-out): AccessControl.ProtectedSids in Common\config\EntraApp.psd1,
# set by the script with Set-ProtectedSids. Until then, every function that
# changes permissions refuses to run.
$script:ProtectedSids = $null

#--------------------------------------------------------------------------
# IDENTITY
#--------------------------------------------------------------------------

function Set-ProtectedSids {

    param([Parameter(Mandatory = $true)][string[]]$Sids)

    $clean = @($Sids | Where-Object { $_ } | ForEach-Object { $_.Trim().ToUpperInvariant() })

    if ($clean.Count -eq 0) {
        throw "ProtectedSids is empty: at least Administrators must keep access."
    }

    foreach ($sid in $clean) {
        if ($sid -notmatch '^S-1(-\d+)+$') {
            throw "Invalid protected SID '$sid'."
        }
    }

    $script:ProtectedSids = $clean
}

function Get-ProtectedSids {

    if (-not $script:ProtectedSids) {
        throw "Protected SIDs not set: the script must call Set-ProtectedSids (AccessControl.ProtectedSids) first."
    }

    return $script:ProtectedSids
}

function Get-CurrentUserName {
    return [Security.Principal.WindowsIdentity]::GetCurrent().Name
}

function Assert-Elevated {

    $p = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()

    if (-not $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw "This action needs an elevated PowerShell (Run with elevated access)."
    }
}

# Entra object ID (user or group) -> the SID Windows uses for it (S-1-12-1-...)
function ConvertTo-EntraSid {

    param([Parameter(Mandatory = $true)][string]$ObjectId)

    $b = ([guid]$ObjectId).ToByteArray()

    return "S-1-12-1-{0}-{1}-{2}-{3}" -f `
        [BitConverter]::ToUInt32($b, 0), [BitConverter]::ToUInt32($b, 4),
        [BitConverter]::ToUInt32($b, 8), [BitConverter]::ToUInt32($b, 12)
}

# UPN -> SID. Only works for people who have signed in to this machine.
function Resolve-UpnToSid {

    param([Parameter(Mandatory = $true)][string]$Upn)

    try {
        return ([Security.Principal.NTAccount]"AzureAD\$Upn").Translate([Security.Principal.SecurityIdentifier]).Value
    }
    catch {
        throw "Cannot resolve '$Upn'. Use their Entra Object ID, or (to remove) the SID shown by the access list."
    }
}

# One de-duplicated SID list from SIDs, Entra object IDs and UPNs.
# Everything is checked here, before any change is made: a mistyped SID,
# object ID or UPN stops the run with nothing changed.
function Resolve-SidList {

    param(
        [string[]]$Sids      = @(),
        [string[]]$ObjectIds = @(),
        [string[]]$Upns      = @()
    )

    # powershell.exe -File passes "-ReaderSids a,b" as one string "a,b":
    # split on commas, semicolons and spaces so both calling styles work
    $split = {
        param([string[]]$Values)
        @($Values | ForEach-Object { $_ -split '[,;\s]+' } | Where-Object { $_ })
    }

    $Sids      = & $split $Sids
    $ObjectIds = & $split $ObjectIds
    $Upns      = & $split $Upns

    $out = @()

    foreach ($sid in $Sids) {

        $sid = $sid.Trim()

        if ($sid -notmatch '^[Ss]-1(-\d+)+$') {
            throw "Invalid SID '$sid': expected a value like S-1-12-1-... or S-1-5-21-..."
        }

        $out += $sid.ToUpperInvariant()
    }
    $out += @($ObjectIds | Where-Object { $_ } | ForEach-Object { ConvertTo-EntraSid $_ })
    $out += @($Upns      | Where-Object { $_ } | ForEach-Object { Resolve-UpnToSid $_ })

    return @($out | Where-Object { $_ } | Select-Object -Unique)
}

# SID -> account name, or $null when unknown (deleted, never signed in here)
function Get-AccountName {

    param([Parameter(Mandatory = $true)][string]$Sid)

    try {
        return ([Security.Principal.SecurityIdentifier]$Sid).Translate([Security.Principal.NTAccount]).Value
    }
    catch {
        return $null
    }
}

#--------------------------------------------------------------------------
# FILE PERMISSIONS
#--------------------------------------------------------------------------

# One object per access rule: Name, SID, Rights, Type
function Get-PathAccess {

    param([Parameter(Mandatory = $true)][string]$Path)

    (Get-Acl -LiteralPath $Path -ErrorAction Stop).Access | ForEach-Object {

        # Kept in a variable: inside catch, $_ is the error, not the rule
        $rule = $_

        $sid = try { $rule.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value }
               catch { "$($rule.IdentityReference)" }

        $name = Get-AccountName $sid

        [pscustomobject]@{
            Name   = if ($name) { $name } else { "(unknown - left or never signed in here)" }
            SID    = $sid
            Rights = $rule.FileSystemRights
            Type   = $rule.AccessControlType
        }
    }
}

# SIDs allowed on a path whose SID starts with one of $Prefixes, e.g.
# "S-1-12-1-" (Entra users/groups) and "S-1-5-21-" (domain/local accounts),
# which leaves out built-in accounts
function Get-PathReaderSids {

    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string[]]$Prefixes
    )

    return @(Get-PathAccess $Path |
             Where-Object {
                 $sid = $_.SID
                 "$($_.Type)" -eq "Allow" -and ($Prefixes | Where-Object { $sid.StartsWith($_, [StringComparison]::OrdinalIgnoreCase) })
             } |
             ForEach-Object { $_.SID } |
             Select-Object -Unique)
}

# Replaces all permissions: removes inherited ones, gives the protected SIDs
# (Administrators, SYSTEM) full control, and the given SIDs read-only.
# -Container: rules also apply to files/folders created inside (a folder).
function Set-PathAccess {

    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [string[]]$ReadSids = @(),
        [switch]$Container
    )

    $inherit = if ($Container) { "(OI)(CI)" } else { "" }

    $grants = @(Get-ProtectedSids | ForEach-Object { "*$($_):${inherit}F" }) +
              @($ReadSids | Where-Object { $_ } | Select-Object -Unique | ForEach-Object { "*$($_):${inherit}R" })

    $r = & icacls "$Path" /inheritance:r /grant $grants 2>&1

    if ($LASTEXITCODE -ne 0) {
        throw "Setting permissions on $Path failed:`n$r"
    }
}

function Grant-PathRead {

    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Sid
    )

    $r = & icacls "$Path" /grant "*$($Sid):R" 2>&1

    if ($LASTEXITCODE -ne 0) {
        throw "Granting read to $Sid on $Path failed:`n$r"
    }
}

# Removes every rule for a SID. Protected SIDs are refused.
function Revoke-PathAccess {

    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Sid
    )

    if ((Get-ProtectedSids) -contains $Sid.ToUpperInvariant()) {
        throw "Refusing to remove protected SID $Sid from $Path"
    }

    $r = & icacls "$Path" /remove "*$Sid" 2>&1

    if ($LASTEXITCODE -ne 0) {
        throw "Removing $Sid from $Path failed:`n$r"
    }
}

Export-ModuleMember -Function `
    Set-ProtectedSids,
    Get-ProtectedSids,
    Get-CurrentUserName,
    Assert-Elevated,
    ConvertTo-EntraSid,
    Resolve-UpnToSid,
    Resolve-SidList,
    Get-AccountName,
    Get-PathAccess,
    Get-PathReaderSids,
    Set-PathAccess,
    Grant-PathRead,
    Revoke-PathAccess
