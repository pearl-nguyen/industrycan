#--------------------------------------------------------------------------
# GraphMail.psm1
#   Sends email through Microsoft Graph as a mailbox (e.g. a no-reply
#   shared mailbox), using the app's own identity.
#
#     Send-GraphMail -From -To [-Cc] -Subject -HtmlBody
#
#   The Entra app needs the Mail.Send application permission (admin
#   consent); an Exchange application access policy should limit it to the
#   sending mailbox.
#   Requires Logging.psm1, HttpHelpers.psm1 (retries, throttling) and
#   GraphAuth.psm1 (Connect-AppGraph first) to be imported by the caller.
#--------------------------------------------------------------------------

# Address rule: name@domain.tld; the name may hold letters, digits and
# _ % + ' - (dots between, not doubled or at the ends). The same rule is
# in SendJobEmail.ps1's -To / -Cc parameter checks: keep them in sync.
$script:EmailPattern = '^[A-Za-z0-9_%+''-]+(\.[A-Za-z0-9_%+''-]+)*@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}$'

function Test-EmailAddress {

    param([string]$Address)

    return ($Address -match $script:EmailPattern)
}

# Splits "a,b; c" values into single addresses, trimmed, without
# duplicates (case-insensitive) and without the -Exclude addresses
function ConvertTo-EmailList {

    param(
        [string[]]$Addresses,
        [string[]]$Exclude = @()
    )

    $seen = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)

    foreach ($e in @($Exclude)) {
        if ($e) { [void]$seen.Add($e.Trim()) }
    }

    $result = New-Object System.Collections.Generic.List[string]

    foreach ($value in @($Addresses)) {
        foreach ($a in ([string]$value -split '[,;\s]+')) {
            if ($a -and $seen.Add($a)) {
                $result.Add($a)
            }
        }
    }

    return $result.ToArray()
}

function ConvertTo-GraphRecipients {

    param([string[]]$Addresses)

    return @($Addresses |
             Where-Object { -not [string]::IsNullOrWhiteSpace($_) } |
             ForEach-Object { @{ emailAddress = @{ address = $_.Trim() } } })
}

# Sends one message. Retries temporary failures (throttling honored);
# 400-level errors other than 429 are not retried. Throws if it can't send.
function Send-GraphMail {

    param(
        [Parameter(Mandatory = $true)][string]$From,
        [Parameter(Mandatory = $true)][string[]]$To,
        [string[]]$Cc = @(),
        [Parameter(Mandatory = $true)][string]$Subject,
        [Parameter(Mandatory = $true)][string]$HtmlBody,
        [bool]$SaveToSentItems = $false,
        [int]$MaxRetries = 3,
        [int]$BaseDelay = 5
    )

    # @(...): a function returning one item returns it unwrapped, which
    # would serialize as a JSON object instead of the list Graph requires
    $toList = @(ConvertTo-GraphRecipients $To)
    $ccList = @(ConvertTo-GraphRecipients $Cc)

    if ($toList.Count -eq 0) {
        throw "No recipients."
    }

    $message = @{
        subject      = $Subject
        body         = @{ contentType = "HTML"; content = $HtmlBody }
        toRecipients = [object[]]$toList
    }

    if ($ccList.Count -gt 0) {
        $message.ccRecipients = [object[]]$ccList
    }

    # JSON as a string, the body form used for every Graph POST/PATCH in
    # these modules (Invoke-MgGraphRequest documents no other)
    $body = @{ message = $message; saveToSentItems = $SaveToSentItems } | ConvertTo-Json -Depth 8

    $uri = "$(Get-GraphBaseUrl)/users/$([uri]::EscapeDataString($From))/sendMail"

    Invoke-WithRetry `
        -Activity "Send email" `
        -MaxRetries $MaxRetries `
        -BaseDelay $BaseDelay `
        -ShouldRetry {
            param($m)
            # Bad request, forbidden, not found...: the same request would fail again
            (Test-IsThrottleError $m) -or -not ($m -match '\(4\d\d\)|success: (BadRequest|Unauthorized|Forbidden|NotFound)')
        } `
        -ScriptBlock {
            Invoke-MgGraphRequest `
                -Method POST `
                -Uri $uri `
                -Body $body `
                -ContentType "application/json" `
                -ErrorAction Stop | Out-Null
        }

    Write-Log "Email sent from $From to $(@($To) -join ', ')$(if ($ccList.Count -gt 0) { " (cc $(@($Cc) -join ', '))" })"
}

Export-ModuleMember -Function Send-GraphMail, Test-EmailAddress, ConvertTo-EmailList
