#--------------------------------------------------------------------------
# FileHelpers.psm1
#   Local file helpers for writing a result safely:
#     New-PartialPath        temporary name next to the final file
#     Move-FileIntoPlace     put a finished file in place in one step
#     Test-IsLocalWriteError access denied / disk full (no point retrying)
#   Used by SpTransfer.psm1 (downloads) and Helpers\ConvertToExcel.ps1.
#   No dependencies on other modules.
#--------------------------------------------------------------------------

# "<Destination>.<8 hex>.partial": same folder as the destination, so the
# final move stays on one volume and is a rename, not a copy
function New-PartialPath {

    param([Parameter(Mandatory = $true)][string]$Destination)

    return "$Destination.$([guid]::NewGuid().ToString('N').Substring(0, 8)).partial"
}

# True for local file system errors that will fail the same way on every
# retry: access denied, disk full. Network errors (also IOExceptions) are
# not matched.
function Test-IsLocalWriteError {

    param($Exception)

    # 0x80070070 ERROR_DISK_FULL, 0x80070027 ERROR_HANDLE_DISK_FULL
    $diskFull = @(-2147024784, -2147024857)

    $e = $Exception

    while ($e) {

        if ($e -is [System.UnauthorizedAccessException]) {
            return $true
        }

        if ($e -is [System.IO.IOException] -and $diskFull -contains $e.HResult) {
            return $true
        }

        $e = $e.InnerException
    }

    return $false
}

# Puts a validated file in place in one step:
#   - destination exists : File.Replace (atomic swap on NTFS; the old file
#                          is never deleted before the new one is in place)
#   - otherwise          : File.Move (fails if a file appeared meanwhile)
function Move-FileIntoPlace {

    param(
        [Parameter(Mandatory = $true)][string]$Source,
        [Parameter(Mandatory = $true)][string]$Destination,
        [bool]$Overwrite = $true
    )

    if (Test-Path -LiteralPath $Destination -PathType Leaf) {

        if (-not $Overwrite) {
            throw [System.IO.IOException]::new("Destination already exists: $Destination")
        }

        [System.IO.File]::Replace($Source, $Destination, [NullString]::Value, $true)
    }
    else {
        [System.IO.File]::Move($Source, $Destination)
    }
}

Export-ModuleMember -Function `
    New-PartialPath,
    Move-FileIntoPlace,
    Test-IsLocalWriteError
