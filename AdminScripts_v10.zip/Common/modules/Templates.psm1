#--------------------------------------------------------------------------
# Templates.psm1
#   Fills text templates (HTML email bodies, subjects, messages).
#
#   Template syntax:
#     {{Name}}                   replaced by the value of Name
#     {{#Name}} ... {{/Name}}    section kept only when Name has a value
#                                (the {{#..}} and {{/..}} markers are removed)
#
#   With -Html, values are HTML-encoded (& < > " ') so text like a file
#   path or a job name can't break the page. A placeholder with no value is
#   removed and logged as a warning, so a typo in a template never stops a
#   notification from going out.
#
#   Functions:
#     Import-Template  -Path            reads a template file (UTF-8)
#     Expand-Template  -Template -Values [-Html [-RawKeys ...]]
#   Requires Logging.psm1 to be imported by the calling script.
#--------------------------------------------------------------------------

$script:SectionPattern     = '(?s)\{\{#([A-Za-z0-9_]+)\}\}(.*?)\{\{/\1\}\}'
$script:PlaceholderPattern = '\{\{([A-Za-z0-9_]+)\}\}'

function Import-Template {

    param([Parameter(Mandatory = $true)][string]$Path)

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "Template not found: $Path"
    }

    return [IO.File]::ReadAllText((Resolve-Path -LiteralPath $Path -ErrorAction Stop).ProviderPath, [Text.Encoding]::UTF8)
}

function Expand-Template {

    param(
        [Parameter(Mandatory = $true)][AllowEmptyString()][string]$Template,
        [Parameter(Mandatory = $true)][System.Collections.IDictionary]$Values,
        [switch]$Html,

        # With -Html: values that are already HTML (e.g. rows built from
        # another template) and must not be encoded again
        [string[]]$RawKeys = @()
    )

    $lookup = @{}

    foreach ($key in $Values.Keys) {
        $lookup[[string]$key] = $Values[$key]
    }

    # Sections first: keep the inside when the value is not empty
    $text = [regex]::Replace($Template, $script:SectionPattern, {
        param($m)
        $value = $lookup[$m.Groups[1].Value]
        if ($null -ne $value -and "$value" -ne "") { $m.Groups[2].Value } else { "" }
    })

    $missing = New-Object System.Collections.Generic.List[string]

    $text = [regex]::Replace($text, $script:PlaceholderPattern, {
        param($m)
        $name = $m.Groups[1].Value

        if (-not $lookup.ContainsKey($name)) {
            if (-not $missing.Contains($name)) { $missing.Add($name) }
            return ""
        }

        $value = "$($lookup[$name])"

        if ($Html -and $RawKeys -notcontains $name) {
            return [System.Net.WebUtility]::HtmlEncode($value)
        }

        return $value
    })

    foreach ($name in $missing) {
        Write-Log "Template placeholder {{$name}} has no value; left empty" "WARN"
    }

    return $text
}

Export-ModuleMember -Function `
    Import-Template,
    Expand-Template
