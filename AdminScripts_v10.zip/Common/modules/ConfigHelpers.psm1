#--------------------------------------------------------------------------
# ConfigHelpers.psm1
#   Loading .psd1 config files, checking required settings (nested keys
#   with dots, e.g. "ExitCodes.Success"), resolving paths written relative
#   to the config file, and cleaning certificate thumbprints.
#   No dependencies on other modules.
#--------------------------------------------------------------------------

# Returns the value at a dotted key ("Section.Name"), or $null if missing
function Get-ConfigValue {

    param(
        [Parameter(Mandatory = $true)]
        [System.Collections.IDictionary]$Config,

        [Parameter(Mandatory = $true)]
        [string]$Key
    )

    $node = $Config

    foreach ($part in ($Key -split '\.')) {

        if ($node -isnot [System.Collections.IDictionary] -or -not $node.Contains($part)) {
            return $null
        }

        $node = $node[$part]
    }

    return $node
}

# Loads a .psd1 and throws one message listing every required key that is
# missing or empty
function Import-ConfigFile {

    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,

        [string[]]$Required = @()
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "Config file not found: $Path"
    }

    $fullPath = (Resolve-Path -LiteralPath $Path -ErrorAction Stop).Path
    $config   = Import-PowerShellDataFile -LiteralPath $fullPath -ErrorAction Stop

    $missing = @()

    foreach ($key in $Required) {

        $value = Get-ConfigValue -Config $config -Key $key

        if ($null -eq $value -or
            ($value -is [string] -and [string]::IsNullOrWhiteSpace($value)) -or
            (@($value).Count -eq 0)) {
            $missing += $key
        }
    }

    if ($missing.Count -gt 0) {
        throw "Missing setting(s) in ${fullPath}: $($missing -join ', ')"
    }

    return $config
}

# Resolves a path written in a config file. Relative paths are taken
# relative to the config file's folder, not the current directory.
function Resolve-ConfigPath {

    param(
        [Parameter(Mandatory = $true)]
        [string]$ConfigFile,

        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    if ([System.IO.Path]::IsPathRooted($Path)) {
        return [System.IO.Path]::GetFullPath($Path)
    }

    $baseFolder = Split-Path -Path (Resolve-Path -LiteralPath $ConfigFile -ErrorAction Stop).Path -Parent

    return [System.IO.Path]::GetFullPath((Join-Path -Path $baseFolder -ChildPath $Path))
}

# Certificate thumbprint as Windows uses it: 40 hex characters, uppercase.
# A thumbprint copied from the Windows certificate dialog usually carries
# spaces and an invisible character at the start; they are removed here.
# Throws when what's left is not a thumbprint.
function ConvertTo-CleanThumbprint {

    param([Parameter(Mandatory = $true)][AllowEmptyString()][string]$Thumbprint)

    $clean = ($Thumbprint -replace '[^0-9A-Fa-f]', '').ToUpperInvariant()

    if ($clean.Length -ne 40) {
        throw "Invalid certificate thumbprint '$Thumbprint': expected 40 hexadecimal characters, found $($clean.Length)."
    }

    return $clean
}

Export-ModuleMember -Function `
    Get-ConfigValue,
    Import-ConfigFile,
    Resolve-ConfigPath,
    ConvertTo-CleanThumbprint
