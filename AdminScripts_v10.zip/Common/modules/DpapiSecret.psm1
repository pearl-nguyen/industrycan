#--------------------------------------------------------------------------
# DpapiSecret.psm1
#   Store and retrieve passwords on THIS machine using Windows DPAPI
#   (LocalMachine scope).
#
#   Settings come from the Secrets section of Common\config\EntraApp.psd1,
#   passed with -ConfigPath:
#       Secrets = @{
#           Folder  = "..\..\Security\secrets"   # absolute, or relative to the config file
#           Entropy = "STS-SMS-Ops-DPAPI-v1"     # NEVER change once secrets are saved
#       }
#
#   - Each secret is one encrypted file: <Folder>\<Name>.bin
#   - Decryption only works on this machine; a copied file is useless elsewhere.
#   - Who can read a secret is controlled by the file's permissions:
#     always Administrators + SYSTEM, plus any readers you grant.
#
#   Functions:
#     Save-DpapiSecret    -ConfigPath <psd1> -Name <name> [-ReaderSids ...] [-ReaderObjectIds ...]  (elevated)
#     Get-DpapiSecret     -ConfigPath <psd1> -Name <name> [-AsPlainText]
#     Get-DpapiSecretList -ConfigPath <psd1>   returns Name, Modified, Readers         (elevated)
#     Remove-DpapiSecret  -ConfigPath <psd1> -Name <name>                               (elevated)
#
#   Modules the calling script must import first:
#     Get-DpapiSecret (read a secret, e.g. in a job script): ConfigHelpers.psm1
#     Save / List / Remove (Security\SaveSecret.ps1): also Logging.psm1 and
#     WinSecurity.psm1
#
#   Usage in a script:
#     $cfg = Join-Path $RootFolder "Common\config\EntraApp.psd1"
#     $pw  = Get-DpapiSecret -ConfigPath $cfg -Name OracleExport -AsPlainText
#--------------------------------------------------------------------------

Add-Type -AssemblyName System.Security -ErrorAction Stop

#--------------------------------------------------------------------------
# HELPERS
#--------------------------------------------------------------------------

function Read-DpapiConfig {

    param([Parameter(Mandatory = $true)][string]$ConfigPath)

    $cfg = Import-ConfigFile -Path $ConfigPath -Required "Secrets.Folder", "Secrets.Entropy"

    return [pscustomobject]@{
        Folder  = Resolve-ConfigPath -ConfigFile $ConfigPath -Path $cfg.Secrets.Folder
        Entropy = [Text.Encoding]::UTF8.GetBytes($cfg.Secrets.Entropy)
    }
}

function Test-SecretName {

    param([string]$Name)

    if ($Name -notmatch '^[A-Za-z0-9._-]+$') {
        throw "Invalid secret name '$Name'. Use letters, digits, dot, dash, underscore."
    }
}

function ConvertFrom-SecureStringPlain {

    param([SecureString]$Secure)

    $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Secure)

    try {
        return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
    }
    finally {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
    }
}

function Get-SecretPath {

    param([string]$Name, [string]$Folder)

    Test-SecretName $Name

    return Join-Path $Folder "$Name.bin"
}

function Initialize-SecretFolder {

    param([string]$Folder)

    if (Test-Path -LiteralPath $Folder -PathType Container) {
        return
    }

    New-Item -Path $Folder -ItemType Directory -Force -ErrorAction Stop | Out-Null

    # Folder: Administrators + SYSTEM only. Readers get access per file.
    Set-PathAccess -Path $Folder -Container

    Write-Log "Secrets folder created: $Folder (Administrators and SYSTEM only)"
}

#--------------------------------------------------------------------------
# PUBLIC FUNCTIONS
#--------------------------------------------------------------------------

# Encrypts a password with DPAPI (LocalMachine) and saves it as
# <Folder>\<Name>.bin. Prompts twice when -Value is not given.
# Saving again with the same name replaces the value and resets its readers.
function Save-DpapiSecret {

    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$ConfigPath,
        [Parameter(Mandatory = $true)][string]$Name,
        [SecureString]$Value,
        [string[]]$ReaderSids      = @(),
        [string[]]$ReaderObjectIds = @()
    )

    Assert-Elevated

    $cfg  = Read-DpapiConfig $ConfigPath
    $path = Get-SecretPath $Name $cfg.Folder

    if (-not $Value) {

        $v1 = Read-Host "Value for '$Name'" -AsSecureString
        $v2 = Read-Host "Confirm value for '$Name'" -AsSecureString

        if ((ConvertFrom-SecureStringPlain $v1) -cne (ConvertFrom-SecureStringPlain $v2)) {
            throw "Values do not match. Nothing saved."
        }

        $Value = $v1
    }

    $plain = ConvertFrom-SecureStringPlain $Value

    try {
        $enc = [Security.Cryptography.ProtectedData]::Protect(
            [Text.Encoding]::UTF8.GetBytes($plain), $cfg.Entropy, 'LocalMachine')
    }
    finally {
        $plain = $null
    }

    Initialize-SecretFolder $cfg.Folder

    # Replacing a secret: delete the old file first, so the new value never
    # sits in a file that still has the old readers. The new file starts
    # with the folder's permissions (Administrators + SYSTEM only).
    if (Test-Path -LiteralPath $path -PathType Leaf) {
        Remove-Item -LiteralPath $path -Force -ErrorAction Stop
    }

    [IO.File]::WriteAllBytes($path, $enc)

    # File permissions: reset, then Administrators + SYSTEM full, readers read-only
    $readers = Resolve-SidList -Sids $ReaderSids -ObjectIds $ReaderObjectIds

    try {
        Set-PathAccess -Path $path -ReadSids $readers
    }
    catch {
        throw "Saved (readable by Administrators and SYSTEM only), but $($_.Exception.Message)"
    }

    Write-Log "Saved secret '$Name' -> $path"

    if ($readers.Count -gt 0) {
        Write-Log "Readers: $($readers -join ', ')"
    }
    else {
        Write-Log "Readers: Administrators and SYSTEM only"
    }
}

# Returns a saved secret as a SecureString (default) or plain text (-AsPlainText)
function Get-DpapiSecret {

    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$ConfigPath,
        [Parameter(Mandatory = $true)][string]$Name,
        [switch]$AsPlainText
    )

    $cfg  = Read-DpapiConfig $ConfigPath
    $path = Get-SecretPath $Name $cfg.Folder

    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        throw "Secret '$Name' not found at $path (or you don't have access). Save it with: Security\SaveSecret.ps1 -Name $Name"
    }

    # Reading and decrypting fail for different reasons: report them apart
    try {
        $bytes = [IO.File]::ReadAllBytes($path)
    }
    catch {
        throw "Cannot read secret '$Name' at ${path}: $($_.Exception.Message)"
    }

    try {
        $plain = [Text.Encoding]::UTF8.GetString(
            [Security.Cryptography.ProtectedData]::Unprotect($bytes, $cfg.Entropy, 'LocalMachine'))
    }
    catch {
        throw "Cannot decrypt '$Name'. Was Secrets.Entropy in $ConfigPath changed, or was the file copied from another machine?"
    }

    if ($AsPlainText) {
        return $plain
    }

    $sec   = ConvertTo-SecureString $plain -AsPlainText -Force
    $plain = $null

    return $sec
}

# Returns one object per saved secret: Name, Modified, Readers.
# Logs the folder; returns nothing when it doesn't exist yet.
function Get-DpapiSecretList {

    [CmdletBinding()]
    param([Parameter(Mandatory = $true)][string]$ConfigPath)

    Assert-Elevated

    $cfg = Read-DpapiConfig $ConfigPath

    if (-not (Test-Path -LiteralPath $cfg.Folder -PathType Container)) {
        Write-Log "No secrets folder yet ($($cfg.Folder))"
        return
    }

    Write-Log "Secrets folder: $($cfg.Folder)"

    Get-ChildItem -LiteralPath $cfg.Folder -Filter *.bin -File -ErrorAction Stop | ForEach-Object {

        $readers = Get-PathAccess $_.FullName | ForEach-Object {
            if ($_.Name -like "(unknown*") { $_.SID } else { $_.Name }
        }

        [pscustomobject]@{
            Name     = $_.BaseName
            Modified = $_.LastWriteTime
            Readers  = ($readers -join '; ')
        }
    }
}

# Deletes a saved secret
function Remove-DpapiSecret {

    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$ConfigPath,
        [Parameter(Mandatory = $true)][string]$Name
    )

    Assert-Elevated

    $cfg  = Read-DpapiConfig $ConfigPath
    $path = Get-SecretPath $Name $cfg.Folder

    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        throw "Secret '$Name' not found at $path"
    }

    Remove-Item -LiteralPath $path -Force -ErrorAction Stop

    Write-Log "Removed secret '$Name'"
}

Export-ModuleMember -Function `
    Save-DpapiSecret,
    Get-DpapiSecret,
    Get-DpapiSecretList,
    Remove-DpapiSecret
