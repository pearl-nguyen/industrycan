<#
    DownloadFromSharePoint.ps1

    Downloads from a SharePoint Online document library. What is downloaded
    depends on -RemotePath:
      a file   : that file
      a folder : -DownloadMode All (default) : every file in the folder
                 -DownloadMode Latest        : the most recently modified file
                 Top level only, no subfolders; optional -Filter such as
                 "*.csv" (default: all files).

  DESCRIPTION
    For each file:
    1. Skips the download if the local file is already identical
       (size + QuickXorHash)
    2. Streams the file to <name>.<id>.partial in the destination folder
       (fresh download URL and current metadata on every attempt)
    3. Validates size + QuickXorHash against SharePoint (a download returns
       the exact stored bytes, so this also holds for Office files)
    4. Sets the local modified time to SharePoint's
    5. Puts it in place in one step (atomic replace of an existing file)

    The destination never holds a partial or unvalidated file, and a failed
    download leaves an existing local file untouched. Throttling
    (Retry-After) is honored and failed downloads are retried. With
    -DownloadMode All, files are downloaded one at a time; failed files are
    retried over up to MaxPasses passes, and files still failing are left
    for the next run (exit PartialFailure), which skips the files already
    downloaded.

    The remote path is relative to the site's default document library.
    If it starts with the library's name ("Documents" or
    "Shared Documents") and isn't found, it is retried without that name.

    Logs : <LogFolder>\<LogFileName>.log
           (no -LogFolder: console only)

  PARAMETER CHECKS
    Parameters are checked when PowerShell binds them (before the script
    starts): a missing required parameter, a wrong value, a path that is
    not a full path (C:\... or \\server\...) or a bad path character stops
    the run with PowerShell's exit code 1 and a message on the console; no
    log is written. None of this script's own exit codes is 1, so 1 always
    means "bad parameters, nothing ran". Run jobs with -NonInteractive, or
    a missing required parameter makes PowerShell wait for typed input.
    Full paths are required because a scheduled task may start in
    C:\Windows\System32, where a relative path would point.

  EXAMPLES
    One file:
    powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File C:\Development\scripts\SharePoint\DownloadFromSharePoint.ps1 `
        -SiteName "smsfc" `
        -RemotePath "Mass Cancellation/test.xlsx" `
        -LocalFolder "C:\Development\data\in" `
        -LogFolder "C:\Development\logs\MassCancellation"

    All CSV files of a folder:
    powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File C:\Development\scripts\SharePoint\DownloadFromSharePoint.ps1 `
        -SiteName "smsfc" `
        -RemotePath "Mass Cancellation" `
        -Filter "*.csv" `
        -LocalFolder "C:\Development\data\in" `
        -LogFolder "C:\Development\logs\MassCancellation"

    Latest CSV in a folder, saved under a fixed name:
    powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File C:\Development\scripts\SharePoint\DownloadFromSharePoint.ps1 `
        -SiteName "smsfc" `
        -RemotePath "Mass Cancellation" `
        -DownloadMode Latest `
        -Filter "*.csv" `
        -LocalFolder "C:\Development\data\in" `
        -LocalFileName "latest.csv" `
        -LogFolder "C:\Development\logs\MassCancellation"

    Options:
        -LocalFileName "other.xlsx"   save under another name (no folders;
                                      not with a folder in DownloadMode All)
        -NoOverwrite                  fail (FileExists) if a different local file exists

  NOTES
    Same layout, modules and SharepointConfig.psd1 as Upload2SharePoint.ps1.
    The local folder must exist (a typo is reported, not silently created).
    Exit codes are defined in SharepointConfig.psd1 (ExitCodes).
    99 is also returned when the config itself could not be loaded.
#>

[CmdletBinding()]
param(
    # Site URL name (https://<host>/sites/<SiteName>)
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^[A-Za-z0-9._-]+$')]
    [string]$SiteName,

    # File or folder inside the default document library,
    # e.g. "Folder/Sub/file.xlsx" or "Folder/Sub"
    # Empty = the library root. Characters SharePoint refuses
    # (" * : < > ? |) are rejected.
    [Parameter(Mandatory = $true)]
    [AllowEmptyString()]
    [ValidatePattern('^[^"*:<>?|]*$')]
    [string]$RemotePath,

    # RemotePath is a folder: All = every file, Latest = newest file only.
    # Ignored when RemotePath is a file.
    [ValidateSet("All", "Latest")]
    [string]$DownloadMode = "All",

    # Folder only: file name filter, e.g. "*.csv". Empty (default) = all files.
    # Wildcards * ? allowed; no folder part.
    [ValidatePattern('^[^\\/:"<>|]*$')]
    [string]$Filter = "",

    [Parameter(Mandatory = $true)]
    [ValidatePattern('^([A-Za-z]:[\\/]|\\\\[^\\/]+[\\/])[^*?"<>|]*$')]
    [string]$LocalFolder,

    # Defaults to the remote file name. A plain file name (no folder).
    [ValidatePattern('^[^\\/:*?"<>|]*$')]
    [string]$LocalFileName,

    # <rootfolder>\logs\<jobname>, passed by the calling job.
    # Not given: no log file, all lines go to the console (standard output)
    [ValidatePattern('^(([A-Za-z]:[\\/]|\\\\[^\\/]+[\\/])[^*?"<>|]*)?$')]
    [string]$LogFolder,

    # Plain file name (no folder), without .log
    [ValidatePattern('^[^\\/:*?"<>|]*$')]
    [string]$LogFileName,

    # Default is to replace a different local file (after validation).
    # A switch (not [bool]) so it works from a batch file with -File.
    [switch]$NoOverwrite
)

$ErrorActionPreference = "Stop"

# Used until the config (and its ExitCodes) is loaded
$UnexpectedExitCode = 99

$RootFolder   = Split-Path $PSScriptRoot -Parent
$ModuleFolder = Join-Path $RootFolder "Common\modules"
$ConfigFile   = Join-Path $PSScriptRoot "SharepointConfig.psd1"
$Overwrite    = -not $NoOverwrite

$ConfigRequired = @(
    "EntraConfig",
    "SharePointHost",
    "MaxRetries",
    "BaseDelay",
    "MaxThrottleEvents",
    "MaxRetryAfter",
    "DownloadTimeoutMinutes",
    "DelayBetweenFiles",
    "MaxPasses",
    "PassDelay",
    "ExitCodes.Success",
    "ExitCodes.LocalPathNotFound",
    "ExitCodes.AuthFailed",
    "ExitCodes.SiteNotFound",
    "ExitCodes.FileExists",
    "ExitCodes.InvalidFileName",
    "ExitCodes.RemoteFileNotFound",
    "ExitCodes.DownloadFailed",
    "ExitCodes.LocalWriteFailed",
    "ExitCodes.PartialFailure",
    "ExitCodes.NeedsReview",
    "ExitCodes.InvalidParameter",
    "ExitCodes.SetupFailed",
    "ExitCodes.Unexpected"
)

$EntraRequired = @("TenantId", "ClientId", "Thumbprint")

#--------------------------------------------------------------------------
# BOOTSTRAP 1: LOGGING (nothing to log to yet -> console, exit 99)
#--------------------------------------------------------------------------

try {
    foreach ($module in @("Logging", "ScriptHelpers")) {
        Import-Module (Join-Path $ModuleFolder "$module.psm1") -Force -ErrorAction Stop
    }

    # No -LogFolder: console only ($logPath is $null)
    $logPath = Initialize-Log -LogFolder $LogFolder -LogFileName $LogFileName
}
catch {
    [Console]::Out.WriteLine("Bootstrap failed (logging): $($_.Exception.Message)")
    exit $UnexpectedExitCode
}

Write-ScriptStart -Title "Download started" -LogPath $logPath -LogFileName $LogFileName

#--------------------------------------------------------------------------
# BOOTSTRAP 2: MODULES AND CONFIG (exit codes not known yet -> exit 99)
#--------------------------------------------------------------------------

try {
    foreach ($module in @("ConfigHelpers", "HttpHelpers", "GraphAuth", "SpGraph", "FileValidation", "FileHelpers", "SpTransfer")) {
        Import-Module (Join-Path $ModuleFolder "$module.psm1") -Force -ErrorAction Stop
    }

    $Config = Import-ConfigFile -Path $ConfigFile -Required $ConfigRequired

    # From here on: Exit-Script "<reason>" uses ExitCodes from the config
    # and disconnects from Graph first
    Set-ScriptExit -ExitCodes $Config.ExitCodes -BeforeExit { Disconnect-AppGraph }
}
catch {
    Write-LogException $_ "Bootstrap failed"
    Exit-Script "Unexpected" -Code $UnexpectedExitCode
}

#--------------------------------------------------------------------------
# SAFETY NET
#--------------------------------------------------------------------------

# Safety net: any unexpected terminating error outside a try/catch is
# logged, disconnects from Graph and exits with ExitCodes.Unexpected
trap {
    Write-LogException $_ "Unexpected error"
    Exit-Script "Unexpected"
}

#--------------------------------------------------------------------------
# SETUP (config loaded -> SetupFailed)
#--------------------------------------------------------------------------

try {
    # Check the Entra config here so a missing/incomplete file is reported
    # as a setup problem, not an authentication failure
    $entraConfigPath = Resolve-ConfigPath -ConfigFile $ConfigFile -Path $Config.EntraConfig

    Import-ConfigFile -Path $entraConfigPath -Required $EntraRequired | Out-Null

    Set-ThrottlePolicy -MaxEvents $Config.MaxThrottleEvents -MaxRetryAfter $Config.MaxRetryAfter

    Write-Log "Config     : $ConfigFile"
    Write-Log "Entra      : $entraConfigPath"
}
catch {
    Write-LogException $_ "Setup failed"
    Exit-Script "SetupFailed"
}

#--------------------------------------------------------------------------
# PARAMETERS
#--------------------------------------------------------------------------

if (-not (Test-Path -LiteralPath $LocalFolder -PathType Container)) {
    Write-Log "Local folder not found: $LocalFolder" "ERROR"
    Exit-Script "LocalPathNotFound"
}

$LocalFolder = (Resolve-Path -LiteralPath $LocalFolder).Path

# A plain file name only, so the file can't land outside -LocalFolder
if (-not [string]::IsNullOrWhiteSpace($LocalFileName)) {

    $problem = Test-PlainFileName $LocalFileName

    if ($problem) {
        Write-Log "Invalid -LocalFileName '$LocalFileName': $problem" "ERROR"
        Exit-Script "InvalidFileName"
    }
}

if ([string]::IsNullOrWhiteSpace($Filter)) {
    $Filter = "*"
}

$remoteParts = @($RemotePath -split '[\\/]' | Where-Object { $_ -ne '' })

# An empty path would mean the whole library root: refuse it, in case a
# batch variable expanded to nothing
if ($remoteParts.Count -eq 0) {
    Write-Log "Remote path is empty" "ERROR"
    Exit-Script "RemoteFileNotFound"
}

Write-Log "Site name  : $SiteName"
Write-Log "Remote     : /$($remoteParts -join '/')"
Write-Log "Local      : $LocalFolder"
Write-Log "Overwrite  : $Overwrite"
Write-LogSeparator

#--------------------------------------------------------------------------
# AUTHENTICATION
#--------------------------------------------------------------------------

try {
    $connection = Connect-AppGraph -EntraConfigPath $entraConfigPath

    Write-Log "Graph authentication successful (client $($connection.ClientId))"
}
catch {
    Write-LogException $_
    Exit-Script "AuthFailed"
}

#--------------------------------------------------------------------------
# LOCATE SITE AND DEFAULT DOCUMENT LIBRARY
#--------------------------------------------------------------------------

try {
    $drive = Invoke-WithRetry `
        -Activity "Locate site" `
        -MaxRetries $Config.MaxRetries `
        -BaseDelay $Config.BaseDelay `
        -ShouldRetry { param($m) -not (Test-IsNotFoundError $m) } `
        -ScriptBlock { Get-SpDrive -SharePointHost $Config.SharePointHost -SiteName $SiteName }

    Write-Log "Site       : $($drive.SiteUrl)"
    Write-Log "Library    : $($drive.Name)"
}
catch {
    Write-LogException $_
    Exit-Script "SiteNotFound"
}

#--------------------------------------------------------------------------
# LOCATE REMOTE FILE OR FOLDER
#--------------------------------------------------------------------------

try {
    # Also handles a path that starts with the library name ("Shared Documents/...")
    $found       = Find-SpItem -Drive $drive -PathParts $remoteParts -Settings $Config
    $item        = $found.Item
    $remoteParts = $found.PathParts
}
catch {
    Write-LogException $_
    Exit-Script "Unexpected"
}

if (-not $item) {
    Write-Log "Remote path not found: /$($remoteParts -join '/')" "ERROR"
    Exit-Script "RemoteFileNotFound"
}

# Statuses worth another pass and a rerun (temporary). The others
# (FileExists, LocalWriteFailed) fail the same way until a person fixes them.
$RetryableStatuses = @("DownloadFailed")

if ($item.folder) {

    $FolderMode = $true

    Write-Log "Mode       : Folder, $DownloadMode (filter '$Filter')"

    # Several files can't share one local name
    if ($DownloadMode -eq "All" -and -not [string]::IsNullOrWhiteSpace($LocalFileName)) {
        Write-Log "-LocalFileName can't be used for a folder with -DownloadMode All" "ERROR"
        Exit-Script "InvalidParameter"
    }

    try {
        $children = Invoke-WithRetry `
            -Activity "List folder" `
            -MaxRetries $Config.MaxRetries `
            -BaseDelay $Config.BaseDelay `
            -ScriptBlock { Get-SpChildren -DriveId $drive.Id -FolderId $item.id }
    }
    catch {
        Write-LogException $_
        Exit-Script "Unexpected"
    }

    $candidates = @($children | Where-Object { $_.file -and $_.name -like $Filter } | Sort-Object { $_.name })

    Write-Log "Folder has $(@($children | Where-Object { $_.file }).Count) file(s), $($candidates.Count) matching '$Filter'"

    if ($candidates.Count -eq 0) {

        if ($DownloadMode -eq "Latest") {
            Write-Log "No file matching '$Filter' in /$($remoteParts -join '/')" "ERROR"
            Exit-Script "RemoteFileNotFound"
        }

        Write-Log "No files to download in /$($remoteParts -join '/') (filter '$Filter')" "WARN"
        Exit-Script "Success"
    }

    if ($DownloadMode -eq "Latest") {

        # Newest modified first; same time -> highest name, so the choice is stable
        $newest = $candidates |
            Sort-Object `
                @{ Expression = { ConvertTo-SpDateUtc $_.lastModifiedDateTime }; Descending = $true },
                @{ Expression = { $_.name }; Descending = $true } |
            Select-Object -First 1

        Write-Log "Newest     : $($newest.name) (modified $((ConvertTo-SpDateUtc $newest.lastModifiedDateTime).ToString('yyyy-MM-dd HH:mm:ss')) UTC)"

        $items = @($newest)
    }
    else {
        $items = $candidates
    }
}
else {

    $FolderMode = $false

    Write-Log "Mode       : File"

    if ($PSBoundParameters.ContainsKey("DownloadMode")) {
        Write-Log "Remote path is a file; -DownloadMode ignored" "WARN"
    }

    if ($Filter -ne "*") {
        Write-Log "Remote path is a file; -Filter ignored" "WARN"
    }

    $items = @($item)
}

# Several files only with a folder in DownloadMode All
$MultiMode = ($FolderMode -and $DownloadMode -eq "All")

Write-Log "Files      : $($items.Count)"

#--------------------------------------------------------------------------
# DOWNLOAD (one file at a time; extra passes for failed files in mode All)
#--------------------------------------------------------------------------

# file name -> result; files never attempted have no entry
$results   = [ordered]@{}
$pending   = $items
$stopped   = $false
$maxPasses = if ($MultiMode) { [math]::Max(1, [int]$Config.MaxPasses) } else { 1 }

for ($pass = 1; $pass -le $maxPasses; $pass++) {

    if ($pass -gt 1) {

        $pending = @($items | Where-Object {
            $results.Contains($_.name) -and
            $results[$_.name].Status -in $RetryableStatuses
        })

        if ($pending.Count -eq 0) {
            break
        }

        # Check before waiting: no point waiting if we are stopping anyway
        if (Test-ThrottleLimitReached) {
            $stopped = $true
            break
        }

        Write-LogSeparator
        Write-Log "Waiting $($Config.PassDelay) seconds before pass $pass" "WARN"
        Start-Sleep -Seconds $Config.PassDelay
    }

    if ($MultiMode) {
        Write-LogSeparator
        Write-Log "Pass $pass of ${maxPasses}: $($pending.Count) file(s)"
    }

    for ($i = 0; $i -lt $pending.Count; $i++) {

        $file = $pending[$i]

        # Circuit breaker: SharePoint keeps throttling us, stop cleanly and
        # leave the remaining files for the next run
        if (Test-ThrottleLimitReached) {
            $stopped = $true
            break
        }

        $name = if (-not $MultiMode -and -not [string]::IsNullOrWhiteSpace($LocalFileName)) { $LocalFileName } else { $file.name }

        Write-LogSeparator

        if ($MultiMode) {
            Write-Log "File $($i + 1) of $($pending.Count)"
        }

        try {
            $result = Receive-SpFile `
                -DriveId $drive.Id `
                -Item $file `
                -Destination (Join-Path $LocalFolder $name) `
                -Overwrite $Overwrite `
                -Settings $Config
        }
        catch {
            # Unexpected error for this file only: record it, carry on
            Write-LogException $_

            $result         = New-SpTransferResult $file.name
            $result.Status  = "DownloadFailed"
            $result.Message = $_.Exception.Message
        }

        $results[$file.name] = $result

        # Only pause when a request was made and another file follows
        if ($result.Status -ne "AlreadyCurrent" -and $i -lt $pending.Count - 1) {
            Start-Sleep -Seconds $Config.DelayBetweenFiles
        }
    }

    if ($stopped) {
        break
    }
}

if ($stopped) {
    Write-LogSeparator
    Write-Log "SharePoint throttling limit reached ($(Get-ThrottleEventCount) throttle response(s)); remaining files left for the next run" "WARN"
}

#--------------------------------------------------------------------------
# SUMMARY
#--------------------------------------------------------------------------

$notStarted = @($items | Where-Object { -not $results.Contains($_.name) } | ForEach-Object { $_.name })

$summary = Write-SpTransferSummary `
    -Results $results `
    -NotStarted $notStarted `
    -Total $items.Count `
    -DoneStatus "Downloaded" `
    -DoneLabel "Downloaded" `
    -SkippedStatus "AlreadyCurrent" `
    -SkippedReason "local file already identical" `
    -RetryableStatuses $RetryableStatuses

if ($summary.Retry -eq 0 -and $summary.Review -eq 0 -and $summary.NotStarted -eq 0) {
    Exit-Script "Success"
}

# One file (file path or DownloadMode Latest): keep the specific exit code
if (-not $MultiMode) {

    if ($summary.NotStarted -gt 0) {
        Exit-Script "DownloadFailed"
    }

    Exit-Script $summary.Failed[0].Status   # names match ExitCodes
}

# Folder, mode All: downloaded files stay; a rerun skips them.
# NeedsReview wins: some files will keep failing until someone acts.
if ($summary.Review -gt 0) {
    Write-Log "Some files need review: a rerun won't fix them as they are" "ERROR"
    Exit-Script "NeedsReview"
}

Write-Log "Some files were not downloaded; rerun to retry them (identical files are skipped)" "WARN"
Exit-Script "PartialFailure"
