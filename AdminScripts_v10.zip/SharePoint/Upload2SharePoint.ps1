<#
    Upload2SharePoint.ps1

    Uploads to a SharePoint Online folder. What is uploaded depends on
    -LocalPath:
      a file   : that file
      a folder : the files of that folder, top level only, no subfolders
                 (optional -Filter such as "*.csv"; default: all files)

    Use full local paths: a relative path is resolved against the process's
    working directory (often C:\Windows\System32 under Task Scheduler), not
    this script's folder. UNC paths (\\server\share\...) work.

  DESCRIPTION
    For each file:
      1. Skips it if the target already has it (same size + QuickXorHash,
         or for Office files: unchanged since the last upload per manifest)
      2. Uploads it to the staging folder under a unique name
      3. Validates without downloading: size + QuickXorHash reported by
         SharePoint. Office files changed by SharePoint (metadata) fall back
         to a download and part-by-part comparison.
      4. Moves the validated file into the target folder with its real name

    The target folder only ever receives fully validated files, and files
    already uploaded are never deleted. Files are sent one at a time,
    honoring SharePoint throttling (Retry-After). Failed files are retried
    over up to MaxPasses passes; files still failing are left for the next
    run (exit PartialFailure), which skips the files already uploaded.

    Logs     : <LogFolder>\<LogFileName>.log
               (no -LogFolder: console only)
    Manifest : <LogFolder>\state\<SiteName>_<TargetFolder>.json
               (no -LogFolder: <this script's folder>\state)
               Pass a stable -LogFolder so the manifest is found again
               next run (put a run id in -LogFileName, not -LogFolder).
               (deleted for a fresh start when the target folder is empty)

  PARAMETER CHECKS
    Parameters are checked when PowerShell binds them (before the script
    starts): a missing required parameter, a wrong value, a path that is
    not a full path (C:\... or \\server\...) or a bad path character stops
    the run with PowerShell's exit code 1 and a message on the console; no
    log is written. None of this script's own exit codes is 1, so 1 always
    means "bad parameters, nothing ran". Run jobs with -NonInteractive, or
    a missing required parameter makes PowerShell wait for typed input.
    Full paths are required because a scheduled task may start in
    C:\Windows\System32, where a relative path would point.

  EXAMPLES
    powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File C:\Development\scripts\SharePoint\Upload2SharePoint.ps1 `
        -LocalPath "C:\Development\data\test.xlsx" `
        -SiteName "smsfc" `
        -TargetFolder "Mass Cancellation" `
        -LogFolder "C:\Development\logs\MassCancellation" `
        -LogFileName "20261001_123455"

    powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File C:\Development\scripts\SharePoint\Upload2SharePoint.ps1 `
        -LocalPath "C:\Development\data\export" `
        -Filter "*.csv" `
        -SiteName "smsfc" `
        -TargetFolder "Mass Cancellation" `
        -LogFolder "C:\Development\logs\MassCancellation" `
        -NoOverwrite

  NOTES
    Layout (<root> = parent of this script's folder):
        <root>\SharePoint\Upload2SharePoint.ps1
        <root>\SharePoint\DownloadFromSharePoint.ps1
        <root>\SharePoint\SharepointConfig.psd1
        <root>\Common\config\EntraApp.psd1
        <root>\Common\modules\Logging.psm1
        <root>\Common\modules\ConfigHelpers.psm1
        <root>\Common\modules\HttpHelpers.psm1
        <root>\Common\modules\GraphAuth.psm1
        <root>\Common\modules\SpGraph.psm1
        <root>\Common\modules\FileValidation.psm1
        <root>\Common\modules\FileHelpers.psm1
        <root>\Common\modules\SpTransfer.psm1

    Exit codes are defined in SharepointConfig.psd1 (ExitCodes).
    99 is also returned when the config itself could not be loaded.
#>

[CmdletBinding()]
param(
    # Full path of a file (uploads that file) or a folder (uploads its files)
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^([A-Za-z]:[\\/]|\\\\[^\\/]+[\\/])[^*?"<>|]*$')]
    [string]$LocalPath,

    # Folder only: file name filter, e.g. "*.csv". Empty (default) = all files.
    # Wildcards * ? allowed; no folder part.
    [ValidatePattern('^[^\\/:"<>|]*$')]
    [string]$Filter = "",

    # Site URL name (https://<host>/sites/<SiteName>)
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^[A-Za-z0-9._-]+$')]
    [string]$SiteName,

    # Folder in the default document library, e.g. "Folder/Sub".
    # Characters SharePoint refuses (" * : < > ? |) are rejected.
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^[^"*:<>?|]+$')]
    [string]$TargetFolder,

    # <rootfolder>\logs\<jobname>, passed by the calling job.
    # Not given: no log file, all lines go to the console (standard output)
    [ValidatePattern('^(([A-Za-z]:[\\/]|\\\\[^\\/]+[\\/])[^*?"<>|]*)?$')]
    [string]$LogFolder,

    # Plain file name (no folder), without .log
    [ValidatePattern('^[^\\/:*?"<>|]*$')]
    [string]$LogFileName,

    # Defaults to StagingFolder in SharepointConfig.psd1
    [ValidatePattern('^[^"*:<>?|]+$')]
    [string]$StagingFolder,

    # Default is to replace a different file already in the target.
    # A switch (not [bool]) so it works from a batch file with -File.
    [switch]$NoOverwrite
)

$ErrorActionPreference = "Stop"

# Used until the config (and its ExitCodes) is loaded
$UnexpectedExitCode = 99

$RootFolder   = Split-Path $PSScriptRoot -Parent
$ModuleFolder = Join-Path $RootFolder "Common\modules"
$ConfigFile   = Join-Path $PSScriptRoot "SharepointConfig.psd1"
$Overwrite    = -not $NoOverwrite

$ConfigRequired = @(
    "EntraConfig",
    "SharePointHost",
    "MaxRetries",
    "BaseDelay",
    "MaxThrottleEvents",
    "MaxRetryAfter",
    "SimpleUploadLimitMB",
    "UploadChunkSizeKB",
    "UploadChunkTimeoutMinutes",
    "OfficeExtensions",
    "OfficeMetadata.IgnoredPartPrefixes",
    "OfficeMetadata.InjectedPattern",
    "StagingFolder",
    "StagingMaxAgeDays",
    "SettleDelay",
    "HashReadAttempts",
    "DelayBetweenFiles",
    "MaxPasses",
    "PassDelay",
    "StateFolderName",
    "ExitCodes.Success",
    "ExitCodes.UploadFailed",
    "ExitCodes.LocalPathNotFound",
    "ExitCodes.AuthFailed",
    "ExitCodes.SiteNotFound",
    "ExitCodes.FileExists",
    "ExitCodes.FolderError",
    "ExitCodes.MoveFailed",
    "ExitCodes.PartialFailure",
    "ExitCodes.NeedsReview",
    "ExitCodes.InvalidFileName",
    "ExitCodes.SetupFailed",
    "ExitCodes.Unexpected"
)

$EntraRequired = @("TenantId", "ClientId", "Thumbprint")

# Statuses worth another pass and a rerun (temporary). The others
# (FileExists, InvalidFileName) fail the same way until a person fixes them.
$RetryableStatuses = @("UploadFailed", "MoveFailed")

#--------------------------------------------------------------------------
# BOOTSTRAP 1: LOGGING (nothing to log to yet -> console, exit 99)
#--------------------------------------------------------------------------

try {
    foreach ($module in @("Logging", "ScriptHelpers")) {
        Import-Module (Join-Path $ModuleFolder "$module.psm1") -Force -ErrorAction Stop
    }

    # No -LogFolder: console only ($logPath is $null)
    $logPath = Initialize-Log -LogFolder $LogFolder -LogFileName $LogFileName
}
catch {
    [Console]::Out.WriteLine("Bootstrap failed (logging): $($_.Exception.Message)")
    exit $UnexpectedExitCode
}

Write-ScriptStart -Title "Upload started" -LogPath $logPath -LogFileName $LogFileName

#--------------------------------------------------------------------------
# BOOTSTRAP 2: MODULES AND CONFIG (exit codes not known yet -> exit 99)
#--------------------------------------------------------------------------

try {
    foreach ($module in @("ConfigHelpers", "HttpHelpers", "GraphAuth", "SpGraph", "FileValidation", "FileHelpers", "SpTransfer")) {
        Import-Module (Join-Path $ModuleFolder "$module.psm1") -Force -ErrorAction Stop
    }

    $Config = Import-ConfigFile -Path $ConfigFile -Required $ConfigRequired

    # From here on: Exit-Script "<reason>" uses ExitCodes from the config
    # and disconnects from Graph first
    Set-ScriptExit -ExitCodes $Config.ExitCodes -BeforeExit { Disconnect-AppGraph }
}
catch {
    Write-LogException $_ "Bootstrap failed"
    Exit-Script "Unexpected" -Code $UnexpectedExitCode
}

#--------------------------------------------------------------------------
# SAFETY NET
#--------------------------------------------------------------------------

# Safety net: any unexpected terminating error outside a try/catch is
# logged, disconnects from Graph and exits with ExitCodes.Unexpected
trap {
    Write-LogException $_ "Unexpected error"
    Exit-Script "Unexpected"
}

#--------------------------------------------------------------------------
# SETUP (config loaded -> SetupFailed)
#--------------------------------------------------------------------------

try {
    if ([string]::IsNullOrWhiteSpace($StagingFolder)) {
        $StagingFolder = $Config.StagingFolder
    }

    # Check the Entra config here so a missing/incomplete file is reported
    # as a setup problem, not an authentication failure
    $entraConfigPath = Resolve-ConfigPath -ConfigFile $ConfigFile -Path $Config.EntraConfig

    Import-ConfigFile -Path $entraConfigPath -Required $EntraRequired | Out-Null

    # <LogFolder>\state, or <script folder>\state when logging to the console
    $stateBase    = if ($logPath) { Split-Path -Path $logPath -Parent } else { $PSScriptRoot }
    $stateFolder  = Join-Path $stateBase $Config.StateFolderName
    $manifestPath = Get-SpManifestPath `
        -StateFolder $stateFolder `
        -SiteName $SiteName `
        -TargetFolder $TargetFolder

    Set-ThrottlePolicy -MaxEvents $Config.MaxThrottleEvents -MaxRetryAfter $Config.MaxRetryAfter

    Write-Log "Config     : $ConfigFile"
    Write-Log "Entra      : $entraConfigPath"
}
catch {
    Write-LogException $_ "Setup failed"
    Exit-Script "SetupFailed"
}

#--------------------------------------------------------------------------
# LOCAL FILES
#--------------------------------------------------------------------------

if (-not (Test-Path -LiteralPath $LocalPath)) {
    Write-Log "Local path not found: $LocalPath" "ERROR"
    Exit-Script "LocalPathNotFound"
}

# Full path for the log, whatever was passed
$LocalPath  = (Resolve-Path -LiteralPath $LocalPath).ProviderPath
$FolderMode = Test-Path -LiteralPath $LocalPath -PathType Container
$Mode       = if ($FolderMode) { "Folder" } else { "File" }

if ([string]::IsNullOrWhiteSpace($Filter)) {
    $Filter = "*"
}

Write-Log "Mode       : $Mode"
Write-Log "Local path : $LocalPath"

if ($FolderMode) {

    # Top level only. "~$*" are Office lock files of documents open in Office.
    $files = @(Get-ChildItem -LiteralPath $LocalPath -File -Filter $Filter |
        Where-Object { -not $_.Name.StartsWith('~$') } |
        Sort-Object Name)

    Write-Log "Filter     : $Filter"
}
else {

    if ($Filter -ne "*") {
        Write-Log "-Filter applies to a folder only; ignored" "WARN"
    }

    $files = @(Get-Item -LiteralPath $LocalPath)
}

Write-Log "Files      : $($files.Count)"
Write-Log "Site name  : $SiteName"
Write-Log "Target     : /$($TargetFolder.Trim('/\'))"
Write-Log "Staging    : /$($StagingFolder.Trim('/\'))"
Write-Log "Overwrite  : $Overwrite"
Write-LogSeparator

if ($files.Count -eq 0) {
    Write-Log "No files to upload in $LocalPath (filter '$Filter')" "WARN"
    Exit-Script "Success"
}

#--------------------------------------------------------------------------
# AUTHENTICATION
#--------------------------------------------------------------------------

try {
    $connection = Connect-AppGraph -EntraConfigPath $entraConfigPath

    Write-Log "Graph authentication successful (client $($connection.ClientId))"
}
catch {
    Write-LogException $_
    Exit-Script "AuthFailed"
}

#--------------------------------------------------------------------------
# LOCATE SITE AND DEFAULT DOCUMENT LIBRARY
#--------------------------------------------------------------------------

try {
    $drive = Invoke-WithRetry `
        -Activity "Locate site" `
        -MaxRetries $Config.MaxRetries `
        -BaseDelay $Config.BaseDelay `
        -ShouldRetry { param($m) -not (Test-IsNotFoundError $m) } `
        -ScriptBlock { Get-SpDrive -SharePointHost $Config.SharePointHost -SiteName $SiteName }

    Write-Log "Site       : $($drive.SiteUrl)"
    Write-Log "Library    : $($drive.Name)"
}
catch {
    Write-LogException $_
    Exit-Script "SiteNotFound"
}

#--------------------------------------------------------------------------
# FOLDERS
#--------------------------------------------------------------------------

try {
    $folders = Invoke-WithRetry `
        -Activity "Locate folders" `
        -MaxRetries $Config.MaxRetries `
        -BaseDelay $Config.BaseDelay `
        -ScriptBlock {
            $target  = Get-SpFolder -DriveId $drive.Id -Path $TargetFolder
            $staging = $null

            if ($target) {
                $staging = Get-SpFolder -DriveId $drive.Id -Path $StagingFolder -CreateIfMissing
            }

            [pscustomobject]@{ Target = $target; Staging = $staging }
        }

    if (-not $folders.Target) {
        throw "Target folder not found: $TargetFolder"
    }

    $targetFolderItem  = $folders.Target
    $stagingFolderItem = $folders.Staging

    Write-Log "Folders ready (target and staging)"
}
catch {
    Write-LogException $_
    Exit-Script "FolderError"
}

# Copies abandoned by killed runs (never touches anything else)
Clear-SpStaging `
    -DriveId $drive.Id `
    -StagingFolderId $stagingFolderItem.id `
    -MaxAgeDays $Config.StagingMaxAgeDays

#--------------------------------------------------------------------------
# MANIFEST
#--------------------------------------------------------------------------

$manifest = Import-SpManifest -Path $manifestPath

#--------------------------------------------------------------------------
# UPLOAD (one file at a time; extra passes for failed files)
#--------------------------------------------------------------------------

# file name -> result; files never attempted have no entry
$results   = [ordered]@{}
$pending   = $files
$stopped   = $false
$maxPasses = [math]::Max(1, [int]$Config.MaxPasses)

for ($pass = 1; $pass -le $maxPasses; $pass++) {

    if ($pass -gt 1) {

        $pending = @($files | Where-Object {
            $results.Contains($_.Name) -and
            $results[$_.Name].Status -in $RetryableStatuses
        })

        if ($pending.Count -eq 0) {
            break
        }

        # Check before waiting: no point waiting if we are stopping anyway
        if (Test-ThrottleLimitReached) {
            $stopped = $true
            break
        }

        Write-LogSeparator
        Write-Log "Waiting $($Config.PassDelay) seconds before pass $pass" "WARN"
        Start-Sleep -Seconds $Config.PassDelay
    }

    Write-LogSeparator
    Write-Log "Pass $pass of ${maxPasses}: $($pending.Count) file(s)"

    # One listing of the target folder for the whole pass, instead of one
    # request per file. If it fails, each file is looked up on its own.
    $targetIndex = $null

    try {
        $targetIndex = Invoke-WithRetry `
            -Activity "List target folder" `
            -MaxRetries $Config.MaxRetries `
            -BaseDelay $Config.BaseDelay `
            -ScriptBlock { New-SpTargetIndex -DriveId $drive.Id -FolderId $targetFolderItem.id }

        Write-Log "Target folder has $($targetIndex.Count) file(s)"

        # Fresh start when nothing has been uploaded yet: the target folder
        # has no files, so delete the manifest (only after a successful
        # listing; a failed listing never clears anything)
        if ($pass -eq 1 -and $targetIndex.Count -eq 0) {

            $manifest = @{}

            if (Test-Path -LiteralPath $manifestPath -PathType Leaf) {
                try {
                    Remove-Item -LiteralPath $manifestPath -Force -ErrorAction Stop
                    Write-Log "Manifest   : target folder is empty; fresh start (manifest deleted)"
                }
                catch {
                    Write-Log "Could not delete manifest; starting with an empty one" "WARN"
                    Write-LogException $_
                }
            }
        }

        # Otherwise forget entries for files no longer in the target folder
        # (deleted on SharePoint). Harmless to keep, since an entry is only
        # used when the file is there, but this keeps the manifest small.
        elseif ($pass -eq 1) {

            $stale = @($manifest.Keys | Where-Object { -not $targetIndex.ContainsKey($_) })

            if ($stale.Count -gt 0) {

                foreach ($name in $stale) {
                    $manifest.Remove($name)
                }

                Write-Log "Manifest   : $($stale.Count) entry(ies) removed (file no longer on SharePoint)"

                try {
                    Save-SpManifest -Path $manifestPath -Manifest $manifest
                }
                catch {
                    Write-Log "Could not save manifest" "WARN"
                    Write-LogException $_
                }
            }
        }
    }
    catch {
        Write-Log "Could not list target folder; checking files one by one" "WARN"
        Write-LogException $_
        $targetIndex = $null
    }

    for ($i = 0; $i -lt $pending.Count; $i++) {

        $file = $pending[$i]

        # Circuit breaker: SharePoint keeps throttling us, stop cleanly and
        # leave the remaining files for the next run
        if (Test-ThrottleLimitReached) {
            $stopped = $true
            break
        }

        Write-LogSeparator
        Write-Log "File $($i + 1) of $($pending.Count)"

        try {
            $result = Publish-SpFile `
                -DriveId $drive.Id `
                -LocalFile $file.FullName `
                -TargetFolder $TargetFolder `
                -TargetFolderId $targetFolderItem.id `
                -StagingFolder $StagingFolder `
                -Overwrite $Overwrite `
                -Settings $Config `
                -TargetIndex $targetIndex `
                -ManifestEntry $manifest[$file.Name]
        }
        catch {
            # Unexpected error for this file only (e.g. local file locked):
            # record it and carry on with the next file
            Write-LogException $_

            $result           = New-SpTransferResult $file.Name
            $result.LocalPath = $file.FullName
            $result.Status    = "UploadFailed"
            $result.Message   = $_.Exception.Message
        }

        $results[$file.Name] = $result

        # Record what is now on SharePoint, right away, so a crash later in
        # the run doesn't lose it
        if ($result.Status -in @("Uploaded", "Skipped") -and $result.RemoteHash) {

            $manifest[$file.Name] = New-SpManifestEntry -Result $result

            try {
                Save-SpManifest -Path $manifestPath -Manifest $manifest
            }
            catch {
                Write-Log "Could not save manifest (file is uploaded; it may be re-checked next run)" "WARN"
                Write-LogException $_
            }
        }

        # Only pause when a request was made and another file follows
        if ($result.Status -notin @("Skipped", "InvalidFileName") -and $i -lt $pending.Count - 1) {
            Start-Sleep -Seconds $Config.DelayBetweenFiles
        }
    }

    if ($stopped) {
        break
    }
}

if ($stopped) {
    Write-LogSeparator
    Write-Log "SharePoint throttling limit reached ($(Get-ThrottleEventCount) throttle response(s)); remaining files left for the next run" "WARN"
}

#--------------------------------------------------------------------------
# SUMMARY
#--------------------------------------------------------------------------

$notStarted = @($files | Where-Object { -not $results.Contains($_.Name) } | ForEach-Object { $_.Name })

$summary = Write-SpTransferSummary `
    -Results $results `
    -NotStarted $notStarted `
    -Total $files.Count `
    -DoneStatus "Uploaded" `
    -DoneLabel "Uploaded" `
    -SkippedStatus "Skipped" `
    -SkippedReason "already on SharePoint" `
    -RetryableStatuses $RetryableStatuses

if ($summary.Retry -eq 0 -and $summary.Review -eq 0 -and $summary.NotStarted -eq 0) {
    Write-Log "Upload complete"
    Exit-Script "Success"
}

# Single file: keep the specific exit code (status names match ExitCodes)
if (-not $FolderMode) {

    if ($summary.NotStarted -gt 0) {
        Exit-Script "UploadFailed"
    }

    Exit-Script $summary.Failed[0].Status
}

# Folder: files already uploaded stay on SharePoint; a rerun skips them.
# NeedsReview wins: some files will keep failing until someone acts.
if ($summary.Review -gt 0) {
    Write-Log "Some files need review: a rerun won't fix them as they are" "ERROR"
    Exit-Script "NeedsReview"
}

Write-Log "Some files were not uploaded; rerun to retry them (uploaded files are skipped)" "WARN"
Exit-Script "PartialFailure"
