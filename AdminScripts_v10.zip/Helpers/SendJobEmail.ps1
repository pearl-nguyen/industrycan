<#
    SendJobEmail.ps1

  SYNOPSIS
    Emails the team the result of a job: name, status, log file location,
    and the expiry of the certificates listed in the config.

  DESCRIPTION
    Sent through Microsoft Graph as the no-reply mailbox (From in the
    config), with the Entra app (Mail.Send application permission). Subject
    and body are built from templates (SubjectTemplate, BodyTemplate,
    CertRowTemplate); recipients, colors, texts and thresholds come from
    SendJobEmailConfig.psd1.

    Certificates (Certificates in the config) are shown on every email:
      more than CertWarningDays left : expiry date, normal
      CertWarningDays or fewer       : warning color
      CertCriticalDays or fewer      : red
      expired / not found            : red / warning color
    The most urgent one is also noted in the subject (CertSubjectNotes).

    A certificate that can't be checked never stops the email.

  PARAMETERS
    -JobName      Name of the job.
    -JobStatus    Success or Failure.
    -JobLogFile   Location of the job's log file (shown in the email).
    -Message      Optional short message.
    -To           Recipients (required; varies by job). Several addresses:
                  "a@x.ca,b@x.ca" (commas, semicolons or spaces).
    -Cc           Optional copies, added to Cc in the config.
                  Addresses are checked before the script starts; an
                  address in both To and Cc is sent once (To).
    -LogFolder    Optional. Not given: no log file, lines go to the console.
    -LogFileName  Optional. Log file name without .log.

  PARAMETER CHECKS
    Parameters are checked when PowerShell binds them (before the script
    starts): a missing required parameter, a wrong value, a path that is
    not a full path (C:\... or \\server\...) or a bad path character stops
    the run with PowerShell's exit code 1 and a message on the console; no
    log is written. None of this script's own exit codes is 1, so 1 always
    means "bad parameters, nothing ran". Run jobs with -NonInteractive, or
    a missing required parameter makes PowerShell wait for typed input.
    Full paths are required because a scheduled task may start in
    C:\Windows\System32, where a relative path would point.

  EXIT CODES
    From ExitCodes in SendJobEmailConfig.psd1. 99 also when the config
    itself could not be loaded.

  EXAMPLE
    powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File Helpers\SendJobEmail.ps1 `
        -JobName "Daily Oracle export" -JobStatus Failure `
        -JobLogFile "C:\Lstelcom\Admin\BcpAdmin\logs\20261031_132311\Upload2SharePoint.log" `
        -Message "Upload exit code 15: some files will be retried." `
        -To "jane.doe@ised-isde.gc.ca,john.smith@ised-isde.gc.ca"

  NOTES
    Layout (<root> = parent of this script's folder):
        <root>\Helpers\SendJobEmail.ps1
        <root>\Helpers\SendJobEmailConfig.psd1
        <root>\Helpers\templates\JobEmail.html, CertRow.html
        <root>\Common\config\EntraApp.psd1
        <root>\Common\modules\Logging, ScriptHelpers, ConfigHelpers,
                              HttpHelpers, GraphAuth, GraphMail, Templates,
                              CertStore (.psm1)
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$JobName,

    [Parameter(Mandatory = $true)]
    [ValidateSet("Success", "Failure")]
    [string]$JobStatus,

    [Parameter(Mandatory = $true)]
    [ValidatePattern('^([A-Za-z]:[\\/]|\\\\[^\\/]+[\\/])[^*?"<>|]*$')]
    [string]$JobLogFile,

    [string]$Message,

    # Recipients of this job's email. One value may hold several addresses
    # separated by , ; or spaces (powershell.exe -File passes
    # "a@x.ca,b@x.ca" as one value). Same address rule as Test-EmailAddress
    # in GraphMail.psm1 (keep the two in sync).
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^\s*[A-Za-z0-9_%+''-]+(\.[A-Za-z0-9_%+''-]+)*@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}(\s*[,;\s]\s*[A-Za-z0-9_%+''-]+(\.[A-Za-z0-9_%+''-]+)*@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,})*\s*$')]
    [string[]]$To,

    # Optional copies; added to Cc in the config
    [ValidatePattern('^\s*[A-Za-z0-9_%+''-]+(\.[A-Za-z0-9_%+''-]+)*@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}(\s*[,;\s]\s*[A-Za-z0-9_%+''-]+(\.[A-Za-z0-9_%+''-]+)*@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,})*\s*$')]
    [string[]]$Cc,

    # Not given: no log file, all lines go to the console (standard output)
    [ValidatePattern('^(([A-Za-z]:[\\/]|\\\\[^\\/]+[\\/])[^*?"<>|]*)?$')]
    [string]$LogFolder,

    # Plain file name (no folder), without .log
    [ValidatePattern('^[^\\/:*?"<>|]*$')]
    [string]$LogFileName
)

$ErrorActionPreference = "Stop"

# Used until the config (and its ExitCodes) is loaded
$UnexpectedExitCode = 99

$RootFolder   = Split-Path $PSScriptRoot -Parent
$ModuleFolder = Join-Path $RootFolder "Common\modules"
$ConfigFile   = Join-Path $PSScriptRoot "SendJobEmailConfig.psd1"

$ConfigRequired = @(
    "EntraConfig", "From", "BodyTemplate", "SubjectTemplate", "CertRowTemplate",
    "TimestampFormat", "DateFormat", "StatusColors.Success", "StatusColors.Failure",
    "CertStores", "CertWarningDays", "CertCriticalDays",
    "CertLevels.Ok", "CertLevels.Warning", "CertLevels.Critical", "CertLevels.Expired", "CertLevels.NotFound",
    "MaxRetries", "BaseDelay", "MaxThrottleEvents", "MaxRetryAfter",
    "ExitCodes.Success", "ExitCodes.SendFailed", "ExitCodes.TemplateError", "ExitCodes.InvalidInput",
    "ExitCodes.AuthFailed", "ExitCodes.SetupFailed", "ExitCodes.Unexpected"
)

# Most urgent first: decides which certificate is noted in the subject
$CertLevelOrder = @("Expired", "Critical", "Warning", "NotFound", "Ok")

#--------------------------------------------------------------------------
# BOOTSTRAP 1: LOGGING (nothing to log to yet -> console, exit 99)
#--------------------------------------------------------------------------

try {
    foreach ($module in @("Logging", "ScriptHelpers")) {
        Import-Module (Join-Path $ModuleFolder "$module.psm1") -Force -ErrorAction Stop
    }

    # No -LogFolder: console only ($logPath is $null)
    $logPath = Initialize-Log -LogFolder $LogFolder -LogFileName $LogFileName
}
catch {
    [Console]::Out.WriteLine("Bootstrap failed (logging): $($_.Exception.Message)")
    exit $UnexpectedExitCode
}

Write-ScriptStart -Title "Job email started" -LogPath $logPath -LogFileName $LogFileName

#--------------------------------------------------------------------------
# BOOTSTRAP 2: MODULES AND CONFIG (exit codes not known yet -> exit 99)
#--------------------------------------------------------------------------

try {
    foreach ($module in @("ConfigHelpers", "HttpHelpers", "GraphAuth", "GraphMail", "Templates", "CertStore")) {
        Import-Module (Join-Path $ModuleFolder "$module.psm1") -Force -ErrorAction Stop
    }

    $Config = Import-ConfigFile -Path $ConfigFile -Required $ConfigRequired

    # From here on: Exit-Script "<reason>" uses ExitCodes from the config
    # and disconnects from Graph first
    Set-ScriptExit -ExitCodes $Config.ExitCodes -BeforeExit { Disconnect-AppGraph }
}
catch {
    Write-LogException $_ "Bootstrap failed"
    Exit-Script "Unexpected" -Code $UnexpectedExitCode
}

#--------------------------------------------------------------------------
# SETUP (config loaded -> SetupFailed)
#--------------------------------------------------------------------------

try {
    $entraConfigPath = Resolve-ConfigPath -ConfigFile $ConfigFile -Path $Config.EntraConfig

    Import-ConfigFile -Path $entraConfigPath -Required "GraphBaseUrl", "TenantId", "ClientId", "Thumbprint" | Out-Null

    Set-ThrottlePolicy -MaxEvents $Config.MaxThrottleEvents -MaxRetryAfter $Config.MaxRetryAfter

    $computerName = [Environment]::MachineName
    $now          = Get-Date

    Write-Log "Config     : $ConfigFile"
    Write-Log "Job        : $JobName"
    Write-Log "Status     : $JobStatus"
    Write-Log "Job log    : $JobLogFile"
}
catch {
    Write-LogException $_ "Setup failed"
    Exit-Script "SetupFailed"
}

#--------------------------------------------------------------------------
# TEMPLATES
#--------------------------------------------------------------------------

try {
    $bodyTemplate    = Import-Template (Resolve-ConfigPath -ConfigFile $ConfigFile -Path $Config.BodyTemplate)
    $certRowTemplate = Import-Template (Resolve-ConfigPath -ConfigFile $ConfigFile -Path $Config.CertRowTemplate)
}
catch {
    Write-LogException $_ "Template error"
    Exit-Script "TemplateError"
}

#--------------------------------------------------------------------------
# RECIPIENTS
#--------------------------------------------------------------------------

# -To / -Cc were checked at binding; From and Cc in the config are checked
# here. Lists are split ("a,b" arrives as one value with -File), and an
# address is sent once: duplicates and Cc addresses already in To are dropped.
$toList = @(ConvertTo-EmailList $To)
$ccList = @(ConvertTo-EmailList (@($Config.Cc) + @($Cc)) -Exclude $toList)

$badAddresses = @(@($toList) + @($ccList) + @($Config.From) |
                  Where-Object { -not (Test-EmailAddress $_) })

if ($toList.Count -eq 0 -or $badAddresses.Count -gt 0) {

    foreach ($a in $badAddresses) {
        Write-Log "Invalid email address: '$a' (check From and Cc in $ConfigFile)" "ERROR"
    }

    if ($toList.Count -eq 0) {
        Write-Log "No recipient in -To" "ERROR"
    }

    Exit-Script "InvalidInput"
}

Write-Log "From       : $($Config.From)"
Write-Log "To         : $($toList -join ', ')"

if ($ccList.Count -gt 0) {
    Write-Log "Cc         : $($ccList -join ', ')"
}

#--------------------------------------------------------------------------
# CERTIFICATES (never stops the email)
#--------------------------------------------------------------------------

$certRows   = New-Object System.Collections.Generic.List[string]
$mostUrgent = $null

foreach ($entry in @($Config.Certificates)) {

    $name   = if ($entry.Name) { $entry.Name } else { "Certificate" }
    $values = @{ CertName = $name; ComputerName = $computerName; ExpiryDate = ""; DaysLeft = "" }
    $level  = "NotFound"

    try {
        if ($entry.Thumbprint) {
            $thumbprint = $entry.Thumbprint
        }
        elseif ($entry.ThumbprintFrom) {
            $source     = Resolve-ConfigPath -ConfigFile $ConfigFile -Path $entry.ThumbprintFrom
            $thumbprint = (Import-ConfigFile -Path $source -Required "Thumbprint").Thumbprint
        }
        else {
            throw "Certificate '$name' has neither Thumbprint nor ThumbprintFrom."
        }

        $thumbprint = ConvertTo-CleanThumbprint $thumbprint
        $cert       = Find-CertByThumbprint -Thumbprint $thumbprint -StorePaths $Config.CertStores

        if ($cert) {

            $expiry = Get-CertExpiry -Cert $cert -WarningDays $Config.CertWarningDays -CriticalDays $Config.CertCriticalDays -Now $now
            $level  = $expiry.Level

            $values.ExpiryDate = $expiry.NotAfter.ToString($Config.DateFormat)
            $values.DaysLeft   = $expiry.DaysLeft

            Write-Log "Certificate: $name  $thumbprint  expires $($values.ExpiryDate) ($($expiry.DaysLeft) days)  [$level]"
        }
        else {
            Write-Log "Certificate: $name  $thumbprint  not found in $($Config.CertStores -join ', ')" "WARN"
        }
    }
    catch {
        Write-Log "Certificate: $name can't be checked: $($_.Exception.Message)" "WARN"
    }

    $style = $Config.CertLevels[$level]

    $rowValues = @{
        CertName    = $name
        CertColor   = $style.Color
        CertWeight  = $style.Weight
        CertMessage = Expand-Template -Template $style.Message -Values $values
    }

    $certRows.Add((Expand-Template -Template $certRowTemplate -Values $rowValues -Html))

    if ($null -eq $mostUrgent -or $CertLevelOrder.IndexOf($level) -lt $CertLevelOrder.IndexOf($mostUrgent.Level)) {
        $mostUrgent = @{ Level = $level; Values = $values }
    }
}

$certSubjectNote = ""

if ($mostUrgent -and $Config.CertSubjectNotes -and $Config.CertSubjectNotes.Contains($mostUrgent.Level)) {
    $certSubjectNote = Expand-Template -Template $Config.CertSubjectNotes[$mostUrgent.Level] -Values $mostUrgent.Values
}

#--------------------------------------------------------------------------
# BUILD THE MESSAGE
#--------------------------------------------------------------------------

$values = @{
    JobName         = $JobName
    JobStatus       = $JobStatus
    StatusColor     = $Config.StatusColors[$JobStatus]
    ComputerName    = $computerName
    Timestamp       = $now.ToString($Config.TimestampFormat)
    LogLocation     = $JobLogFile
    Message         = $Message
    CertRows        = ($certRows -join [Environment]::NewLine)
    CertSubjectNote = $certSubjectNote
}

$subject = Expand-Template -Template $Config.SubjectTemplate -Values $values
$body    = Expand-Template -Template $bodyTemplate -Values $values -Html -RawKeys "CertRows"

Write-Log "Subject    : $subject"
Write-LogSeparator

#--------------------------------------------------------------------------
# SEND
#--------------------------------------------------------------------------

try {
    $connection = Connect-AppGraph -EntraConfigPath $entraConfigPath

    Write-Log "Graph authentication successful (client $($connection.ClientId))"
}
catch {
    Write-LogException $_
    Exit-Script "AuthFailed"
}

try {
    Send-GraphMail `
        -From $Config.From `
        -To $toList `
        -Cc $ccList `
        -Subject $subject `
        -HtmlBody $body `
        -SaveToSentItems ([bool]$Config.SaveToSentItems) `
        -MaxRetries $Config.MaxRetries `
        -BaseDelay $Config.BaseDelay
}
catch {
    Write-LogException $_ "Email not sent"
    Exit-Script "SendFailed"
}

Exit-Script "Success"
