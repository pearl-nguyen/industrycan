#--------------------------------------------------------------------------
# SendJobEmailConfig.psd1
#   Settings for Helpers\SendJobEmail.ps1. Paths are relative to this file.
#--------------------------------------------------------------------------

@{
    # Entra app used to send (Graph endpoint, tenant, app, certificate).
    # The app has the Mail.Send application permission, limited to the
    # sending mailbox by an Exchange application access policy.
    EntraConfig = "..\Common\config\EntraApp.psd1"

    #----------------------------------------------------------------------
    # Message
    #----------------------------------------------------------------------

    # Sending mailbox (no-reply). SET TO YOUR NO-REPLY ADDRESS.
    From = "noreply@ised-isde.gc.ca"

    # Recipients come from the job: -To (required) and -Cc on the command
    # line. Addresses here are copied on EVERY email, in addition to -Cc
    # (e.g. a team mailbox). Empty: none.
    Cc   = @()

    # Keep a copy in the sending mailbox's Sent Items
    SaveToSentItems = $false

    # Templates ({{Name}} placeholders; {{#Name}}...{{/Name}} only when Name
    # has a value). Placeholders available:
    #   JobName, JobStatus, StatusColor, ComputerName, Timestamp,
    #   LogLocation, Message, CertRows (body only), CertSubjectNote
    BodyTemplate    = "templates\JobEmail.html"
    SubjectTemplate = "[{{JobStatus}}] {{JobName}} - {{ComputerName}}{{#CertSubjectNote}} - {{CertSubjectNote}}{{/CertSubjectNote}}"

    # One row per certificate in the body ({{CertRows}}). Placeholders:
    #   CertName, CertColor, CertWeight, CertMessage
    CertRowTemplate = "templates\CertRow.html"

    TimestampFormat = "yyyy-MM-dd HH:mm:ss"
    DateFormat      = "yyyy-MM-dd"

    # Color of the job status (HTML colors)
    StatusColors = @{
        Success = "#2e7d32"
        Failure = "#c62828"
    }

    #----------------------------------------------------------------------
    # Certificates whose expiry is shown in every email
    #   ThumbprintFrom : a config file with a Thumbprint setting (preferred:
    #                    the thumbprint is kept in one place)
    #   Thumbprint     : or the thumbprint itself
    #----------------------------------------------------------------------
    Certificates = @(
        @{ Name = "STS - SMS Operations (Graph sign-in)"; ThumbprintFrom = "..\Common\config\EntraApp.psd1" }
    )

    # Stores searched for the certificates, in order
    CertStores = @("Cert:\LocalMachine\My", "Cert:\CurrentUser\My")

    # Days left at which a certificate is shown as Warning / Critical
    CertWarningDays  = 30
    CertCriticalDays = 15

    # Look and text per level. Message placeholders: ExpiryDate, DaysLeft,
    # CertName, ComputerName
    CertLevels = @{
        Ok       = @{ Color = "#555555"; Weight = "normal"; Message = "Expires on {{ExpiryDate}} ({{DaysLeft}} days left)." }
        Warning  = @{ Color = "#e65100"; Weight = "bold";   Message = "Expires in {{DaysLeft}} days, on {{ExpiryDate}}. Plan the renewal." }
        Critical = @{ Color = "#c62828"; Weight = "bold";   Message = "Expires in {{DaysLeft}} days, on {{ExpiryDate}}. Renew it now: jobs stop when it expires." }
        Expired  = @{ Color = "#c62828"; Weight = "bold";   Message = "EXPIRED on {{ExpiryDate}}. Jobs that use it no longer work." }
        NotFound = @{ Color = "#e65100"; Weight = "bold";   Message = "Not found on {{ComputerName}}: its expiry can't be checked." }
    }

    # Added to the subject ({{CertSubjectNote}}) for the most urgent
    # certificate; levels not listed add nothing
    CertSubjectNotes = @{
        Warning  = "certificate expires in {{DaysLeft}} days"
        Critical = "CERTIFICATE EXPIRES IN {{DaysLeft}} DAYS"
        Expired  = "CERTIFICATE EXPIRED"
    }

    #----------------------------------------------------------------------
    # Sending: retries and throttling
    #----------------------------------------------------------------------
    MaxRetries        = 3
    BaseDelay         = 5
    MaxThrottleEvents = 10
    MaxRetryAfter     = 300

    #----------------------------------------------------------------------
    # Exit codes returned to the calling job.
    # A failure before this file is loaded (modules, this config itself)
    # exits with 99: the script hardcodes it since these codes aren't known yet.
    #----------------------------------------------------------------------
    # 1 is not used: PowerShell returns 1 when a parameter is missing or
    # invalid (the script never started).
    ExitCodes = @{
        Success       = 0    # email sent
        SendFailed    = 2    # Graph refused or failed to send after all retries
        TemplateError = 3    # a template file is missing or unreadable
        InvalidInput  = 4    # an invalid address (-To, -Cc, From, Cc in this config)
        AuthFailed    = 10   # Graph authentication
        SetupFailed   = 98   # setup after config load (Entra config, certificate list)
        Unexpected    = 99   # any error not covered above, or config not loaded
    }
}
