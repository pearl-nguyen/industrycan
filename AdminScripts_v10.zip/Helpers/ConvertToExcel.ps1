<#
    ConvertToExcel.ps1

  SYNOPSIS
    Converts a CSV file to an Excel workbook (.xlsx) and validates it.

  DESCRIPTION
    Microsoft Office is not needed: the .xlsx is written directly
    (Common\modules\ExcelExport.psm1).

      1. Writes <XlsxFile>.<id>.partial next to the target
      2. Validates it by opening it like Excel would: the package, every
         required part, well-formed XML, then every cell. Row count, column
         counts and a hash of all cell values must match what was read from
         the CSV.
      3. Puts it in place in one step (an existing .xlsx is replaced only
         after the new one is validated, and only if overwrite is on)

    Every cell is written as text, exactly as in the CSV: leading zeros
    (00123), long numbers and dates are kept as they are. With a header,
    the first row is bold and frozen. Characters Excel can't hold (control
    characters) are removed and counted in the log. Blank lines at the end
    of the CSV (e.g. a SQL*Plus spool) are not written; blank lines between
    data rows are kept.

  PARAMETERS
    -CsvFile      Full path to the CSV file; must end with .csv.
    -XlsxFile     Optional. Full path, or a file name only (goes in the
                  CSV's folder); must end with .xlsx.
                  Default: the CSV's folder and name, with .xlsx
    -Delimiter    Optional. , | ; or tab. Default: Delimiter in the config.
    -Encoding     Optional. UTF8, Windows1252 or Unicode. Default: config.
    -SheetName    Optional. Default: the CSV file name (made valid for Excel).
    -NoHeader     The first row is data, not a header.
    -NoOverwrite  Fail (OutputExists) if the .xlsx already exists.
    -LogFolder    Optional. Not given: no log file, lines go to the console.
    -LogFileName  Optional. Log file name without .log.

  PARAMETER CHECKS
    Parameters are checked when PowerShell binds them (before the script
    starts): a missing required parameter, a wrong value, a path that is
    not a full path (C:\... or \\server\...) or a bad path character stops
    the run with PowerShell's exit code 1 and a message on the console; no
    log is written. None of this script's own exit codes is 1, so 1 always
    means "bad parameters, nothing ran". Run jobs with -NonInteractive, or
    a missing required parameter makes PowerShell wait for typed input.
    Full paths are required because a scheduled task may start in
    C:\Windows\System32, where a relative path would point.

  EXIT CODES
    From ExitCodes in ConvertToExcelConfig.psd1. 99 also when the config
    itself could not be loaded.

  EXAMPLE
    powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File Helpers\ConvertToExcel.ps1 `
        -CsvFile "D:\out\extract.csv" -LogFolder "D:\job\logs" -LogFileName run_20261031

    Output name in the CSV's folder; writes D:\out\extract_20261031.xlsx:
        ... -File Helpers\ConvertToExcel.ps1 -CsvFile "D:\out\extract.csv" -XlsxFile extract_20261031.xlsx

  NOTES
    Layout (<root> = parent of this script's folder):
        <root>\Helpers\ConvertToExcel.ps1
        <root>\Helpers\ConvertToExcelConfig.psd1
        <root>\Common\modules\Logging, ScriptHelpers, ConfigHelpers,
                              FileHelpers, ExcelExport (.psm1)
#>

[CmdletBinding()]
param(
    # Full path, ending with .csv
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^([A-Za-z]:[\\/]|\\\\[^\\/]+[\\/])[^*?"<>|]*\.csv$')]
    [string]$CsvFile,

    # Full path, or a file name only (goes in the CSV's folder); ends with .xlsx
    [ValidatePattern('^(([A-Za-z]:[\\/]|\\\\[^\\/]+[\\/])[^*?"<>|]*|[^\\/:*?"<>|]+)\.xlsx$')]
    [string]$XlsxFile,

    [ValidateSet(',', '|', ';', "`t")]
    [string]$Delimiter,

    [ValidateSet("UTF8", "Windows1252", "Unicode")]
    [string]$Encoding,

    [ValidateNotNullOrEmpty()]
    [string]$SheetName,

    [switch]$NoHeader,

    [switch]$NoOverwrite,

    # Not given: no log file, all lines go to the console (standard output)
    [ValidatePattern('^(([A-Za-z]:[\\/]|\\\\[^\\/]+[\\/])[^*?"<>|]*)?$')]
    [string]$LogFolder,

    # Plain file name (no folder), without .log
    [ValidatePattern('^[^\\/:*?"<>|]*$')]
    [string]$LogFileName
)

$ErrorActionPreference = "Stop"

# Used until the config (and its ExitCodes) is loaded
$UnexpectedExitCode = 99

$RootFolder   = Split-Path $PSScriptRoot -Parent
$ModuleFolder = Join-Path $RootFolder "Common\modules"
$ConfigFile   = Join-Path $PSScriptRoot "ConvertToExcelConfig.psd1"

$ConfigRequired = @(
    "Delimiter", "Encoding", "HasHeader", "Overwrite", "Excel",
    "ExitCodes.Success", "ExitCodes.ConversionFailed", "ExitCodes.InputNotFound",
    "ExitCodes.ValidationFailed", "ExitCodes.OutputExists",
    "ExitCodes.ExcelLimitExceeded", "ExitCodes.Unexpected"
)

#--------------------------------------------------------------------------
# BOOTSTRAP 1: LOGGING (nothing to log to yet -> console, exit 99)
#--------------------------------------------------------------------------

try {
    foreach ($module in @("Logging", "ScriptHelpers")) {
        Import-Module (Join-Path $ModuleFolder "$module.psm1") -Force -ErrorAction Stop
    }

    # No -LogFolder: console only ($logPath is $null)
    $logPath = Initialize-Log -LogFolder $LogFolder -LogFileName $LogFileName
}
catch {
    [Console]::Out.WriteLine("Bootstrap failed (logging): $($_.Exception.Message)")
    exit $UnexpectedExitCode
}

Write-ScriptStart -Title "Convert to Excel started" -LogPath $logPath -LogFileName $LogFileName

#--------------------------------------------------------------------------
# BOOTSTRAP 2: MODULES AND CONFIG (exit codes not known yet -> exit 99)
#--------------------------------------------------------------------------

try {
    foreach ($module in @("ConfigHelpers", "FileHelpers", "ExcelExport")) {
        Import-Module (Join-Path $ModuleFolder "$module.psm1") -Force -ErrorAction Stop
    }

    $Config = Import-ConfigFile -Path $ConfigFile -Required $ConfigRequired

    # From here on: Exit-Script "<reason>" uses ExitCodes from the config
    Set-ScriptExit -ExitCodes $Config.ExitCodes

    $format = New-XlsxFormat -Settings $Config.Excel
}
catch {
    Write-LogException $_ "Bootstrap failed"
    Exit-Script "Unexpected" -Code $UnexpectedExitCode
}

#--------------------------------------------------------------------------
# PARAMETERS (config defaults)
#--------------------------------------------------------------------------

if ([string]::IsNullOrEmpty($Delimiter)) { $Delimiter = $Config.Delimiter }
if ([string]::IsNullOrEmpty($Encoding))  { $Encoding  = $Config.Encoding }

$hasHeader = [bool]$Config.HasHeader -and -not $NoHeader
$overwrite = [bool]$Config.Overwrite -and -not $NoOverwrite

if (-not (Test-Path -LiteralPath $CsvFile -PathType Leaf)) {
    Write-Log "CSV file not found: $CsvFile" "ERROR"
    Exit-Script "InputNotFound"
}

$CsvFile = (Resolve-Path -LiteralPath $CsvFile).ProviderPath

$csvFolder = Split-Path -Path $CsvFile -Parent

if ([string]::IsNullOrWhiteSpace($XlsxFile)) {
    # Same folder and name as the CSV
    $XlsxFile = [IO.Path]::ChangeExtension($CsvFile, ".xlsx")
}
elseif ([string]::IsNullOrEmpty((Split-Path -Path $XlsxFile -Parent))) {
    # Name only: next to the CSV
    $XlsxFile = Join-Path $csvFolder $XlsxFile
}

# (.csv in, .xlsx out: checked at binding, so the CSV can't be overwritten)
$XlsxFile = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($XlsxFile)

if ([string]::IsNullOrWhiteSpace($SheetName)) {
    $SheetName = [IO.Path]::GetFileNameWithoutExtension($CsvFile)
}

$SheetName = Get-XlsxSheetName -Name $SheetName -Format $format

Write-Log "Config     : $ConfigFile"
Write-Log "CSV file   : $CsvFile"
Write-Log "Excel file : $XlsxFile"
Write-Log "Sheet      : $SheetName"
Write-Log "Delimiter  : $(if ($Delimiter -eq "`t") { 'tab' } else { $Delimiter })"
Write-Log "Encoding   : $Encoding"
Write-Log "Header     : $hasHeader"
Write-Log "Overwrite  : $overwrite"
Write-LogSeparator

$xlsxFolder = Split-Path -Path $XlsxFile -Parent

if (-not (Test-Path -LiteralPath $xlsxFolder -PathType Container)) {
    Write-Log "Output folder not found: $xlsxFolder" "ERROR"
    Exit-Script "InputNotFound"
}

# Fail fast; checked again when the file is put in place
if ((Test-Path -LiteralPath $XlsxFile -PathType Leaf) -and -not $overwrite) {
    Write-Log "Excel file already exists and overwrite is off; nothing written" "ERROR"
    Exit-Script "OutputExists"
}

#--------------------------------------------------------------------------
# CONVERT + VALIDATE + PUT IN PLACE
#--------------------------------------------------------------------------

$partial = New-PartialPath $XlsxFile

try {
    #----------------------------------------------------------------------
    # 1. Write
    #----------------------------------------------------------------------

    try {
        $written = ConvertTo-XlsxFile `
            -CsvPath $CsvFile `
            -XlsxPath $partial `
            -Delimiter $Delimiter `
            -Encoding $Encoding `
            -SheetName $SheetName `
            -Format $format `
            -NoHeader:(-not $hasHeader)
    }
    catch {
        $inner = $_.Exception

        while ($inner.InnerException) { $inner = $inner.InnerException }

        Write-LogException $_ "Conversion failed"

        if ($inner -is [ExcelExport.XlsxLimitException]) {
            Exit-Script "ExcelLimitExceeded"
        }

        Exit-Script "ConversionFailed"
    }

    Write-Log "Written    : $($written.Rows) row(s), $($written.MinColumns)-$($written.MaxColumns) column(s), $($written.Cells) cell(s)"

    if ($written.RaggedRows -gt 0) {
        Write-Log "$($written.RaggedRows) row(s) have a different number of fields than the first row" "WARN"
    }

    if ($written.TrailingBlankLines -gt 0) {
        Write-Log "$($written.TrailingBlankLines) blank line(s) at the end of the CSV not written"
    }

    if ($written.RemovedChars -gt 0) {
        Write-Log "$($written.RemovedChars) character(s) Excel can't hold (control characters) were removed" "WARN"
    }

    #----------------------------------------------------------------------
    # 2. Validate: open the workbook and compare every cell
    #----------------------------------------------------------------------

    try {
        $read = Read-XlsxFile -Path $partial -Format $format
    }
    catch {
        Write-LogException $_ "Excel file can't be opened"
        Exit-Script "ValidationFailed"
    }

    Write-Log "Read back  : $($read.Rows) row(s), $($read.MinColumns)-$($read.MaxColumns) column(s), $($read.Cells) cell(s)"

    $problems = @()

    if ($read.Rows -ne $written.Rows)             { $problems += "rows: CSV $($written.Rows), Excel $($read.Rows)" }
    if ($read.Cells -ne $written.Cells)           { $problems += "cells: CSV $($written.Cells), Excel $($read.Cells)" }
    if ($read.MaxColumns -ne $written.MaxColumns) { $problems += "columns: CSV $($written.MaxColumns), Excel $($read.MaxColumns)" }
    if ($read.Hash -cne $written.Hash)            { $problems += "cell values differ (hash)" }

    if ($problems.Count -gt 0) {
        foreach ($p in $problems) {
            Write-Log "Mismatch: $p" "ERROR"
        }

        Exit-Script "ValidationFailed"
    }

    Write-Log "Validation : every cell matches the CSV"

    #----------------------------------------------------------------------
    # 3. Put in place
    #----------------------------------------------------------------------

    try {
        Move-FileIntoPlace -Source $partial -Destination $XlsxFile -Overwrite $overwrite
    }
    catch {
        if (-not $overwrite -and (Test-Path -LiteralPath $XlsxFile -PathType Leaf)) {
            Write-Log "Excel file appeared during the conversion and overwrite is off" "ERROR"
            Exit-Script "OutputExists"
        }

        Write-LogException $_ "Could not put the Excel file in place (open in Excel? read-only?)"
        Exit-Script "ConversionFailed"
    }

    Write-Log "Excel file ready: $XlsxFile"
}
finally {
    # Never leave a partial file behind
    if (Test-Path -LiteralPath $partial) {
        Remove-Item -LiteralPath $partial -Force -ErrorAction SilentlyContinue
    }
}

Exit-Script "Success"
