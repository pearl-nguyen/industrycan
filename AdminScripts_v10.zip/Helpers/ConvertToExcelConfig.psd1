#--------------------------------------------------------------------------
# ConvertToExcelConfig.psd1
#   Settings for Helpers\ConvertToExcel.ps1
#--------------------------------------------------------------------------

@{
    #----------------------------------------------------------------------
    # Defaults for the CSV (parameters override them)
    #----------------------------------------------------------------------

    # Field delimiter: "," "|" ";" or "`t" (tab)
    Delimiter   = ","

    # CSV text encoding: UTF8 (a BOM is detected), Windows1252 or Unicode
    Encoding    = "UTF8"

    # First row is a header (bold, frozen). -NoHeader overrides it.
    HasHeader   = $true

    # Replace an existing .xlsx (only after the new one is validated).
    # -NoOverwrite overrides it.
    Overwrite   = $true

    #----------------------------------------------------------------------
    # Excel: limits and .xlsx format. Values from Microsoft's Excel
    # specifications and the Office Open XML standard; change them only if
    # those change.
    #----------------------------------------------------------------------
    Excel = @{
        # Limits of one Excel worksheet
        MaxRows            = 1048576
        MaxColumns         = 16384
        MaxCellChars       = 32767

        # Sheet name rules
        SheetNameMaxLength    = 31
        SheetNameInvalidChars = '[]:*?/\'
        DefaultSheetName      = "Sheet1"

        # Look of the sheet
        FontName           = "Calibri"
        FontSize           = 11
        TextNumberFormatId = 49        # built-in format "@" (text): values stay as typed

        # Column widths (in characters), sized from the first rows
        WidthSampleRows    = 1000
        MinColumnWidth     = 8
        MaxColumnWidth     = 60

        # Office Open XML names (namespaces, content and relationship types)
        MainNamespace                = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
        RelationshipNamespace        = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
        PackageRelationshipNamespace = "http://schemas.openxmlformats.org/package/2006/relationships"
        ContentTypesNamespace        = "http://schemas.openxmlformats.org/package/2006/content-types"
        RelationshipsContentType     = "application/vnd.openxmlformats-package.relationships+xml"
        WorkbookContentType          = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"
        WorksheetContentType         = "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"
        StylesContentType            = "application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"
        OfficeDocumentRelationship   = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument"
        WorksheetRelationship        = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet"
        StylesRelationship           = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles"
    }

    #----------------------------------------------------------------------
    # Exit codes returned to the calling job.
    # A failure before this file is loaded (modules, this config itself)
    # exits with 99: the script hardcodes it since these codes aren't known yet.
    #----------------------------------------------------------------------
    # 1 is not used: PowerShell returns 1 when a parameter is missing or
    # invalid (the script never started).
    ExitCodes = @{
        Success            = 0    # .xlsx written, validated and in place
        ConversionFailed   = 6    # CSV can't be read (bad quoting, encoding) or .xlsx can't be written
        InputNotFound      = 2    # CSV file not found
        ValidationFailed   = 3    # the .xlsx read back doesn't match the CSV; nothing replaced
        OutputExists       = 4    # .xlsx exists and overwrite is off
        ExcelLimitExceeded = 5    # too many rows/columns, or a cell too long for Excel
        Unexpected         = 99   # any error not covered above, or config not loaded
    }
}
