<#
    CleanupItems.ps1

  SYNOPSIS
    Cleans up old files or folders.

  DESCRIPTION
    Removes old files or folders from a target location while keeping the
    most recent items.

    File mode:
      - Removes files matching the given extension (exact match).
      - Keeps the given number of most recent files.
      - Optionally excludes files whose base names end with ExcludeSuffix.

    Folder mode:
      - Only allowed when -Folder's own name is in FolderMode.AllowedParentNames
        in the config (default: logs, dumps, data). Anything else is refused.
      - Removes old subfolders (recursively). Junctions/symlinks are skipped.
      - Keeps the given number of most recent folders.
      - Optionally excludes folders whose names end with ExcludeSuffix.

    Excluded items (ExcludeSuffix) are never deleted and do NOT count toward
    KeepItems. This run's own log file, or the folder holding it, is never
    deleted and DOES count toward KeepItems (KeepItems 5 = it + 4 others).
    Supports -WhatIf for a dry run (the items that would be deleted are logged).

  PARAMETERS
    -Folder         Parent folder containing the files or subfolders to clean up.
    -Mode           File = remove old files; Folder = remove old folders.
    -Extension      Mode File: extension WITHOUT the dot (letters, digits, _ or -).
                    Example: log, dmp, csv   (".log" or "tar.gz" are rejected)
    -KeepItems      Number of most recent files or folders to keep (minimum 1).
    -ExcludeSuffix  Suffix of files or folders that must never be deleted.
    -SortBy         How "most recent" is decided: LastWriteTime (default),
                    CreationTime or Name. For timestamp-named folders
                    (e.g. 20261026_153000), Name is the most reliable.
    -LogFolder      Optional. Not given: no log file, lines go to the console.
    -LogFileName    Optional. Log file name without .log (default: yyyyMMdd_HHmmss).

  PARAMETER CHECKS
    Parameters are checked when PowerShell binds them (before the script
    starts): a missing required parameter, a wrong value, a path that is
    not a full path (C:\... or \\server\...) or a bad path character stops
    the run with PowerShell's exit code 1 and a message on the console; no
    log is written. None of this script's own exit codes is 1, so 1 always
    means "bad parameters, nothing ran". Run jobs with -NonInteractive, or
    a missing required parameter makes PowerShell wait for typed input.
    Full paths are required because a scheduled task may start in
    C:\Windows\System32, where a relative path would point.

  EXIT CODES
    From ExitCodes in CleanupItemsConfig.psd1:
      Success  everything selected was removed (or nothing needed removing,
               or the folder does not exist)
      Error    invalid input or an unexpected failure; cleanup did not run
               or stopped early
      Partial  cleanup ran, but one or more items could not be deleted
               (e.g. file in use, access denied); each failure is logged
    99 = setup failed (module or config could not be loaded).
    Parameter errors (missing/invalid argument) are reported by PowerShell
    before the script runs, with exit code 1 and nothing logged.

  EXAMPLES
    .\CleanupItems.ps1 -Folder "C:\Logs" -Mode File -Extension log -KeepItems 200 -WhatIf

    .\CleanupItems.ps1 -Folder "C:\Exports\logs" -Mode Folder -KeepItems 30 -SortBy Name `
        -ExcludeSuffix "_keep" -LogFolder "C:\Jobs\Cleanup\logs"

  NOTES
    Layout (<root> = parent of this script's folder):
        <root>\Helpers\CleanupItems.ps1
        <root>\Helpers\CleanupItemsConfig.psd1
        <root>\Common\modules\Logging.psm1
        <root>\Common\modules\ConfigHelpers.psm1
#>

[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^([A-Za-z]:[\\/]|\\\\[^\\/]+[\\/])[^*?"<>|]*$')]
    [string]$Folder,

    [Parameter(Mandatory = $true)]
    [ValidateSet('File', 'Folder')]
    [string]$Mode,

    [ValidateScript({
        if ($_ -match '^[A-Za-z0-9_-]+$') { $true }
        else { throw "Extension must be letters, digits, _ or - only, without a dot (e.g. 'log', not '.log'). Got: '$_'" }
    })]
    [string]$Extension,

    [ValidateRange(1, [int]::MaxValue)]
    [int]$KeepItems = 365,

    # End of a file or folder name: no folder part, no wildcards
    [ValidatePattern('^[^\\/:*?"<>|]*$')]
    [string]$ExcludeSuffix,

    [ValidateSet('LastWriteTime', 'CreationTime', 'Name')]
    [string]$SortBy = 'LastWriteTime',

    # Not given: no log file, all lines go to the console (standard output)
    [ValidatePattern('^(([A-Za-z]:[\\/]|\\\\[^\\/]+[\\/])[^*?"<>|]*)?$')]
    [string]$LogFolder,

    # Plain file name (no folder), without .log
    [ValidatePattern('^[^\\/:*?"<>|]*$')]
    [string]$LogFileName
)

$ErrorActionPreference = "Stop"

# Used until the config (and its ExitCodes) is loaded
$UnexpectedExitCode = 99

$RootFolder   = Split-Path $PSScriptRoot -Parent
$ModuleFolder = Join-Path $RootFolder "Common\modules"
$ConfigFile   = Join-Path $PSScriptRoot "CleanupItemsConfig.psd1"

$ConfigRequired = @("ExitCodes.Success", "ExitCodes.Error", "ExitCodes.Partial")

if ($Mode -eq 'Folder') {
    $ConfigRequired += "FolderMode.AllowedParentNames"
}

#--------------------------------------------------------------------------
# BOOTSTRAP 1: LOGGING (nothing to log to yet -> console, exit 99)
#--------------------------------------------------------------------------

try {
    foreach ($module in @("Logging", "ScriptHelpers")) {
        Import-Module (Join-Path $ModuleFolder "$module.psm1") -Force -ErrorAction Stop
    }

    # No -LogFolder: console only ($logPath is $null)
    $logPath = Initialize-Log -LogFolder $LogFolder -LogFileName $LogFileName
}
catch {
    [Console]::Out.WriteLine("Bootstrap failed (logging): $($_.Exception.Message)")
    exit $UnexpectedExitCode
}

Write-ScriptStart -Title "Cleanup started" -LogPath $logPath -LogFileName $LogFileName

#--------------------------------------------------------------------------
# BOOTSTRAP 2: MODULES AND CONFIG (exit codes not known yet -> exit 99)
#--------------------------------------------------------------------------

try {
    Import-Module (Join-Path $ModuleFolder "ConfigHelpers.psm1") -Force -ErrorAction Stop

    $Config = Import-ConfigFile -Path $ConfigFile -Required $ConfigRequired

    # From here on: Exit-Script "<reason>" uses ExitCodes from the config
    Set-ScriptExit -ExitCodes $Config.ExitCodes

    $allowedParents = @($Config.FolderMode.AllowedParentNames | Where-Object { $_ })
}
catch {
    Write-LogException $_ "Bootstrap failed"
    Exit-Script "Unexpected" -Code $UnexpectedExitCode
}

Write-Log "Config        : $ConfigFile"
Write-Log "Mode          : $Mode"
Write-Log "Folder        : $Folder"
Write-Log ("Extension     : {0}" -f $(if ($Mode -eq 'File') { $Extension } else { 'N/A' }))
Write-Log "Keep items    : $KeepItems"
Write-Log "Sort by       : $SortBy"
Write-Log "ExcludeSuffix : $ExcludeSuffix"
Write-Log "WhatIf mode   : $WhatIfPreference"
Write-LogSeparator

#--------------------------------------------------------------------------
# CLEANUP
#--------------------------------------------------------------------------

try {
    if (-not (Test-Path -LiteralPath $Folder -PathType Container)) {
        Write-Log "Folder does not exist: $Folder" "WARN"
        Exit-Script "Success"
    }

    $resolved = (Resolve-Path -LiteralPath $Folder).ProviderPath
    $sep      = [IO.Path]::DirectorySeparatorChar

    Write-Log "Resolved folder: $resolved"

    if ($resolved.TrimEnd($sep) -eq [IO.Path]::GetPathRoot($resolved).TrimEnd($sep)) {
        throw "Refusing to clean a drive root: $resolved"
    }

    if ($Mode -eq 'File') {

        if ([string]::IsNullOrWhiteSpace($Extension)) {
            throw "Extension is required when Mode=File."
        }

        $ext = '.' + $Extension

        # Exact extension match avoids the 8.3 quirk where *.log also matches .logx
        $items = @(Get-ChildItem -LiteralPath $resolved -File |
                   Where-Object { $_.Extension -eq $ext })
    }
    else {
        # Recursive folder deletion only inside a folder with an allowed name (e.g. 'logs')
        $leaf = Split-Path -Path $resolved.TrimEnd($sep) -Leaf

        if (-not ($allowedParents -contains $leaf)) {
            throw "Refusing Folder mode: '$resolved' is not named one of: $($allowedParents -join ', ') (FolderMode.AllowedParentNames)."
        }

        $items = @(Get-ChildItem -LiteralPath $resolved -Directory)

        # Never delete through a junction/symlink: Windows PowerShell 5.1
        # Remove-Item -Recurse can delete the link target's contents instead
        # of just the link.
        $links = @($items | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint })

        foreach ($l in $links) {
            Write-Log "Skipped (junction/symlink): $($l.Name)" "WARN"
        }

        $items = @($items | Where-Object { -not ($_.Attributes -band [IO.FileAttributes]::ReparsePoint) })
    }

    # This run's own log file, or the folder holding it: never deleted, but
    # it counts as one of the KeepItems (KeepItems 5 = this one + 4 others)
    $current = @()

    if ($logPath) {

        $logDir = Split-Path -Path $logPath -Parent

        $current = @($items | Where-Object {
            $_.FullName -eq $logPath -or
            ($logDir + $sep).StartsWith($_.FullName.TrimEnd($sep) + $sep, [StringComparison]::OrdinalIgnoreCase)
        })

        $items = @($items | Where-Object { $current -notcontains $_ })
    }

    # Items protected by ExcludeSuffix are never deleted and don't use a slot
    $candidates = @($items | Where-Object {
        if ([string]::IsNullOrEmpty($ExcludeSuffix)) { return $true }
        $name = if ($Mode -eq 'File') { $_.BaseName } else { $_.Name }
        -not $name.EndsWith($ExcludeSuffix, [StringComparison]::OrdinalIgnoreCase)
    })

    $keepOthers = [math]::Max(0, $KeepItems - $current.Count)

    $toDelete = @($candidates |
                  Sort-Object -Property $SortBy -Descending |
                  Select-Object -Skip $keepOthers)

    foreach ($c in $current) {
        Write-Log "Kept (this run's log): $($c.Name)"
    }

    Write-Log ("Found: {0}, this run: {1}, excluded: {2}, to be deleted: {3}" -f `
        ($items.Count + $current.Count), $current.Count, ($items.Count - $candidates.Count), $toDelete.Count)

    $deleted = 0
    $failed  = 0

    foreach ($item in $toDelete) {

        if ($PSCmdlet.ShouldProcess($item.FullName, "Delete $($Mode.ToLower())")) {

            try {
                Remove-Item -LiteralPath $item.FullName -Recurse:($Mode -eq 'Folder') -Force -ErrorAction Stop
                Write-Log "Deleted: $($item.Name)"
                $deleted++
            }
            catch {
                Write-Log "FAILED : $($item.Name) - $($_.Exception.Message)" "ERROR"
                $failed++
            }
        }
        else {
            # -WhatIf: ShouldProcess prints to the host, which a batch
            # redirect may not capture
            Write-Log "WhatIf: would delete $($item.Name)"
        }
    }

    if ($failed -gt 0) {
        Write-Log "Cleanup partially completed. Deleted: $deleted, failed: $failed." "WARN"
        Exit-Script "Partial"
    }

    Write-Log "Cleanup completed. Deleted: $deleted."
    Exit-Script "Success"
}
catch {
    Write-LogException $_ "Cleanup failed"
    Exit-Script "Error"
}
