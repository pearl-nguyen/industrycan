#--------------------------------------------------------------------------
# CleanupItemsConfig.psd1
#   Settings for Helpers\CleanupItems.ps1
#--------------------------------------------------------------------------

@{
    #----------------------------------------------------------------------
    # Exit codes returned to the calling job.
    # A failure before this file is loaded (modules, this config itself)
    # exits with 99: the script hardcodes it since these codes aren't known yet.
    #----------------------------------------------------------------------
    # 1 is not used: PowerShell returns 1 when a parameter is missing or
    # invalid (the script never started).
    ExitCodes = @{
        Success = 0    # everything selected was removed (or nothing to remove, or folder missing)
        Error   = 3    # invalid input or unexpected failure; cleanup did not run or stopped early
        Partial = 2    # cleanup ran, but some items could not be deleted (in use, access denied)
    }

    FolderMode = @{
        # Folder mode (recursive delete) only runs when -Folder's own name is
        # one of these (case-insensitive).
        # Example: D:\jobs\abc\logs is allowed, D:\jobs\abc is refused.
        AllowedParentNames = @('logs', 'dumps', 'data')
    }
}
