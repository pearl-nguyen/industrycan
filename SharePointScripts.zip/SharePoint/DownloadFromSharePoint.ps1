<#
    DownloadFromSharePoint.ps1

    Downloads one file from a SharePoint Online document library:
      - a file path  : downloads that file
      - a folder path: with -DownloadLatest, downloads the most recently
                       modified file in that folder (top level, optional
                       -Filter such as "*.csv")

  DESCRIPTION
    1. Skips the download if the local file is already identical
       (size + QuickXorHash)
    2. Streams the file to <name>.<id>.partial in the destination folder
       (fresh download URL and current metadata on every attempt)
    3. Validates size + QuickXorHash against SharePoint (a download returns
       the exact stored bytes, so this also holds for Office files)
    4. Sets the local modified time to SharePoint's
    5. Puts it in place in one step (atomic replace of an existing file)

    The destination never holds a partial or unvalidated file, and a failed
    download leaves an existing local file untouched. Throttling
    (Retry-After) is honored and failed downloads are retried.

    The remote path is relative to the site's default document library.
    If it starts with the library's name ("Documents" or
    "Shared Documents") and isn't found, it is retried without that name.

    Logs : <LogFolder>\<LogFileName>.log

  EXAMPLES
    One file:
    powershell.exe -ExecutionPolicy Bypass -File C:\Development\scripts\SharePoint\DownloadFromSharePoint.ps1 `
        -SiteName "smsfc" `
        -RemotePath "Mass Cancellation/test.xlsx" `
        -LocalFolder "C:\Development\data\in" `
        -LogFolder "C:\Development\logs\MassCancellation"

    Latest CSV in a folder, saved under a fixed name:
    powershell.exe -ExecutionPolicy Bypass -File C:\Development\scripts\SharePoint\DownloadFromSharePoint.ps1 `
        -SiteName "smsfc" `
        -RemotePath "Mass Cancellation" `
        -DownloadLatest `
        -Filter "*.csv" `
        -LocalFolder "C:\Development\data\in" `
        -LocalFileName "latest.csv" `
        -LogFolder "C:\Development\logs\MassCancellation"

    Options:
        -LocalFileName "other.xlsx"   save under another name (no folders)
        -NoOverwrite                  fail (FileExists) if a different local file exists

  NOTES
    Same layout, modules and SharepointConfig.psd1 as Upload2SharePoint.ps1.
    The local folder must exist (a typo is reported, not silently created).
    Exit codes are defined in SharepointConfig.psd1 (ExitCodes).
    99 is also returned when the config itself could not be loaded.
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$SiteName,

    # File or folder inside the default document library,
    # e.g. "Folder/Sub/file.xlsx" or "Folder/Sub"
    [Parameter(Mandatory = $true)]
    [AllowEmptyString()]
    [string]$RemotePath,

    # RemotePath is a folder: download its most recently modified file
    [switch]$DownloadLatest,

    # With -DownloadLatest: only consider files matching this pattern
    [string]$Filter = "*",

    [Parameter(Mandatory = $true)]
    [string]$LocalFolder,

    # Defaults to the remote file name
    [string]$LocalFileName,

    # <rootfolder>\logs\<jobname>, passed by the calling job
    [Parameter(Mandatory = $true)]
    [string]$LogFolder,

    [string]$LogFileName,

    # Default is to replace a different local file (after validation).
    # A switch (not [bool]) so it works from a batch file with -File.
    [switch]$NoOverwrite
)

$ErrorActionPreference = "Stop"

# Used until the config (and its ExitCodes) is loaded
$UnexpectedExitCode = 99

$RootFolder   = Split-Path $PSScriptRoot -Parent
$ModuleFolder = Join-Path $RootFolder "Common\modules"
$ConfigFile   = Join-Path $PSScriptRoot "SharepointConfig.psd1"
$Overwrite    = -not $NoOverwrite

$ConfigRequired = @(
    "EntraConfig",
    "SharePointHost",
    "MaxRetries",
    "BaseDelay",
    "MaxThrottleEvents",
    "MaxRetryAfter",
    "DownloadTimeoutMinutes",
    "ExitCodes.Success",
    "ExitCodes.LocalPathNotFound",
    "ExitCodes.AuthFailed",
    "ExitCodes.SiteNotFound",
    "ExitCodes.FileExists",
    "ExitCodes.InvalidFileName",
    "ExitCodes.RemoteFileNotFound",
    "ExitCodes.DownloadFailed",
    "ExitCodes.RemoteIsFolder",
    "ExitCodes.LocalWriteFailed",
    "ExitCodes.SetupFailed",
    "ExitCodes.Unexpected"
)

$EntraRequired = @("TenantId", "ClientId", "Thumbprint")

#--------------------------------------------------------------------------
# BOOTSTRAP 1: LOGGING (nothing to log to yet -> stderr, exit 99)
#--------------------------------------------------------------------------

try {
    Import-Module (Join-Path $ModuleFolder "Logging.psm1") -Force -ErrorAction Stop

    $logPath = Initialize-Log -LogFolder $LogFolder -LogFileName $LogFileName
}
catch {
    [Console]::Error.WriteLine("Bootstrap failed (logging): $($_.Exception.Message)")
    exit $UnexpectedExitCode
}

Write-LogSeparator
Write-Log "Download started"
Write-Log "Log file   : $logPath"

#--------------------------------------------------------------------------
# BOOTSTRAP 2: MODULES AND CONFIG (exit codes not known yet -> exit 99)
#--------------------------------------------------------------------------

try {
    foreach ($module in @("ConfigHelpers", "HttpHelpers", "GraphAuth", "SpGraph", "FileValidation", "SpTransfer")) {
        Import-Module (Join-Path $ModuleFolder "$module.psm1") -Force -ErrorAction Stop
    }

    $Config    = Import-ConfigFile -Path $ConfigFile -Required $ConfigRequired
    $ExitCodes = $Config.ExitCodes
}
catch {
    Write-LogException $_ "Bootstrap failed"
    Write-Log "Finished with exit code $UnexpectedExitCode (Unexpected)"
    Write-LogSeparator
    exit $UnexpectedExitCode
}

#--------------------------------------------------------------------------
# HELPERS
#--------------------------------------------------------------------------

# Single exit point: disconnects from Graph, logs the code and exits.
# $Reason is a key of ExitCodes in SharepointConfig.psd1.
function Exit-Download {

    param([Parameter(Mandatory = $true)][string]$Reason)

    $code = $ExitCodes[$Reason]

    if ($null -eq $code) {
        Write-Log "Unknown exit reason '$Reason'" "WARN"
        $Reason = "Unexpected"
        $code   = $ExitCodes.Unexpected
    }

    Disconnect-AppGraph

    Write-Log "Finished with exit code $code ($Reason)"
    Write-LogSeparator

    exit $code
}

# Looks up an item by path parts, with retries; $null if not found
function Find-RemoteItem {

    param([string[]]$Parts)

    return Invoke-WithRetry `
        -Activity "Locate /$($Parts -join '/')" `
        -MaxRetries $Config.MaxRetries `
        -BaseDelay $Config.BaseDelay `
        -ScriptBlock { Get-SpItemByPath -DriveId $drive.Id -PathParts $Parts }
}

# Safety net: any unexpected terminating error outside a try/catch is
# logged, disconnects from Graph and exits with ExitCodes.Unexpected
trap {
    Write-LogException $_ "Unexpected error"
    Exit-Download "Unexpected"
}

#--------------------------------------------------------------------------
# SETUP (config loaded -> SetupFailed)
#--------------------------------------------------------------------------

try {
    # Check the Entra config here so a missing/incomplete file is reported
    # as a setup problem, not an authentication failure
    $entraConfigPath = Resolve-ConfigPath -ConfigFile $ConfigFile -Path $Config.EntraConfig

    Import-ConfigFile -Path $entraConfigPath -Required $EntraRequired | Out-Null

    Set-ThrottlePolicy -MaxEvents $Config.MaxThrottleEvents -MaxRetryAfter $Config.MaxRetryAfter

    Write-Log "Config     : $ConfigFile"
    Write-Log "Entra      : $entraConfigPath"
}
catch {
    Write-LogException $_ "Setup failed"
    Exit-Download "SetupFailed"
}

#--------------------------------------------------------------------------
# PARAMETERS
#--------------------------------------------------------------------------

if (-not (Test-Path -LiteralPath $LocalFolder -PathType Container)) {
    Write-Log "Local folder not found: $LocalFolder" "ERROR"
    Exit-Download "LocalPathNotFound"
}

$LocalFolder = (Resolve-Path -LiteralPath $LocalFolder).Path

# A plain file name only: no folders, no "..", no invalid characters,
# so the file can't land outside -LocalFolder
if (-not [string]::IsNullOrWhiteSpace($LocalFileName)) {

    $invalid = [System.IO.Path]::GetInvalidFileNameChars()

    if ($LocalFileName.IndexOfAny($invalid) -ge 0 -or
        $LocalFileName -match '[\\/]' -or
        $LocalFileName.Trim('.', ' ') -eq '') {
        Write-Log "Invalid -LocalFileName '$LocalFileName': must be a plain file name" "ERROR"
        Exit-Download "InvalidFileName"
    }
}

$remoteParts = @($RemotePath -split '[\\/]' | Where-Object { $_ -ne '' })

if ($remoteParts.Count -eq 0 -and -not $DownloadLatest) {
    Write-Log "Remote path is empty (use -DownloadLatest to take the newest file of the library root)" "ERROR"
    Exit-Download "RemoteFileNotFound"
}

Write-Log "Site name  : $SiteName"
Write-Log "Remote     : /$($remoteParts -join '/')"
Write-Log "Mode       : $(if ($DownloadLatest) { "Newest file in folder (filter '$Filter')" } else { 'File' })"
Write-Log "Folder     : $LocalFolder"
Write-Log "Overwrite  : $Overwrite"
Write-LogSeparator

#--------------------------------------------------------------------------
# AUTHENTICATION
#--------------------------------------------------------------------------

try {
    $connection = Connect-AppGraph -EntraConfigPath $entraConfigPath

    Write-Log "Graph authentication successful (client $($connection.ClientId))"
}
catch {
    Write-LogException $_
    Exit-Download "AuthFailed"
}

#--------------------------------------------------------------------------
# LOCATE SITE AND DEFAULT DOCUMENT LIBRARY
#--------------------------------------------------------------------------

try {
    $drive = Invoke-WithRetry `
        -Activity "Locate site" `
        -MaxRetries $Config.MaxRetries `
        -BaseDelay $Config.BaseDelay `
        -ShouldRetry { param($m) -not (Test-IsNotFoundError $m) } `
        -ScriptBlock { Get-SpDrive -SharePointHost $Config.SharePointHost -SiteName $SiteName }

    Write-Log "Site       : $($drive.SiteUrl)"
    Write-Log "Library    : $($drive.Name)"
}
catch {
    Write-LogException $_
    Exit-Download "SiteNotFound"
}

#--------------------------------------------------------------------------
# LOCATE REMOTE FILE OR FOLDER
#--------------------------------------------------------------------------

try {
    $item = Find-RemoteItem -Parts $remoteParts

    # People often include the library itself ("Shared Documents/...");
    # paths are relative to it, so retry without that first segment
    if (-not $item -and $remoteParts.Count -gt 1) {

        $libraryNames = @($drive.Name)

        if ($drive.WebUrl) {
            $libraryNames += [uri]::UnescapeDataString(($drive.WebUrl -split '/')[-1])
        }

        if ($libraryNames -contains $remoteParts[0]) {
            Write-Log "Path starts with the library name '$($remoteParts[0])'; retrying without it" "WARN"
            $remoteParts = @($remoteParts | Select-Object -Skip 1)
            $item        = Find-RemoteItem -Parts $remoteParts
        }
    }
}
catch {
    Write-LogException $_
    Exit-Download "Unexpected"
}

if (-not $item) {
    Write-Log "Remote path not found: /$($remoteParts -join '/')" "ERROR"
    Exit-Download "RemoteFileNotFound"
}

if ($item.folder) {

    if (-not $DownloadLatest) {
        Write-Log "Remote path is a folder: /$($remoteParts -join '/') (use -DownloadLatest to take its newest file)" "ERROR"
        Exit-Download "RemoteIsFolder"
    }

    #----------------------------------------------------------------------
    # NEWEST FILE IN THE FOLDER
    #----------------------------------------------------------------------

    try {
        $children = Invoke-WithRetry `
            -Activity "List folder" `
            -MaxRetries $Config.MaxRetries `
            -BaseDelay $Config.BaseDelay `
            -ScriptBlock { Get-SpChildren -DriveId $drive.Id -FolderId $item.id }
    }
    catch {
        Write-LogException $_
        Exit-Download "Unexpected"
    }

    $candidates = @($children | Where-Object { $_.file -and $_.name -like $Filter })

    Write-Log "Folder has $(@($children | Where-Object { $_.file }).Count) file(s), $($candidates.Count) matching '$Filter'"

    if ($candidates.Count -eq 0) {
        Write-Log "No file matching '$Filter' in /$($remoteParts -join '/')" "ERROR"
        Exit-Download "RemoteFileNotFound"
    }

    # Newest modified first; same time -> highest name, so the choice is stable
    $item = $candidates |
        Sort-Object `
            @{ Expression = { ConvertTo-SpDateUtc $_.lastModifiedDateTime }; Descending = $true },
            @{ Expression = { $_.name }; Descending = $true } |
        Select-Object -First 1

    Write-Log "Newest     : $($item.name) (modified $((ConvertTo-SpDateUtc $item.lastModifiedDateTime).ToString('yyyy-MM-dd HH:mm:ss')) UTC)"
}
elseif ($DownloadLatest) {
    Write-Log "Remote path is a file; -DownloadLatest ignored"
}

#--------------------------------------------------------------------------
# DOWNLOAD + VALIDATE + PUT IN PLACE
#--------------------------------------------------------------------------

if ([string]::IsNullOrWhiteSpace($LocalFileName)) {
    $LocalFileName = $item.name
}

$destination = Join-Path $LocalFolder $LocalFileName

Write-LogSeparator

$result = Receive-SpFile `
    -DriveId $drive.Id `
    -Item $item `
    -Destination $destination `
    -Overwrite $Overwrite `
    -Settings $Config

switch ($result.Status) {
    "Downloaded"     { Exit-Download "Success" }
    "AlreadyCurrent" { Exit-Download "Success" }
    default          { Exit-Download $result.Status }   # names match ExitCodes
}
