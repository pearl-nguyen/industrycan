<#
    Upload2SharePoint.ps1

    Uploads one file (-LocalFile) or the files of one folder (-LocalFolder,
    top level only, no subfolders) to a SharePoint Online folder.

  DESCRIPTION
    For each file:
      1. Skips it if the target already has it (same size + QuickXorHash,
         or for Office files: unchanged since the last upload per manifest)
      2. Uploads it to the staging folder under a unique name
      3. Validates without downloading: size + QuickXorHash reported by
         SharePoint. Office files changed by SharePoint (metadata) fall back
         to a download and part-by-part comparison.
      4. Moves the validated file into the target folder with its real name

    The target folder only ever receives fully validated files, and files
    already uploaded are never deleted. Files are sent one at a time,
    honoring SharePoint throttling (Retry-After). Failed files are retried
    over up to MaxPasses passes; files still failing are left for the next
    run (exit PartialFailure), which skips the files already uploaded.

    Logs     : <LogFolder>\<LogFileName>.log
    Manifest : <LogFolder>\state\<SiteName>_<TargetFolder>.json

  EXAMPLES
    powershell.exe -ExecutionPolicy Bypass -File C:\Development\scripts\SharePoint\Upload2SharePoint.ps1 `
        -LocalFile "C:\Development\data\test.xlsx" `
        -SiteName "smsfc" `
        -TargetFolder "Mass Cancellation" `
        -LogFolder "C:\Development\logs\MassCancellation" `
        -LogFileName "20261001_123455"

    powershell.exe -ExecutionPolicy Bypass -File C:\Development\scripts\SharePoint\Upload2SharePoint.ps1 `
        -LocalFolder "C:\Development\data\export" `
        -Filter "*.csv" `
        -SiteName "smsfc" `
        -TargetFolder "Mass Cancellation" `
        -LogFolder "C:\Development\logs\MassCancellation" `
        -NoOverwrite

  NOTES
    Layout (<root> = parent of this script's folder):
        <root>\SharePoint\Upload2SharePoint.ps1
        <root>\SharePoint\DownloadFromSharePoint.ps1
        <root>\SharePoint\SharepointConfig.psd1
        <root>\Common\config\EntraApp.psd1
        <root>\Common\modules\Logging.psm1
        <root>\Common\modules\ConfigHelpers.psm1
        <root>\Common\modules\HttpHelpers.psm1
        <root>\Common\modules\GraphAuth.psm1
        <root>\Common\modules\SpGraph.psm1
        <root>\Common\modules\FileValidation.psm1
        <root>\Common\modules\SpTransfer.psm1

    Exit codes are defined in SharepointConfig.psd1 (ExitCodes).
    99 is also returned when the config itself could not be loaded.
#>

[CmdletBinding(DefaultParameterSetName = "File")]
param(
    [Parameter(Mandatory = $true, ParameterSetName = "File")]
    [string]$LocalFile,

    [Parameter(Mandatory = $true, ParameterSetName = "Folder")]
    [string]$LocalFolder,

    # Folder mode: file name filter, e.g. "*.csv"
    [Parameter(ParameterSetName = "Folder")]
    [string]$Filter = "*",

    [Parameter(Mandatory = $true)]
    [string]$SiteName,

    [Parameter(Mandatory = $true)]
    [string]$TargetFolder,

    # <rootfolder>\logs\<jobname>, passed by the calling job
    [Parameter(Mandatory = $true)]
    [string]$LogFolder,

    [string]$LogFileName,

    # Defaults to StagingFolder in SharepointConfig.psd1
    [string]$StagingFolder,

    # Default is to replace a different file already in the target.
    # A switch (not [bool]) so it works from a batch file with -File.
    [switch]$NoOverwrite
)

$ErrorActionPreference = "Stop"

# Used until the config (and its ExitCodes) is loaded
$UnexpectedExitCode = 99

$RootFolder   = Split-Path $PSScriptRoot -Parent
$ModuleFolder = Join-Path $RootFolder "Common\modules"
$ConfigFile   = Join-Path $PSScriptRoot "SharepointConfig.psd1"
$FolderMode   = ($PSCmdlet.ParameterSetName -eq "Folder")
$Overwrite    = -not $NoOverwrite

$ConfigRequired = @(
    "EntraConfig",
    "SharePointHost",
    "MaxRetries",
    "BaseDelay",
    "MaxThrottleEvents",
    "MaxRetryAfter",
    "SimpleUploadLimitMB",
    "StagingFolder",
    "StagingMaxAgeDays",
    "SettleDelay",
    "HashReadAttempts",
    "DelayBetweenFiles",
    "MaxPasses",
    "PassDelay",
    "StateFolderName",
    "ExitCodes.Success",
    "ExitCodes.UploadFailed",
    "ExitCodes.LocalPathNotFound",
    "ExitCodes.AuthFailed",
    "ExitCodes.SiteNotFound",
    "ExitCodes.FileExists",
    "ExitCodes.FolderError",
    "ExitCodes.MoveFailed",
    "ExitCodes.PartialFailure",
    "ExitCodes.InvalidFileName",
    "ExitCodes.SetupFailed",
    "ExitCodes.Unexpected"
)

$EntraRequired = @("TenantId", "ClientId", "Thumbprint")

# Statuses worth another pass (transient). FileExists and InvalidFileName
# would fail the same way every time.
$RetryableStatuses = @("UploadFailed", "MoveFailed")

#--------------------------------------------------------------------------
# BOOTSTRAP 1: LOGGING (nothing to log to yet -> stderr, exit 99)
#--------------------------------------------------------------------------

try {
    Import-Module (Join-Path $ModuleFolder "Logging.psm1") -Force -ErrorAction Stop

    $logPath = Initialize-Log -LogFolder $LogFolder -LogFileName $LogFileName
}
catch {
    [Console]::Error.WriteLine("Bootstrap failed (logging): $($_.Exception.Message)")
    exit $UnexpectedExitCode
}

Write-LogSeparator
Write-Log "Upload started"
Write-Log "Log file   : $logPath"

#--------------------------------------------------------------------------
# BOOTSTRAP 2: MODULES AND CONFIG (exit codes not known yet -> exit 99)
#--------------------------------------------------------------------------

try {
    foreach ($module in @("ConfigHelpers", "HttpHelpers", "GraphAuth", "SpGraph", "FileValidation", "SpTransfer")) {
        Import-Module (Join-Path $ModuleFolder "$module.psm1") -Force -ErrorAction Stop
    }

    $Config    = Import-ConfigFile -Path $ConfigFile -Required $ConfigRequired
    $ExitCodes = $Config.ExitCodes
}
catch {
    Write-LogException $_ "Bootstrap failed"
    Write-Log "Finished with exit code $UnexpectedExitCode (Unexpected)"
    Write-LogSeparator
    exit $UnexpectedExitCode
}

#--------------------------------------------------------------------------
# HELPERS
#--------------------------------------------------------------------------

# Single exit point: disconnects from Graph, logs the code and exits.
# $Reason is a key of ExitCodes in SharepointConfig.psd1.
function Exit-Upload {

    param([Parameter(Mandatory = $true)][string]$Reason)

    $code = $ExitCodes[$Reason]

    if ($null -eq $code) {
        Write-Log "Unknown exit reason '$Reason'" "WARN"
        $Reason = "Unexpected"
        $code   = $ExitCodes.Unexpected
    }

    Disconnect-AppGraph

    Write-Log "Finished with exit code $code ($Reason)"
    Write-LogSeparator

    exit $code
}

# Safety net: any unexpected terminating error outside a try/catch is
# logged, disconnects from Graph and exits with ExitCodes.Unexpected
trap {
    Write-LogException $_ "Unexpected error"
    Exit-Upload "Unexpected"
}

#--------------------------------------------------------------------------
# SETUP (config loaded -> SetupFailed)
#--------------------------------------------------------------------------

try {
    if ([string]::IsNullOrWhiteSpace($StagingFolder)) {
        $StagingFolder = $Config.StagingFolder
    }

    # Check the Entra config here so a missing/incomplete file is reported
    # as a setup problem, not an authentication failure
    $entraConfigPath = Resolve-ConfigPath -ConfigFile $ConfigFile -Path $Config.EntraConfig

    Import-ConfigFile -Path $entraConfigPath -Required $EntraRequired | Out-Null

    $manifestPath = Get-SpManifestPath `
        -LogFolder $LogFolder `
        -SiteName $SiteName `
        -TargetFolder $TargetFolder `
        -StateFolderName $Config.StateFolderName

    Set-ThrottlePolicy -MaxEvents $Config.MaxThrottleEvents -MaxRetryAfter $Config.MaxRetryAfter

    Write-Log "Config     : $ConfigFile"
    Write-Log "Entra      : $entraConfigPath"
}
catch {
    Write-LogException $_ "Setup failed"
    Exit-Upload "SetupFailed"
}

#--------------------------------------------------------------------------
# LOCAL FILES
#--------------------------------------------------------------------------

if ($FolderMode) {

    if (-not (Test-Path -LiteralPath $LocalFolder -PathType Container)) {
        Write-Log "Local folder not found: $LocalFolder" "ERROR"
        Exit-Upload "LocalPathNotFound"
    }

    # Top level only. "~$*" are Office lock files of documents open in Office.
    $files = @(Get-ChildItem -LiteralPath $LocalFolder -File -Filter $Filter |
        Where-Object { -not $_.Name.StartsWith('~$') } |
        Sort-Object Name)

    Write-Log "Mode       : Folder"
    Write-Log "Folder     : $LocalFolder"
    Write-Log "Filter     : $Filter"
}
else {

    if (-not (Test-Path -LiteralPath $LocalFile -PathType Leaf)) {
        Write-Log "Local file not found: $LocalFile" "ERROR"
        Exit-Upload "LocalPathNotFound"
    }

    $files = @(Get-Item -LiteralPath $LocalFile)

    Write-Log "Mode       : Single file"
}

Write-Log "Files      : $($files.Count)"
Write-Log "Site name  : $SiteName"
Write-Log "Target     : /$($TargetFolder.Trim('/\'))"
Write-Log "Staging    : /$($StagingFolder.Trim('/\'))"
Write-Log "Overwrite  : $Overwrite"
Write-LogSeparator

if ($files.Count -eq 0) {
    Write-Log "No files to upload in $LocalFolder (filter '$Filter')" "WARN"
    Exit-Upload "Success"
}

#--------------------------------------------------------------------------
# AUTHENTICATION
#--------------------------------------------------------------------------

try {
    $connection = Connect-AppGraph -EntraConfigPath $entraConfigPath

    Write-Log "Graph authentication successful (client $($connection.ClientId))"
}
catch {
    Write-LogException $_
    Exit-Upload "AuthFailed"
}

#--------------------------------------------------------------------------
# LOCATE SITE AND DEFAULT DOCUMENT LIBRARY
#--------------------------------------------------------------------------

try {
    $drive = Invoke-WithRetry `
        -Activity "Locate site" `
        -MaxRetries $Config.MaxRetries `
        -BaseDelay $Config.BaseDelay `
        -ShouldRetry { param($m) -not (Test-IsNotFoundError $m) } `
        -ScriptBlock { Get-SpDrive -SharePointHost $Config.SharePointHost -SiteName $SiteName }

    Write-Log "Site       : $($drive.SiteUrl)"
    Write-Log "Library    : $($drive.Name)"
}
catch {
    Write-LogException $_
    Exit-Upload "SiteNotFound"
}

#--------------------------------------------------------------------------
# FOLDERS
#--------------------------------------------------------------------------

try {
    $folders = Invoke-WithRetry `
        -Activity "Locate folders" `
        -MaxRetries $Config.MaxRetries `
        -BaseDelay $Config.BaseDelay `
        -ScriptBlock {
            $target  = Get-SpFolder -DriveId $drive.Id -Path $TargetFolder
            $staging = $null

            if ($target) {
                $staging = Get-SpFolder -DriveId $drive.Id -Path $StagingFolder -CreateIfMissing
            }

            [pscustomobject]@{ Target = $target; Staging = $staging }
        }

    if (-not $folders.Target) {
        throw "Target folder not found: $TargetFolder"
    }

    $targetFolderItem  = $folders.Target
    $stagingFolderItem = $folders.Staging

    Write-Log "Folders ready (target and staging)"
}
catch {
    Write-LogException $_
    Exit-Upload "FolderError"
}

# Copies abandoned by killed runs (never touches anything else)
Clear-SpStaging `
    -DriveId $drive.Id `
    -StagingFolderId $stagingFolderItem.id `
    -MaxAgeDays $Config.StagingMaxAgeDays

#--------------------------------------------------------------------------
# MANIFEST
#--------------------------------------------------------------------------

$manifest = Import-SpManifest -Path $manifestPath

#--------------------------------------------------------------------------
# UPLOAD (one file at a time; extra passes for failed files)
#--------------------------------------------------------------------------

# file name -> result; files never attempted have no entry
$results   = [ordered]@{}
$pending   = $files
$stopped   = $false
$maxPasses = [math]::Max(1, [int]$Config.MaxPasses)

for ($pass = 1; $pass -le $maxPasses; $pass++) {

    if ($pass -gt 1) {

        $pending = @($files | Where-Object {
            $results.Contains($_.Name) -and
            $results[$_.Name].Status -in $RetryableStatuses
        })

        if ($pending.Count -eq 0) {
            break
        }

        # Check before waiting: no point waiting if we are stopping anyway
        if (Test-ThrottleLimitReached) {
            $stopped = $true
            break
        }

        Write-LogSeparator
        Write-Log "Waiting $($Config.PassDelay) seconds before pass $pass" "WARN"
        Start-Sleep -Seconds $Config.PassDelay
    }

    Write-LogSeparator
    Write-Log "Pass $pass of ${maxPasses}: $($pending.Count) file(s)"

    # One listing of the target folder for the whole pass, instead of one
    # request per file. If it fails, each file is looked up on its own.
    $targetIndex = $null

    try {
        $targetIndex = Invoke-WithRetry `
            -Activity "List target folder" `
            -MaxRetries $Config.MaxRetries `
            -BaseDelay $Config.BaseDelay `
            -ScriptBlock { New-SpTargetIndex -DriveId $drive.Id -FolderId $targetFolderItem.id }

        Write-Log "Target folder has $($targetIndex.Count) file(s)"
    }
    catch {
        Write-Log "Could not list target folder; checking files one by one" "WARN"
        Write-LogException $_
        $targetIndex = $null
    }

    for ($i = 0; $i -lt $pending.Count; $i++) {

        $file = $pending[$i]

        # Circuit breaker: SharePoint keeps throttling us, stop cleanly and
        # leave the remaining files for the next run
        if (Test-ThrottleLimitReached) {
            $stopped = $true
            break
        }

        Write-LogSeparator
        Write-Log "File $($i + 1) of $($pending.Count)"

        try {
            $result = Publish-SpFile `
                -DriveId $drive.Id `
                -LocalFile $file.FullName `
                -TargetFolder $TargetFolder `
                -TargetFolderId $targetFolderItem.id `
                -StagingFolder $StagingFolder `
                -Overwrite $Overwrite `
                -Settings $Config `
                -TargetIndex $targetIndex `
                -ManifestEntry $manifest[$file.Name]
        }
        catch {
            # Unexpected error for this file only (e.g. local file locked):
            # record it and carry on with the next file
            Write-LogException $_

            $result           = New-SpTransferResult $file.Name
            $result.LocalPath = $file.FullName
            $result.Status    = "UploadFailed"
            $result.Message   = $_.Exception.Message
        }

        $results[$file.Name] = $result

        # Record what is now on SharePoint, right away, so a crash later in
        # the run doesn't lose it
        if ($result.Status -in @("Uploaded", "Skipped") -and $result.RemoteHash) {

            $manifest[$file.Name] = New-SpManifestEntry -Result $result

            try {
                Save-SpManifest -Path $manifestPath -Manifest $manifest
            }
            catch {
                Write-Log "Could not save manifest (file is uploaded; it may be re-checked next run)" "WARN"
                Write-LogException $_
            }
        }

        # Only pause when a request was made and another file follows
        if ($result.Status -notin @("Skipped", "InvalidFileName") -and $i -lt $pending.Count - 1) {
            Start-Sleep -Seconds $Config.DelayBetweenFiles
        }
    }

    if ($stopped) {
        break
    }
}

if ($stopped) {
    Write-LogSeparator
    Write-Log "SharePoint throttling limit reached ($(Get-ThrottleEventCount) throttle response(s)); remaining files left for the next run" "WARN"
}

#--------------------------------------------------------------------------
# SUMMARY
#--------------------------------------------------------------------------

$uploaded   = @($results.Values | Where-Object { $_.Status -eq "Uploaded" })
$skipped    = @($results.Values | Where-Object { $_.Status -eq "Skipped" })
$failed     = @($results.Values | Where-Object { $_.Status -notin @("Uploaded", "Skipped") })
$notStarted = @($files | Where-Object { -not $results.Contains($_.Name) })

Write-LogSeparator
Write-Log "Summary    : $($files.Count) file(s)"
Write-Log "Uploaded   : $($uploaded.Count)"
Write-Log "Skipped    : $($skipped.Count) (already on SharePoint)"
Write-Log "Failed     : $($failed.Count)"
Write-Log "Not started: $($notStarted.Count)"

foreach ($r in $failed) {
    Write-Log "  FAILED  $($r.FileName) [$($r.Status)] $($r.Message)" "ERROR"
}

foreach ($f in $notStarted) {
    Write-Log "  PENDING $($f.Name) (next run)" "WARN"
}

if ($failed.Count -eq 0 -and $notStarted.Count -eq 0) {
    Write-Log "Upload complete"
    Exit-Upload "Success"
}

# Single file: keep the specific exit code (status names match ExitCodes)
if (-not $FolderMode) {

    if ($notStarted.Count -gt 0) {
        Exit-Upload "UploadFailed"
    }

    Exit-Upload $failed[0].Status
}

# Folder: files already uploaded stay on SharePoint; the next run resumes
Write-Log "Some files were not uploaded; the next run will resume" "WARN"
Exit-Upload "PartialFailure"
